﻿package com.dut.dutGreenTracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
