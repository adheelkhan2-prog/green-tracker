// ignore_for_file: deprecated_member_use, prefer_const_constructors, avoid_print, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import '../screens/projects/project_detail_screen.dart';
import '../../models/project.dart';
import '../screens/tasks/task_evidence_screen.dart';
import '../../models/task.dart';


class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  String _filter = 'all';

  Future<void> _openNotification(Map<String, dynamic> data, String docId) async {
    print('=== NOTIFICATION TAPPED ===');
    print('Type: ${data['notificationType']}');
    print('Related ID: ${data['relatedId']}');
    
    // Show loading indicator
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Opening...'), duration: Duration(seconds: 1)),
    );
    
    // Mark as read
    await FirebaseFirestore.instance
        .collection("notifications")
        .doc(docId)
        .update({"isRead": true});
    
    final relatedId = data['relatedId'];
    final notificationType = data['notificationType'] ?? '';
    
    if (relatedId == null || relatedId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No content available'), backgroundColor: Colors.orange),
      );
      return;
    }

    try {
      // Navigate based on notification type
      if (notificationType.contains('task')) {
        final taskDoc = await FirebaseFirestore.instance
            .collection('tasks')
            .doc(relatedId)
            .get();
        
        if (taskDoc.exists && mounted) {
          final task = Task.fromMap(taskDoc.data()!, taskDoc.id);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TaskEvidenceScreen(task: task),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Task not found'), backgroundColor: Colors.red),
          );
        }
      } 
      else {
        // Try to open as project
        final projectDoc = await FirebaseFirestore.instance
            .collection('projects')
            .doc(relatedId)
            .get();
        
        if (projectDoc.exists && mounted) {
          final project = Project.fromMap(projectDoc.data()!, projectDoc.id);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProjectDetailScreen(project: project),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Content not found'), backgroundColor: Colors.red),
          );
        }
      }
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _markAllAsRead() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;
    
    final notifications = await FirebaseFirestore.instance
        .collection("notifications")
        .where("userId", isEqualTo: userId)
        .where("isRead", isEqualTo: false)
        .get();
    
    for (var doc in notifications.docs) {
      await doc.reference.update({"isRead": true});
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('All marked as read'), backgroundColor: Colors.green),
    );
  }

  String _formatDate(Timestamp? timestamp) {
    if (timestamp == null) return 'Unknown';
    final date = timestamp.toDate();
    final now = DateTime.now();
    final diff = now.difference(date);
    
    if (diff.inDays > 7) return DateFormat('dd MMM').format(date);
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }

  @override
  Widget build(BuildContext context) {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    
    if (userId == null) {
      return const Scaffold(body: Center(child: Text('Please login')));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Notifications"),
        backgroundColor: Colors.green,
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            onSelected: (value) => setState(() => _filter = value),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'all', child: Text('All')),
              const PopupMenuItem(value: 'unread', child: Text('Unread')),
              const PopupMenuItem(value: 'today', child: Text('Today')),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.done_all),
            onPressed: _markAllAsRead,
            tooltip: 'Mark all as read',
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("notifications")
            .where("userId", isEqualTo: userId)
            .orderBy("createdAt", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_none, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No notifications'),
                ],
              ),
            );
          }

          var notifications = snapshot.data!.docs;
          
          // Apply filter
          if (_filter == 'unread') {
            notifications = notifications.where((doc) {
              final data = doc.data() as Map<String, dynamic>;
              return data['isRead'] != true;
            }).toList();
          } else if (_filter == 'today') {
            final today = DateTime.now();
            notifications = notifications.where((doc) {
              final data = doc.data() as Map<String, dynamic>;
              final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
              return createdAt != null &&
                  createdAt.year == today.year &&
                  createdAt.month == today.month &&
                  createdAt.day == today.day;
            }).toList();
          }

          if (notifications.isEmpty) {
            return const Center(child: Text('No notifications match filter'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final doc = notifications[index];
              final data = doc.data() as Map<String, dynamic>;
              final isRead = data['isRead'] == true;
              final type = data['notificationType'] ?? 'general';
              
              // Get icon and color based on type
              IconData icon;
              Color color;
              if (type.contains('task')) {
                icon = Icons.task;
                color = Colors.orange;
              } else if (type.contains('project')) {
                icon = Icons.folder;
                color = Colors.blue;
              } else if (type.contains('team')) {
                icon = Icons.group;
                color = Colors.purple;
              } else {
                icon = Icons.notifications;
                color = Colors.grey;
              }
              
              return Card(
                elevation: isRead ? 1 : 3,
                margin: const EdgeInsets.only(bottom: 12),
                color: isRead ? null : color.withOpacity(0.05),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: isRead ? BorderSide.none : BorderSide(color: color, width: 1.5),
                ),
                child: InkWell(
                  onTap: () => _openNotification(data, doc.id),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        // Icon
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(icon, color: color, size: 28),
                        ),
                        const SizedBox(width: 12),
                        
                        // Content
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                data['title'] ?? 'Notification',
                                style: TextStyle(
                                  fontWeight: isRead ? FontWeight.normal : FontWeight.bold,
                                  fontSize: 14,
                                  color: color,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                data['message'] ?? '',
                                style: const TextStyle(fontSize: 13),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _formatDate(data['createdAt'] as Timestamp?),
                                style: const TextStyle(fontSize: 11, color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                        
                        // Unread dot
                        if (!isRead)
                          Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}