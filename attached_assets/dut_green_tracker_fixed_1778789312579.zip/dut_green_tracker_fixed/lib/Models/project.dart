// lib/models/project.dart
class Project {
  final String id;
  final String title;
  final String status;
  final int progress;
  final String projectTypeId;

  final String? campusId;
  final String? leaderId;
  final List<String> members;

  // 🌱 AI SUSTAINABILITY DATA
  final Map<String, dynamic> scores;
  final double sustainabilityScore;
  
  // 📋 VISIBILITY FIELDS
  final String visibility;    // 'open', 'department', 'restricted'
  final String? department;
  final String? faculty;
  
  // 📅 DATE FIELDS (ADD THESE)
  final dynamic startDate;    // Timestamp or null
  final dynamic endDate;      // Timestamp or null

  Project({
    required this.id,
    required this.title,
    required this.status,
    required this.progress,
    required this.projectTypeId,
    this.campusId,
    this.leaderId,
    this.members = const [],
    required this.scores,
    required this.sustainabilityScore,
    this.visibility = 'open',
    this.department,
    this.faculty,
    this.startDate,    // ← ADD THIS
    this.endDate,      // ← ADD THIS
  });

  // =========================
  // FIRESTORE → APP
  // =========================
  factory Project.fromMap(Map<String, dynamic> map, String id) {
    return Project(
      id: id,
      title: map['title'] ?? '',
      status: map['status'] ?? 'Pending',
      progress: map['progress'] ?? 0,
      projectTypeId: map['projectTypeId'] ?? '',
      campusId: map['campusId'],
      leaderId: map['leaderId'],
      members: List<String>.from(map['members'] ?? []),
      scores: Map<String, dynamic>.from(map['scores'] ?? {}),
      sustainabilityScore: (map['sustainabilityScore'] ?? 0).toDouble(),
      visibility: map['visibility'] ?? 'open',
      department: map['department'],
      faculty: map['faculty'],
      startDate: map['startDate'],    // ← ADD THIS
      endDate: map['endDate'],        // ← ADD THIS
    );
  }

  // =========================
  // APP → FIRESTORE
  // =========================
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'status': status,
      'progress': progress,
      'projectTypeId': projectTypeId,
      'campusId': campusId,
      'leaderId': leaderId,
      'members': members,
      'scores': scores,
      'sustainabilityScore': sustainabilityScore,
      'visibility': visibility,
      'department': department,
      'faculty': faculty,
      'startDate': startDate,    // ← ADD THIS
      'endDate': endDate,        // ← ADD THIS
    };
  }
}