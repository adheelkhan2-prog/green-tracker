class Role {
  final String name;
  final bool canCreateProject;
  final bool canEditProject;
  final bool canDeleteProject;
  final bool canManageUsers;

  Role({
    required this.name,
    this.canCreateProject = false,
    this.canEditProject = false,
    this.canDeleteProject = false,
    this.canManageUsers = false,
  });

  factory Role.fromMap(Map<String, dynamic> map) {
    return Role(
      name: map['name'],
      canCreateProject: map['canCreateProject'] ?? false,
      canEditProject: map['canEditProject'] ?? false,
      canDeleteProject: map['canDeleteProject'] ?? false,
      canManageUsers: map['canManageUsers'] ?? false,
    );
  }
}