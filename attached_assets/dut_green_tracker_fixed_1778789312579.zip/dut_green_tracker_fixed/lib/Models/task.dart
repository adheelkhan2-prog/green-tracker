import 'package:cloud_firestore/cloud_firestore.dart';

class Task {
  final String id;
  final String title;
  final String description;
  final String projectId;
  final String assignedTo;
  final String assignedBy;
  final String status; // pending, in_progress, completed, blocked
  final int progress;
  final DateTime deadline;
  final DateTime? completedAt;
  final List<String> attachments;
  
  // NEW FIELDS
  final int difficultyLevel; // 1-10 (AI calculated)
  final String difficultyReason; // Why AI thinks it's hard/easy
  final List<String> evidenceImages; // URLs of uploaded images
  final String? evidenceNotes; // Notes from student about completion
  final DateTime? evidenceSubmittedAt;
  final bool evidenceVerified; // Admin/Leader verification

  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.projectId,
    required this.assignedTo,
    required this.assignedBy,
    this.status = 'pending',
    this.progress = 0,
    required this.deadline,
    this.completedAt,
    this.attachments = const [],
    this.difficultyLevel = 1,
    this.difficultyReason = '',
    this.evidenceImages = const [],
    this.evidenceNotes,
    this.evidenceSubmittedAt,
    this.evidenceVerified = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'projectId': projectId,
      'assignedTo': assignedTo,
      'assignedBy': assignedBy,
      'status': status,
      'progress': progress,
      'deadline': Timestamp.fromDate(deadline), // FIXED: Convert to Timestamp
      'completedAt': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
      'attachments': attachments,
      'difficultyLevel': difficultyLevel,
      'difficultyReason': difficultyReason,
      'evidenceImages': evidenceImages,
      'evidenceNotes': evidenceNotes,
      'evidenceSubmittedAt': evidenceSubmittedAt != null ? Timestamp.fromDate(evidenceSubmittedAt!) : null,
      'evidenceVerified': evidenceVerified,
    };
  }

  factory Task.fromMap(Map<String, dynamic> map, String id) {
    return Task(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      projectId: map['projectId'] ?? '',
      assignedTo: map['assignedTo'] ?? '',
      assignedBy: map['assignedBy'] ?? '',
      status: map['status'] ?? 'pending',
      progress: map['progress'] ?? 0,
      deadline: (map['deadline'] as Timestamp?)?.toDate() ?? DateTime.now(),
      completedAt: (map['completedAt'] as Timestamp?)?.toDate(),
      attachments: List<String>.from(map['attachments'] ?? []),
      difficultyLevel: map['difficultyLevel'] ?? 1,
      difficultyReason: map['difficultyReason'] ?? '',
      evidenceImages: List<String>.from(map['evidenceImages'] ?? []),
      evidenceNotes: map['evidenceNotes'],
      evidenceSubmittedAt: (map['evidenceSubmittedAt'] as Timestamp?)?.toDate(),
      evidenceVerified: map['evidenceVerified'] ?? false,
    );
  }
}