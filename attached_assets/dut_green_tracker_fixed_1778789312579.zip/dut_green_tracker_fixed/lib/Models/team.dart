// lib/models/team.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class Team {
  final String id;
  final String name;
  final String projectId;
  final List<String> memberIds;
  final String leaderId;
  final int maxMembers;
  final bool isAvailable;
  final DateTime? createdAt;
  final String? createdBy;

  Team({
    required this.id,
    required this.name,
    required this.projectId,
    required this.memberIds,
    required this.leaderId,
    this.maxMembers = 5,
    this.isAvailable = true,
    this.createdAt,
    this.createdBy,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'projectId': projectId,
      'memberIds': memberIds,
      'leaderId': leaderId,
      'maxMembers': maxMembers,
      'isAvailable': isAvailable,
      'createdAt': createdAt ?? FieldValue.serverTimestamp(),
      'createdBy': createdBy,
    };
  }

  factory Team.fromMap(Map<String, dynamic> map, String id) {
    return Team(
      id: id,
      name: map['name'] ?? '',
      projectId: map['projectId'] ?? '',
      memberIds: List<String>.from(map['memberIds'] ?? []),
      leaderId: map['leaderId'] ?? '',
      maxMembers: map['maxMembers'] ?? 5,
      isAvailable: map['isAvailable'] ?? true,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
      createdBy: map['createdBy'],
    );
  }
}