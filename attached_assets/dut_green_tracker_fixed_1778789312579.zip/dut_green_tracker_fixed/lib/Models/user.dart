// lib/models/user.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class AppUser {
  final String id;
  final String email;
  final String name;
  final String role; // admin, lecturer, student, staff, external
  final String? teamId;
  final String? campusId;
  final String? department;  // NEW: e.g., "Computer Science", "Mechanical Engineering"
  final String? faculty;     // NEW: e.g., "Faculty of Engineering", "Faculty of IT"
  final DateTime createdAt;

  AppUser({
    required this.id,
    required this.email,
    required this.name,
    required this.role,
    this.teamId,
    this.campusId,
    this.department,      // NEW
    this.faculty,         // NEW
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'name': name,
      'role': role,
      'teamId': teamId,
      'campusId': campusId,
      'department': department,   // NEW
      'faculty': faculty,         // NEW
      'createdAt': createdAt,
    };
  }

  factory AppUser.fromMap(Map<String, dynamic> map, String id) {
    return AppUser(
      id: id,
      email: map['email'] ?? '',
      name: map['name'] ?? '',
      role: map['role'] ?? 'student',
      teamId: map['teamId'],
      campusId: map['campusId'],
      department: map['department'],   // NEW
      faculty: map['faculty'],         // NEW
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}