// ignore_for_file: deprecated_member_use, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../services/ai_difficulty_service.dart';
import 'package:intl/intl.dart';

class UnassignedTasksCard extends StatelessWidget {
  final String projectId;
  final List<Map<String, dynamic>> projectMembers;
  final Function(String taskId, String memberId) onAssignTask;
  final bool projectCompleted;

  const UnassignedTasksCard({
    super.key,
    required this.projectId,
    required this.projectMembers,
    required this.onAssignTask,
    required this.projectCompleted,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('tasks')
          .where('projectId', isEqualTo: projectId)
          .where('assignedTo', isEqualTo: '')
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            ),
          );
        }

        final unassignedTasks = snapshot.data?.docs ?? [];
        
        if (unassignedTasks.isEmpty) {
          return const SizedBox.shrink(); // Don't show if no unassigned tasks
        }

        return Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.pending_actions, color: Colors.orange),
                    const SizedBox(width: 8),
                    const Text(
                      'Unassigned Tasks',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade100,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${unassignedTasks.length} tasks',
                        style: TextStyle(color: Colors.orange.shade800),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: unassignedTasks.length,
                  itemBuilder: (context, index) {
                    final taskDoc = unassignedTasks[index];
                    final data = taskDoc.data() as Map<String, dynamic>;
                    return _buildUnassignedTaskCard(
                      taskId: taskDoc.id,
                      title: data['title'] ?? 'Untitled',
                      description: data['description'] ?? '',
                      difficulty: data['difficultyLevel'] ?? 1,
                      deadline: (data['deadline'] as Timestamp?)?.toDate(),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildUnassignedTaskCard({
    required String taskId,
    required String title,
    required String description,
    required int difficulty,
    required DateTime? deadline,
  }) {
    final difficultyColor = AIDifficultyService.getDifficultyColor(difficulty);
    final isOverdue = deadline != null && deadline.isBefore(DateTime.now());

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.orange.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.orange.shade200),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: difficultyColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.task, size: 18, color: difficultyColor),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: difficultyColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Lvl $difficulty',
                    style: TextStyle(fontSize: 10, color: difficultyColor),
                  ),
                ),
              ],
            ),
            if (description.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                description.length > 100 ? '${description.substring(0, 100)}...' : description,
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, size: 12, color: isOverdue ? Colors.red : Colors.grey),
                const SizedBox(width: 4),
                Text(
                  deadline != null
                      ? 'Due: ${DateFormat('dd MMM yyyy').format(deadline)}'
                      : 'No deadline set',
                  style: TextStyle(
                    fontSize: 11,
                    color: isOverdue ? Colors.red : Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (projectMembers.isEmpty)
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.warning, size: 14, color: Colors.grey),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'No team members available. Add members to the project first.',
                        style: TextStyle(fontSize: 11),
                      ),
                    ),
                  ],
                ),
              )
            else if (!projectCompleted)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Assign to:',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: projectMembers.map((member) {
                      return ActionChip(
                        label: Text(member['name']),
                        onPressed: () => onAssignTask(taskId, member['id']),
                        backgroundColor: Colors.green.shade50,
                        labelStyle: const TextStyle(fontSize: 12),
                      );
                    }).toList(),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}