import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyA6pdXISQprDIDOLqg66JaYgeN_B_nLGt4',
    appId: '1:800083889966:android:68aef71f6e109082a7b4bf',
    messagingSenderId: '800083889966',
    projectId: 'dut-green-tracker-fixed',
    storageBucket: 'dut-green-tracker-fixed.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyA6pdXISQprDIDOLqg66JaYgeN_B_nLGt4',
    appId: '1:800083889966:ios:YOUR_IOS_APP_ID',  // You'll need to add iOS app in Firebase
    messagingSenderId: '800083889966',
    projectId: 'dut-green-tracker-fixed',
    storageBucket: 'dut-green-tracker-fixed.firebasestorage.app',
    iosBundleId: 'com.dut.dutGreenTracker',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyA6pdXISQprDIDOLqg66JaYgeN_B_nLGt4',
    appId: '1:800083889966:web:YOUR_WEB_APP_ID',
    messagingSenderId: '800083889966',
    projectId: 'dut-green-tracker-fixed',
    authDomain: 'dut-green-tracker-fixed.firebaseapp.com',
    storageBucket: 'dut-green-tracker-fixed.firebasestorage.app',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyA6pdXISQprDIDOLqg66JaYgeN_B_nLGt4',
    appId: '1:800083889966:ios:YOUR_IOS_APP_ID',
    messagingSenderId: '800083889966',
    projectId: 'dut-green-tracker-fixed',
    storageBucket: 'dut-green-tracker-fixed.firebasestorage.app',
    iosBundleId: 'com.dut.dutGreenTracker',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyA6pdXISQprDIDOLqg66JaYgeN_B_nLGt4',
    appId: '1:800083889966:web:YOUR_WEB_APP_ID',
    messagingSenderId: '800083889966',
    projectId: 'dut-green-tracker-fixed',
    authDomain: 'dut-green-tracker-fixed.firebaseapp.com',
    storageBucket: 'dut-green-tracker-fixed.firebasestorage.app',
  );
}
