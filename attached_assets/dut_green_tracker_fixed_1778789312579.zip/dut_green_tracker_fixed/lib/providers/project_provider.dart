import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/firebase_service.dart';
import '../models/project.dart';

final firebaseServiceProvider = Provider<FirebaseService>((ref) {
  return FirebaseService();
});

final projectStreamProvider = StreamProvider<List<Project>>((ref) {
  final firebaseService = ref.watch(firebaseServiceProvider);
  return firebaseService.getProjects();
});