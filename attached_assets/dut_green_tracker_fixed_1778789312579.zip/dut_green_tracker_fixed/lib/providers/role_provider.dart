import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/role_service.dart';

final roleServiceProvider = Provider((ref) => RoleService());

final roleProvider = FutureProvider.family((ref, String roleName) {
  return ref.read(roleServiceProvider).getRole(roleName);
});