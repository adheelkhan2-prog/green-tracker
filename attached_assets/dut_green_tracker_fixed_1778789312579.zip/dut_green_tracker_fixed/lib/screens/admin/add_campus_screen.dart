// ignore_for_file: deprecated_member_use, prefer_final_fields

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class AddCampusScreen extends StatefulWidget {
  const AddCampusScreen({super.key});

  @override
  State<AddCampusScreen> createState() => _AddCampusScreenState();
}

class _AddCampusScreenState extends State<AddCampusScreen> {
  final _nameController = TextEditingController();
  final _locationController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _contactEmailController = TextEditingController();
  final _contactPhoneController = TextEditingController();
  
  // Campus details
  String _selectedCampusType = 'Main Campus';
  final List<String> _campusTypes = [
    'Main Campus',
    'Steve Biko Campus',
    'Ritson Campus',
    'ML Sultan Campus',
    'City Campus',
    'Indumiso Campus',
    'Riverside Campus',
  ];
  
  // Facilities
  final List<String> _availableFacilities = [
    'Library',
    'Computer Lab',
    'Research Lab',
    'Sports Complex',
    'Auditorium',
    'Cafeteria',
    'Hostel',
    'Medical Center',
    'Transport Hub',
    'Innovation Lab',
  ];
  final List<String> _selectedFacilities = [];
  
  // Capacity
  int _studentCapacity = 1000;
  int _staffCount = 50;
  double _areaSize = 10.0; // in hectares
  
  // Status
  bool _isActive = true;
  Color _campusColor = Colors.blue;
  final List<Color> _availableColors = [
    Colors.blue, Colors.green, Colors.orange, Colors.purple,
    Colors.red, Colors.teal, Colors.indigo, Colors.pink,
  ];
  
  // Statistics
  int _totalProjectsCompleted = 0;
  double _averageSustainabilityScore = 0;
  
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _locationController.dispose();
    _descriptionController.dispose();
    _contactEmailController.dispose();
    _contactPhoneController.dispose();
    super.dispose();
  }

  Future<void> _saveCampus() async {
    if (_nameController.text.trim().isEmpty) {
      _showError('Please enter campus name');
      return;
    }
    
    if (_locationController.text.trim().isEmpty) {
      _showError('Please enter campus location');
      return;
    }

    setState(() => _isLoading = true);

    try {
      await FirebaseFirestore.instance.collection("campuses").add({
        "name": _nameController.text.trim(),
        "location": _locationController.text.trim(),
        "description": _descriptionController.text.trim(),
        "contactEmail": _contactEmailController.text.trim(),
        "contactPhone": _contactPhoneController.text.trim(),
        "campusType": _selectedCampusType,
        "facilities": _selectedFacilities,
        "studentCapacity": _studentCapacity,
        "staffCount": _staffCount,
        "areaSize": _areaSize,
        "isActive": _isActive,
        "color": _campusColor.value,
        "totalProjectsCompleted": _totalProjectsCompleted,
        "averageSustainabilityScore": _averageSustainabilityScore,
        "createdAt": FieldValue.serverTimestamp(),
        "updatedAt": FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Campus created successfully!')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _toggleFacility(String facility) {
    setState(() {
      if (_selectedFacilities.contains(facility)) {
        _selectedFacilities.remove(facility);
      } else {
        _selectedFacilities.add(facility);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Campuses"),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.list_alt),
            onPressed: () => _showCampusesList(),
            tooltip: 'View All Campuses',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.green.shade400, Colors.green.shade700],
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Add New Campus',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Register a new campus location',
                          style: TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Basic Information Section
                  _buildSectionHeader('Basic Information', Icons.info),
                  const SizedBox(height: 16),
                  
                  // Campus Name
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Campus Name *',
                      hintText: 'e.g., Durban University of Technology - Steve Biko Campus',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.school),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Campus Type Dropdown
                  DropdownButtonFormField<String>(
                    value: _selectedCampusType,
                    decoration: const InputDecoration(
                      labelText: 'Campus Type',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.category),
                    ),
                    items: _campusTypes.map((type) {
                      return DropdownMenuItem(
                        value: type,
                        child: Text(type),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() => _selectedCampusType = value!);
                    },
                  ),
                  const SizedBox(height: 16),

                  // Location
                  TextField(
                    controller: _locationController,
                    decoration: const InputDecoration(
                      labelText: 'Location *',
                      hintText: 'e.g., Steve Biko Road, Durban',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.location_on),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Description
                  TextField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Description',
                      hintText: 'Describe the campus facilities and features...',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.description),
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 24),

                  // Contact Information Section
                  _buildSectionHeader('Contact Information', Icons.contact_phone),
                  const SizedBox(height: 16),
                  
                  // Contact Email
                  TextField(
                    controller: _contactEmailController,
                    decoration: const InputDecoration(
                      labelText: 'Contact Email',
                      hintText: 'campus@dut.ac.za',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.email),
                    ),
                    keyboardType: TextInputType.emailAddress,
                  ),
                  const SizedBox(height: 16),

                  // Contact Phone
                  TextField(
                    controller: _contactPhoneController,
                    decoration: const InputDecoration(
                      labelText: 'Contact Phone',
                      hintText: '+27 31 123 4567',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.phone),
                    ),
                    keyboardType: TextInputType.phone,
                  ),
                  const SizedBox(height: 24),

                  // Facilities Section
                  _buildSectionHeader('Facilities', Icons.business),
                  const SizedBox(height: 8),
                  const Text(
                    'Select available facilities on this campus',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _availableFacilities.map((facility) {
                          final isSelected = _selectedFacilities.contains(facility);
                          return FilterChip(
                            label: Text(facility),
                            selected: isSelected,
                            onSelected: (_) => _toggleFacility(facility),
                            backgroundColor: Colors.grey.shade200,
                            selectedColor: Colors.green.shade100,
                            checkmarkColor: Colors.green,
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Capacity Section
                  _buildSectionHeader('Capacity & Statistics', Icons.people),
                  const SizedBox(height: 16),
                  
                  // Student Capacity
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Student Capacity',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.people, size: 20, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text('$_studentCapacity students'),
                              const Spacer(),
                              SizedBox(
                                width: 200,
                                child: Slider(
                                  value: _studentCapacity.toDouble(),
                                  min: 100,
                                  max: 20000,
                                  divisions: 199,
                                  label: '$_studentCapacity',
                                  onChanged: (value) {
                                    setState(() => _studentCapacity = value.toInt());
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Staff Count
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Staff Count',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.badge, size: 20, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text('$_staffCount staff members'),
                              const Spacer(),
                              SizedBox(
                                width: 200,
                                child: Slider(
                                  value: _staffCount.toDouble(),
                                  min: 10,
                                  max: 2000,
                                  divisions: 199,
                                  label: '$_staffCount',
                                  onChanged: (value) {
                                    setState(() => _staffCount = value.toInt());
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Area Size
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Campus Area',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.square_foot, size: 20, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text('${_areaSize.toStringAsFixed(1)} hectares'),
                              const Spacer(),
                              SizedBox(
                                width: 200,
                                child: Slider(
                                  value: _areaSize,
                                  min: 1,
                                  max: 100,
                                  divisions: 99,
                                  label: '${_areaSize.toStringAsFixed(1)} ha',
                                  onChanged: (value) {
                                    setState(() => _areaSize = value);
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Theme Section
                  _buildSectionHeader('Theme & Status', Icons.palette),
                  const SizedBox(height: 16),
                  
                  // Color Selection
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Campus Theme Color',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 12,
                            runSpacing: 12,
                            children: _availableColors.map((color) {
                              final isSelected = _campusColor == color;
                              return GestureDetector(
                                onTap: () => setState(() => _campusColor = color),
                                child: Container(
                                  width: 45,
                                  height: 45,
                                  decoration: BoxDecoration(
                                    color: color,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: isSelected ? Colors.black : Colors.transparent,
                                      width: 3,
                                    ),
                                  ),
                                  child: isSelected
                                      ? const Center(
                                          child: Icon(Icons.check, color: Colors.white, size: 20),
                                        )
                                      : null,
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Active Status
                  Card(
                    elevation: 2,
                    child: SwitchListTile(
                      value: _isActive,
                      onChanged: (value) => setState(() => _isActive = value),
                      title: const Text('Active Campus'),
                      subtitle: const Text('Inactive campuses won\'t appear in selection'),
                      activeColor: Colors.green,
                      secondary: Icon(
                        _isActive ? Icons.check_circle : Icons.cancel,
                        color: _isActive ? Colors.green : Colors.grey,
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Save Button
                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      onPressed: _saveCampus,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 3,
                      ),
                      child: const Text(
                        'Create Campus',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.green.shade100,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: Colors.green, size: 20),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  void _showCampusesList() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: const Text(
                'All Campuses',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('campuses')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  
                  final campuses = snapshot.data!.docs;
                  
                  if (campuses.isEmpty) {
                    return const Center(child: Text('No campuses yet'));
                  }
                  
                  return ListView.builder(
                    controller: scrollController,
                    itemCount: campuses.length,
                    itemBuilder: (context, index) {
                      final doc = campuses[index];
                      final data = doc.data() as Map<String, dynamic>;
                      final color = data['color'] != null 
                          ? Color(data['color']) 
                          : Colors.blue;
                      final facilities = data['facilities'] as List? ?? [];
                      
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: ExpansionTile(
                          leading: Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(Icons.school, color: color, size: 28),
                          ),
                          title: Text(
                            data['name'] ?? 'Unnamed',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(data['location'] ?? 'No location'),
                              if (data['studentCapacity'] != null)
                                Text(
                                  'Capacity: ${data['studentCapacity']} students',
                                  style: const TextStyle(fontSize: 12),
                                ),
                            ],
                          ),
                          trailing: data['isActive'] == true
                              ? const Chip(
                                  label: Text('Active'),
                                  backgroundColor: Colors.green,
                                  labelStyle: TextStyle(color: Colors.white, fontSize: 10),
                                )
                              : const Chip(
                                  label: Text('Inactive'),
                                  backgroundColor: Colors.grey,
                                  labelStyle: TextStyle(color: Colors.white, fontSize: 10),
                                ),
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (data['description'] != null && data['description'].isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(bottom: 8),
                                      child: Text(data['description']),
                                    ),
                                  const Text(
                                    'Facilities:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  Wrap(
                                    spacing: 4,
                                    children: facilities.map((f) => Chip(
                                      label: Text(f),
                                      backgroundColor: Colors.grey.shade200,
                                      visualDensity: VisualDensity.compact,
                                    )).toList(),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }
}