// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddProjectTypeScreen extends StatefulWidget {
  const AddProjectTypeScreen({super.key});

  @override
  State<AddProjectTypeScreen> createState() => _AddProjectTypeScreenState();
}

class _AddProjectTypeScreenState extends State<AddProjectTypeScreen> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  
  // Metrics configuration
  final Map<String, TextEditingController> _metricControllers = {};
  final List<String> _defaultMetrics = [
    'Environmental Impact',
    'Community Engagement',
    'Innovation Level',
    'Resource Efficiency',
    'Scalability',
  ];
  
  // Color selection
  Color _selectedColor = Colors.green;
  final List<Color> _availableColors = [
    Colors.green, Colors.blue, Colors.orange, Colors.purple,
    Colors.red, Colors.teal, Colors.indigo, Colors.pink,
    Colors.amber, Colors.cyan,
  ];
  
  // Additional fields
  bool _isActive = true;
  int _estimatedWeeks = 4;
  String _difficultyLevel = 'Intermediate';
  final List<String> _difficultyLevels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
  
  bool _isLoading = false;
  String? _selectedIcon;
  
  final List<String> _availableIcons = [
    '🌱', '🌳', '💡', '♻️', '🚰', '☀️', '💨', '🔋',
    '🏗️', '🏭', '🚲', '🗑️', '💧', '🌊', '🔥', '⚡',
    '📊', '🎯', '🏆', '🌟', '💚', '🤝', '📈', '🔬',
  ];

  @override
  void initState() {
    super.initState();
    _initializeMetricControllers();
  }

  void _initializeMetricControllers() {
    for (var metric in _defaultMetrics) {
      _metricControllers[metric] = TextEditingController(text: '50');
    }
  }

  Future<void> _saveProjectType() async {
    if (_nameController.text.trim().isEmpty) {
      _showError('Please enter a project type name');
      return;
    }

    setState(() => _isLoading = true);

    // Build metrics map
    final Map<String, double> metrics = {};
    for (var entry in _metricControllers.entries) {
      metrics[entry.key] = double.tryParse(entry.value.text) ?? 50;
    }

    try {
      await FirebaseFirestore.instance.collection("project_types").add({
        "name": _nameController.text.trim(),
        "description": _descriptionController.text.trim(),
        "icon": _selectedIcon ?? '🌱',
        "color": _selectedColor.value,
        "isActive": _isActive,
        "estimatedWeeks": _estimatedWeeks,
        "difficultyLevel": _difficultyLevel,
        "metrics": metrics,
        "createdAt": FieldValue.serverTimestamp(),
        "updatedAt": FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Project type created successfully!')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Project Types"),
        backgroundColor: Colors.green,
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.list_alt),
            onPressed: () => _showProjectTypesList(),
            tooltip: 'View All Types',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Colors.green, Colors.greenAccent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Create Project Type',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Define reusable project templates',
                          style: TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Basic Information Section
                  _buildSectionHeader('Basic Information', Icons.info_outline),
                  const SizedBox(height: 16),
                  
                  // Name
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Project Type Name *',
                      hintText: 'e.g., Solar Installation, Tree Planting',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.category),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Description
                  TextField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Description',
                      hintText: 'Describe this project type...',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.description),
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 16),

                  // Icon Selection
                  _buildIconSelector(),
                  const SizedBox(height: 16),

                  // Color Selection
                  _buildColorSelector(),
                  const SizedBox(height: 24),

                  // Duration Section
                  _buildSectionHeader('Duration', Icons.timer_outlined),
                  const SizedBox(height: 16),
                  
                  // Estimated Weeks Slider
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Estimated Duration',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.timer, size: 20, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text('$_estimatedWeeks weeks'),
                              const Spacer(),
                              SizedBox(
                                width: 200,
                                child: Slider(
                                  value: _estimatedWeeks.toDouble(),
                                  min: 1,
                                  max: 24,
                                  divisions: 23,
                                  label: '$_estimatedWeeks weeks',
                                  onChanged: (value) {
                                    setState(() => _estimatedWeeks = value.toInt());
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Difficulty Level
                  _buildSectionHeader('Difficulty', Icons.trending_up),
                  const SizedBox(height: 16),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Project Difficulty'),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 12,
                            runSpacing: 8,
                            children: _difficultyLevels.map((level) {
                              final isSelected = _difficultyLevel == level;
                              return FilterChip(
                                label: Text(level),
                                selected: isSelected,
                                onSelected: (selected) {
                                  setState(() => _difficultyLevel = level);
                                },
                                backgroundColor: Colors.grey.shade200,
                                selectedColor: Colors.green.shade100,
                                checkmarkColor: Colors.green,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Metrics Configuration Section
                  _buildSectionHeader('Success Metrics', Icons.assessment),
                  const SizedBox(height: 8),
                  const Text(
                    'Define how this project type will be measured',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  
                  ..._defaultMetrics.map((metric) => _buildMetricSlider(metric)),
                  const SizedBox(height: 24),

                  // Status Section
                  _buildSectionHeader('Status', Icons.toggle_on),
                  const SizedBox(height: 16),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: SwitchListTile(
                      value: _isActive,
                      onChanged: (value) => setState(() => _isActive = value),
                      title: const Text('Active Project Type'),
                      subtitle: const Text('Inactive types won\'t appear in selection'),
                      activeColor: Colors.green,
                      secondary: Icon(
                        _isActive ? Icons.check_circle : Icons.cancel,
                        color: _isActive ? Colors.green : Colors.grey,
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Save Button
                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      onPressed: _saveProjectType,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 3,
                      ),
                      child: const Text(
                        'Create Project Type',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.green.shade100,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: Colors.green, size: 20),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildIconSelector() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Project Icon',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: _availableIcons.map((icon) {
                final isSelected = _selectedIcon == icon;
                return GestureDetector(
                  onTap: () => setState(() => _selectedIcon = icon),
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.green.shade100 : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? Colors.green : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        icon,
                        style: const TextStyle(fontSize: 28),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorSelector() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Theme Color',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: _availableColors.map((color) {
                final isSelected = _selectedColor == color;
                return GestureDetector(
                  onTap: () => setState(() => _selectedColor = color),
                  child: Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isSelected ? Colors.black : Colors.transparent,
                        width: 3,
                      ),
                    ),
                    child: isSelected
                        ? const Center(
                            child: Icon(Icons.check, color: Colors.white, size: 20),
                          )
                        : null,
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricSlider(String metric) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  metric,
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${_metricControllers[metric]?.text ?? '50'}%',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            Slider(
              value: double.tryParse(_metricControllers[metric]?.text ?? '50') ?? 50,
              min: 0,
              max: 100,
              divisions: 10,
              label: '${_metricControllers[metric]?.text}%',
              onChanged: (value) {
                setState(() {
                  _metricControllers[metric]?.text = value.toInt().toString();
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showProjectTypesList() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: const Text(
                'Existing Project Types',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('project_types')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  
                  final types = snapshot.data!.docs;
                  
                  if (types.isEmpty) {
                    return const Center(child: Text('No project types yet'));
                  }
                  
                  return ListView.builder(
                    controller: scrollController,
                    itemCount: types.length,
                    itemBuilder: (context, index) {
                      final doc = types[index];
                      final data = doc.data() as Map<String, dynamic>;
                      final color = data['color'] != null 
                          ? Color(data['color']) 
                          : Colors.green;
                      final icon = data['icon'] ?? '🌱';
                      
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: ListTile(
                          leading: Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(icon, style: const TextStyle(fontSize: 24)),
                            ),
                          ),
                          title: Text(data['name'] ?? 'Unnamed'),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (data['description'] != null && data['description'].isNotEmpty)
                                Text(
                                  data['description'],
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12),
                                ),
                              const SizedBox(height: 4),
                              Text(
                                '${data['estimatedWeeks'] ?? 4} weeks',
                                style: const TextStyle(fontSize: 11, color: Colors.grey),
                              ),
                            ],
                          ),
                          trailing: data['isActive'] == true
                              ? const Chip(
                                  label: Text('Active'),
                                  backgroundColor: Colors.green,
                                  labelStyle: TextStyle(color: Colors.white, fontSize: 10),
                                )
                              : const Chip(
                                  label: Text('Inactive'),
                                  backgroundColor: Colors.grey,
                                  labelStyle: TextStyle(color: Colors.white, fontSize: 10),
                                ),
                          onTap: () => Navigator.pop(context),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    for (var controller in _metricControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }
}