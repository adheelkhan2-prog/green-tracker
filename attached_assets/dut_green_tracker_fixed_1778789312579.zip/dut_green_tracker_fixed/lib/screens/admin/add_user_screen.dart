// lib/screens/admin/add_user_screen.dart
// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddUserScreen extends StatefulWidget {
  const AddUserScreen({super.key});

  @override
  State<AddUserScreen> createState() => _AddUserScreenState();
}

class _AddUserScreenState extends State<AddUserScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  
  String role = "student";
  String? campusId;
  String? department;  // NEW
  String? faculty;     // NEW

  final roles = ["admin", "lecturer", "student", "staff", "external"];
  
  // NEW: Departments list
  final List<String> departments = [
    "Computer Science",
    "Information Technology",
    "Community Health Studies",
    "Biotechnology & Food Science",
    "Horticulture",
    "Mechanical Engineering",
    "Electrical Engineering",
    "Civil Engineering",
    "Business Management",
    "Accounting",
    "Marketing",
    "Communications",
    "Other",
  ];
  
  // NEW: Faculties list
  final List<String> faculties = [
    "Faculty of Applied Sciences",
    "Faculty of Accounting & Informatics",
    "Faculty of Engineering & the Built Environment",
    "Faculty of Health Sciences",
    "Faculty of Management Sciences",
    "Faculty of Arts & Design",
    "Other",
  ];

  bool loading = false;

  Future<void> createUser() async {
    if (nameController.text.trim().isEmpty) {
      _showError("Please enter name");
      return;
    }
    if (emailController.text.trim().isEmpty) {
      _showError("Please enter email");
      return;
    }
    if (passwordController.text.trim().length < 6) {
      _showError("Password must be at least 6 characters");
      return;
    }
    if (campusId == null) {
      _showError("Please select a campus");
      return;
    }
    if (department == null) {
      _showError("Please select a department");
      return;
    }
    if (faculty == null) {
      _showError("Please select a faculty");
      return;
    }

    setState(() => loading = true);

    try {
      // 1. CREATE AUTH USER
      final cred = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      final uid = cred.user!.uid;

      // 2. SAVE FIRESTORE USER with department and faculty
      await FirebaseFirestore.instance.collection("users").doc(uid).set({
        "name": nameController.text.trim(),
        "email": emailController.text.trim(),
        "role": role,
        "campusId": campusId,
        "department": department,   // NEW
        "faculty": faculty,         // NEW
        "createdAt": FieldValue.serverTimestamp(),
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("User created successfully")),
      );

      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => loading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add User"),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: "Full Name *",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: "Email *",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.email),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: "Password * (min 6 characters)",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.lock),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: role,
              items: roles.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
              onChanged: (value) => setState(() => role = value!),
              decoration: const InputDecoration(
                labelText: "Role *",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.badge),
              ),
            ),
            const SizedBox(height: 16),
            // NEW: Department Dropdown
            DropdownButtonFormField<String>(
              value: department,
              hint: const Text("Select Department *"),
              items: departments.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
              onChanged: (value) => setState(() => department = value),
              decoration: const InputDecoration(
                labelText: "Department *",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.business),
              ),
            ),
            const SizedBox(height: 16),
            // NEW: Faculty Dropdown
            DropdownButtonFormField<String>(
              value: faculty,
              hint: const Text("Select Faculty *"),
              items: faculties.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
              onChanged: (value) => setState(() => faculty = value),
              decoration: const InputDecoration(
                labelText: "Faculty *",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.school),
              ),
            ),
            const SizedBox(height: 16),
            // Campus Dropdown
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('campuses').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }
                final campuses = snapshot.data!.docs;
                return DropdownButtonFormField<String>(
                  value: campusId,
                  hint: const Text("Select Campus *"),
                  items: campuses.map((doc) {
                    return DropdownMenuItem(
                      value: doc.id,
                      child: Text(doc['name']),
                    );
                  }).toList(),
                  onChanged: (value) => setState(() => campusId = value),
                  decoration: const InputDecoration(
                    labelText: "Campus *",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.location_city),
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: loading ? null : createUser,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("Create User", style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}