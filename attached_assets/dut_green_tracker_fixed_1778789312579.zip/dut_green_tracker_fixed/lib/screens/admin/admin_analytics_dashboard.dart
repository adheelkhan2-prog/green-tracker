import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';

class AdminAnalyticsDashboard extends StatelessWidget {
  const AdminAnalyticsDashboard({super.key});

  // =========================
  // STREAM: PROJECT DATA
  // =========================
  Stream<QuerySnapshot> getProjects() {
    return FirebaseFirestore.instance.collection("projects").snapshots();
  }

  // =========================
  // PIE DATA
  // =========================
  Stream<Map<String, int>> getStatusData() {
    return FirebaseFirestore.instance.collection("projects").snapshots().map(
      (snapshot) {
        int active = 0;
        int completed = 0;

        for (var doc in snapshot.docs) {
          final status = doc['status'];

          if (status == "Active") active++;
          if (status == "Completed") completed++;
        }

        return {
          "Active": active,
          "Completed": completed,
        };
      },
    );
  }

  // =========================
  // CAMPUS DATA
  // =========================
  Stream<Map<String, int>> getCampusData() {
    return FirebaseFirestore.instance.collection("projects").snapshots().map(
      (snapshot) {
        Map<String, int> map = {};

        for (var doc in snapshot.docs) {
          final campus = doc['campusId'] ?? "Unknown";
          map[campus] = (map[campus] ?? 0) + 1;
        }

        return map;
      },
    );
  }

  // =========================
  // LECTURER DATA
  // =========================
  Stream<Map<String, int>> getLecturerData() {
    return FirebaseFirestore.instance.collection("projects").snapshots().map(
      (snapshot) {
        Map<String, int> map = {};

        for (var doc in snapshot.docs) {
          final lecturer = doc['lecturerId'] ?? "Unassigned";
          map[lecturer] = (map[lecturer] ?? 0) + 1;
        }

        return map;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Admin Analytics Dashboard"),
        backgroundColor: Colors.green,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // =========================
            // PIE CHART
            // =========================
            const Text(
              "Project Status",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),

            StreamBuilder<Map<String, int>>(
              stream: getStatusData(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                final data = snapshot.data!;

                return SizedBox(
                  height: 250,
                  child: PieChart(
                    PieChartData(
                      sections: [
                        PieChartSectionData(
                          value: data["Active"]!.toDouble(),
                          title: "Active",
                          color: Colors.orange,
                          radius: 60,
                        ),
                        PieChartSectionData(
                          value: data["Completed"]!.toDouble(),
                          title: "Completed",
                          color: Colors.green,
                          radius: 60,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 30),

            // =========================
            // CAMPUS BAR CHART
            // =========================
            const Text(
              "Projects per Campus",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),

            StreamBuilder<Map<String, int>>(
              stream: getCampusData(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                final data = snapshot.data!;
                final keys = data.keys.toList();

                return SizedBox(
                  height: 250,
                  child: BarChart(
                    BarChartData(
                      barGroups: List.generate(keys.length, (i) {
                        final value = data[keys[i]]!.toDouble();

                        return BarChartGroupData(
                          x: i,
                          barRods: [
                            BarChartRodData(
                              toY: value,
                              width: 18,
                              color: Colors.blue,
                            ),
                          ],
                        );
                      }),
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 30),

            // =========================
            // CAMPUS LIST
            // =========================
            const Text(
              "Campus Overview",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            StreamBuilder<Map<String, int>>(
              stream: getCampusData(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                final data = snapshot.data!;

                return Column(
                  children: data.entries.map((e) {
                    return ListTile(
                      leading: const Icon(Icons.school),
                      title: Text("Campus: ${e.key}"),
                      trailing: Text("${e.value} projects"),
                    );
                  }).toList(),
                );
              },
            ),

            const SizedBox(height: 20),

            // =========================
            // LECTURER ANALYTICS
            // =========================
            const Text(
              "Lecturer Workload",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            StreamBuilder<Map<String, int>>(
              stream: getLecturerData(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                final data = snapshot.data!;

                return Column(
                  children: data.entries.map((e) {
                    return ListTile(
                      leading: const Icon(Icons.person),
                      title: Text("Lecturer: ${e.key}"),
                      trailing: Text("${e.value} projects"),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}