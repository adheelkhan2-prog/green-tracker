// ignore_for_file: sort_child_properties_last, use_build_context_synchronously, prefer_const_declarations, deprecated_member_use, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'add_campus_screen.dart';
import 'add_project_type_screen.dart';
import 'create_team_screen.dart';
import '../projects/add_project_screen.dart';
import '../projects/projects_list_screen.dart';
import '../team/assign_team_screen.dart';
import '../team/team_availability_screen.dart';
import '../ai_suggestions_screen.dart';
import '../ai/ai_analysis_screen.dart';
import '../ai/impact_prediction_screen.dart';
import '../analytics_dashboard.dart';
import 'user_list_screen.dart';
import 'assign_members_screen.dart';
import 'workload_limits_screen.dart';
import '../dashboards/notifications_screen.dart';
import '../../services/ai_service.dart';
import 'admin_weekly_summary.dart';
import '../ai/ai_chatbot_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Admin Panel"),
        backgroundColor: Colors.green,
        centerTitle: false,
        actions: [
          // AI Chatbot Button
          IconButton(
            icon: const Icon(Icons.chat),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AIChatbotScreen(),
                ),
              );
            },
            tooltip: 'AI Assistant',
          ),
          
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('notifications')
                .where('userId', isEqualTo: currentUser?.uid)
                .where('isRead', isEqualTo: false)
                .snapshots(),
            builder: (context, snapshot) {
              final unreadCount = snapshot.data?.docs.length ?? 0;
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const NotificationsScreen(),
                        ),
                      );
                    },
                  ),
                  if (unreadCount > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          unreadCount > 9 ? '9+' : '$unreadCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle),
            onSelected: (value) async {
              if (value == 'profile') {
                _showProfileDialog(context);
              } else if (value == 'logout') {
                await _showLogoutDialog(context);
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person, size: 20),
                    SizedBox(width: 12),
                    Text('Profile'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, size: 20, color: Colors.red),
                    SizedBox(width: 12),
                    Text('Logout', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {},
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Colors.green, Colors.greenAccent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white,
                      child: const Icon(Icons.admin_panel_settings, color: Colors.green, size: 30),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Admin Dashboard',
                            style: TextStyle(color: Colors.white70, fontSize: 14),
                          ),
                          Text(
                            'Welcome, ${currentUser?.email?.split('@').first ?? 'Admin'}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Stats Row
              Row(
                children: [
                  Expanded(
                    child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance.collection('projects').snapshots(),
                      builder: (context, snapshot) {
                        final count = snapshot.data?.docs.length ?? 0;
                        return _buildStatCard('Total Projects', count.toString(), Icons.folder, Colors.blue);
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('projects')
                          .where('status', isEqualTo: 'Active')
                          .snapshots(),
                      builder: (context, snapshot) {
                        final count = snapshot.data?.docs.length ?? 0;
                        return _buildStatCard('Active Projects', count.toString(), Icons.play_circle, Colors.green);
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance.collection('users').snapshots(),
                      builder: (context, snapshot) {
                        final count = snapshot.data?.docs.length ?? 0;
                        return _buildStatCard('Total Users', count.toString(), Icons.people, Colors.purple);
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('projects')
                          .snapshots(),
                      builder: (context, snapshot) {
                        final allProjects = snapshot.data?.docs.length ?? 0;
                        return StreamBuilder<QuerySnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('projects')
                              .where('status', isEqualTo: 'Completed')
                              .snapshots(),
                          builder: (context, completedSnapshot) {
                            final completedCount = completedSnapshot.data?.docs.length ?? 0;
                            final completionRate = allProjects > 0 ? (completedCount / allProjects * 100).toInt() : 0;
                            return _buildStatCard('Completion Rate', '$completionRate%', Icons.trending_up, Colors.orange);
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Quick Actions Section
              const Text(
                'Quick Actions',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  _buildActionChip(Icons.add, 'Add Project', Colors.green, () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const AddProjectScreen()));
                  }),
                  _buildActionChip(Icons.person_add, 'Add User', Colors.orange, () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const UserListScreen()));
                  }),
                  _buildActionChip(Icons.analytics, 'Analytics', Colors.purple, () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalyticsDashboard()));
                  }),
                  _buildActionChip(Icons.calendar_month, 'Weekly Summary', Colors.teal, () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminWeeklySummary()));
                  }),
                ],
              ),
              const SizedBox(height: 24),

              // Projects Section
              _buildSectionHeader('Projects', Icons.folder, () {}),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildHorizontalCard('View All Projects', Icons.list, Colors.blue, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ProjectListScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Add New Project', Icons.add, Colors.green, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AddProjectScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Project Types', Icons.category, Colors.orange, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AddProjectTypeScreen()));
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Teams Section
              _buildSectionHeader('Teams', Icons.group, () {}),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildHorizontalCard('Create Team', Icons.group_add, Colors.green, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateTeamScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Assign Members', Icons.person_add, Colors.blue, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AssignMembersScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Assign to Project', Icons.assignment_ind, Colors.orange, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AssignTeamScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Team Availability', Icons.people_outline, Colors.purple, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const TeamAvailabilityScreen()));
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Management Section
              _buildSectionHeader('Management', Icons.settings, () {}),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildHorizontalCard('Manage Users', Icons.people, Colors.blue, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const UserListScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Manage Campuses', Icons.school, Colors.green, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCampusScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Workload Limits', Icons.speed, Colors.orange, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const WorkloadLimitsScreen()));
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // AI Section
              _buildSectionHeader('AI Assistant', Icons.auto_awesome, () {}),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildHorizontalCard('Test AI', Icons.science, Colors.red, () async {
                      final isWorking = await AIService.testConnection();
                      if (isWorking) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('✅ AI is working!'), backgroundColor: Colors.green),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('❌ AI connection failed. Check API key.'), backgroundColor: Colors.red),
                        );
                      }
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('AI Analysis', Icons.analytics, Colors.purple, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AIAnalysisScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Impact Prediction', Icons.trending_up, Colors.green, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ImpactPredictionScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('AI Suggestions', Icons.psychology, Colors.orange, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AISuggestionsScreen()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Analytics', Icons.bar_chart, Colors.blue, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalyticsDashboard()));
                    }),
                    const SizedBox(width: 12),
                    _buildHorizontalCard('Weekly Summary', Icons.calendar_month, Colors.teal, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminWeeklySummary()));
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        child: const Icon(Icons.chat, color: Colors.white),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AIChatbotScreen(),
            ),
          );
        },
        tooltip: 'Ask AI Assistant',
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.folder),
            label: 'Projects',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people),
            label: 'Teams',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ProjectListScreen()));
          } else if (index == 2) {
            // Navigate to Teams
          } else if (index == 3) {
            _showProfileDialog(context);
          }
        },
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
                  ),
                  Text(
                    title,
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionChip(IconData icon, String label, Color color, VoidCallback onTap) {
    return ActionChip(
      avatar: Icon(icon, size: 16, color: color),
      label: Text(label),
      onPressed: onTap,
      backgroundColor: color.withOpacity(0.1),
      side: BorderSide(color: color.withOpacity(0.3)),
    );
  }

  Widget _buildHorizontalCard(String title, IconData icon, Color color, VoidCallback onTap) {
    return Container(
      width: 160,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade100,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, VoidCallback onSeeAll) {
    return Row(
      children: [
        Icon(icon, color: Colors.green, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        TextButton(
          onPressed: onSeeAll,
          child: const Text(
            'See All',
            style: TextStyle(color: Colors.green),
          ),
        ),
      ],
    );
  }

  Future<void> _showLogoutDialog(BuildContext context) async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (shouldLogout == true) {
      await FirebaseAuth.instance.signOut();
      if (context.mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      }
    }
  }

  void _showProfileDialog(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser?.uid)
            .get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!.data() as Map<String, dynamic>;
          return AlertDialog(
            title: const Text('Admin Profile'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(data['name'] ?? 'Admin'),
                  subtitle: const Text('Name'),
                ),
                ListTile(
                  leading: const Icon(Icons.email),
                  title: Text(data['email'] ?? currentUser?.email ?? 'No email'),
                  subtitle: const Text('Email'),
                ),
                ListTile(
                  leading: const Icon(Icons.admin_panel_settings),
                  title: const Text('Administrator'),
                  subtitle: const Text('Role'),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
  }
}
