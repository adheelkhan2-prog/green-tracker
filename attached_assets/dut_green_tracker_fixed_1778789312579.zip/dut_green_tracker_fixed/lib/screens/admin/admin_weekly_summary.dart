// lib/screens/admin/admin_weekly_summary.dart
// ignore_for_file: prefer_const_constructors, unnecessary_brace_in_string_interps, use_build_context_synchronously, deprecated_member_use, unused_field, prefer_final_fields

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/weekly_update_service.dart';
import '../../services/ai_service.dart';

class AdminWeeklySummary extends StatefulWidget {
  const AdminWeeklySummary({super.key});

  @override
  State<AdminWeeklySummary> createState() => _AdminWeeklySummaryState();
}

class _AdminWeeklySummaryState extends State<AdminWeeklySummary> {
  final WeeklyUpdateService _service = WeeklyUpdateService();
  String _selectedUpdateId = '';
  final _feedbackController = TextEditingController();
  String _selectedStatus = 'approved';
  
  // AI Summary
  String _aiSummary = '';
  bool _isGeneratingSummary = false;
  bool _summaryGenerated = false;
  
  // Stats
  int _totalProjects = 0;
  int _totalUsers = 0;
  int _completedTasks = 0;
  int _pendingTasks = 0;
  int _overdueTasks = 0;
  List<Map<String, dynamic>> _projects = [];
  List<Map<String, dynamic>> _weeklyUpdates = [];

  @override
  void initState() {
    super.initState();
    _loadStats();
  }
  
  @override
  void dispose() {
    _feedbackController.dispose();
    super.dispose();
  }
  
  Future<void> _loadStats() async {
    // Load projects
    final projectsSnapshot = await FirebaseFirestore.instance
        .collection('projects')
        .get();
    
    _projects = projectsSnapshot.docs.map((doc) {
      final data = doc.data();
      return {
        'id': doc.id,
        'title': data['title'] ?? 'Untitled',
        'progress': data['progress'] ?? 0,
        'status': data['status'] ?? 'pending',
        'sustainabilityScore': data['sustainabilityScore'] ?? 0,
      };
    }).toList();
    _totalProjects = _projects.length;
    
    // Load users
    final usersSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .get();
    _totalUsers = usersSnapshot.docs.length;
    
    // Load tasks stats
    final tasksSnapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .get();
    
    for (var doc in tasksSnapshot.docs) {
      final data = doc.data();
      final progress = data['progress'] ?? 0;
      final deadline = (data['deadline'] as Timestamp?)?.toDate();
      
      if (progress == 100) {
        _completedTasks++;
      } else if (progress > 0) {
        _pendingTasks++;
      }
      
      if (deadline != null && deadline.isBefore(DateTime.now()) && progress < 100) {
        _overdueTasks++;
      }
    }
    
    // Load weekly updates
    final updatesSnapshot = await FirebaseFirestore.instance
        .collection('weekly_updates')
        .orderBy('submittedAt', descending: true)
        .limit(10)
        .get();
    
    _weeklyUpdates = updatesSnapshot.docs.map((doc) {
      final data = doc.data();
      return {
        'id': doc.id,
        'projectTitle': data['projectTitle'] ?? '',
        'weekNumber': data['weekNumber'] ?? 1,
        'progressSummary': data['progressSummary'] ?? '',
        'achievements': data['achievements'] ?? '',
        'status': data['status'] ?? 'pending',
      };
    }).toList();
    
    setState(() {});
  }
  
  Future<void> _generateAISummary() async {
    setState(() {
      _isGeneratingSummary = true;
      _summaryGenerated = false;
    });
    
    try {
      final summary = await AIService.generateWeeklySummary(
        projects: _projects,
        tasks: [], // Tasks data is passed via stats
        weeklyUpdates: _weeklyUpdates,
        totalUsers: _totalUsers,
        completedTasks: _completedTasks,
        pendingTasks: _pendingTasks,
        overdueTasks: _overdueTasks,
      );
      
      setState(() {
        _aiSummary = summary;
        _isGeneratingSummary = false;
        _summaryGenerated = true;
      });
    } catch (e) {
      setState(() {
        _aiSummary = 'Error generating summary: $e';
        _isGeneratingSummary = false;
      });
    }
  }
  
  void _showReviewDialog(WeeklyUpdate update) {
    _feedbackController.text = update.adminFeedback ?? '';
    _selectedStatus = update.status == 'reviewed' ? 'approved' : update.status;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Review: ${update.projectTitle}'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _feedbackController,
                decoration: const InputDecoration(
                  hintText: 'Enter feedback for the team leader...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _selectedStatus,
                decoration: const InputDecoration(labelText: 'Status'),
                items: const [
                  DropdownMenuItem(value: 'approved', child: Text('✅ Approved')),
                  DropdownMenuItem(value: 'flagged', child: Text('⚠️ Flag for Follow-up')),
                ],
                onChanged: (v) => setState(() => _selectedStatus = v!),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              await _service.reviewWeeklyUpdate(
                update.id,
                _feedbackController.text,
                _selectedStatus,
              );
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Review submitted!'),
                    backgroundColor: Colors.green,
                  ),
                );
                Navigator.pop(context);
                _loadStats(); // Refresh data
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text('Submit Review'),
          ),
        ],
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Weekly Updates'),
          backgroundColor: Colors.green,
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Pending', icon: Icon(Icons.pending)),
              Tab(text: 'All Updates', icon: Icon(Icons.history)),
              Tab(text: 'AI Summary', icon: Icon(Icons.auto_awesome)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Pending Updates Tab
            _buildPendingUpdatesTab(),
            
            // All Updates Tab
            _buildAllUpdatesTab(),
            
            // AI Summary Tab
            _buildAISummaryTab(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildPendingUpdatesTab() {
    return StreamBuilder<List<WeeklyUpdate>>(
      stream: _service.getPendingWeeklyUpdates(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.check_circle, size: 64, color: Colors.green),
                SizedBox(height: 16),
                Text('No pending updates'),
                SizedBox(height: 8),
                Text('All weekly updates have been reviewed'),
              ],
            ),
          );
        }
        
        final updates = snapshot.data!;
        
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: updates.length,
          itemBuilder: (context, index) {
            final update = updates[index];
            return _buildUpdateCard(update, isPending: true);
          },
        );
      },
    );
  }
  
  Widget _buildAllUpdatesTab() {
    return StreamBuilder<List<WeeklyUpdate>>(
      stream: _service.getAllWeeklyUpdates(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.history, size: 64, color: Colors.grey),
                SizedBox(height: 16),
                Text('No updates yet'),
              ],
            ),
          );
        }
        
        final updates = snapshot.data!;
        
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: updates.length,
          itemBuilder: (context, index) {
            final update = updates[index];
            return _buildUpdateCard(update, isPending: update.status == 'pending');
          },
        );
      },
    );
  }
  
  Widget _buildAISummaryTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Stats Cards
          Row(
            children: [
              _buildStatCard('Projects', _totalProjects.toString(), Icons.folder, Colors.blue),
              const SizedBox(width: 12),
              _buildStatCard('Users', _totalUsers.toString(), Icons.people, Colors.purple),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildStatCard('Tasks Done', _completedTasks.toString(), Icons.check_circle, Colors.green),
              const SizedBox(width: 12),
              _buildStatCard('Overdue', _overdueTasks.toString(), Icons.warning, Colors.red),
            ],
          ),
          const SizedBox(height: 20),
          
          // Generate Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isGeneratingSummary ? null : _generateAISummary,
              icon: _isGeneratingSummary
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_awesome),
              label: Text(_isGeneratingSummary ? 'Generating Summary...' : 'Generate AI Weekly Summary'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 20),
          
          // AI Summary Result
          if (_summaryGenerated || _aiSummary.isNotEmpty)
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.green.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.auto_awesome, color: Colors.green, size: 28),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'AI Generated Report',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Divider(),
                    const SizedBox(height: 16),
                    
                    // Summary content
                    if (_isGeneratingSummary)
                      const Center(
                        child: Column(
                          children: [
                            CircularProgressIndicator(),
                            SizedBox(height: 16),
                            Text('AI is analyzing project data...'),
                          ],
                        ),
                      )
                    else
                      Text(
                        _aiSummary,
                        style: const TextStyle(height: 1.6),
                      ),
                    
                    const SizedBox(height: 20),
                    
                    // Export Button
                    if (_summaryGenerated && _aiSummary.isNotEmpty)
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            _showExportOptions();
                          },
                          icon: const Icon(Icons.share),
                          label: const Text('Share Report'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.green,
                            side: const BorderSide(color: Colors.green),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                    
                    const SizedBox(height: 8),
                    
                    // Info note
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info, color: Colors.blue.shade700),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'This summary is generated based on ${_totalProjects} projects, ${_weeklyUpdates.length} weekly updates, and current task status.',
                              style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          
          // Empty state
          if (!_summaryGenerated && _aiSummary.isEmpty && !_isGeneratingSummary)
            Card(
              elevation: 2,
              color: Colors.grey.shade50,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  children: [
                    Icon(Icons.auto_awesome, size: 64, color: Colors.grey.shade400),
                    const SizedBox(height: 16),
                    const Text(
                      'Ready to generate weekly summary',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Click the button above to generate an AI-powered\nsummary of all project activities this week.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
  
  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 16),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color),
                  ),
                  Text(
                    title,
                    style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildUpdateCard(WeeklyUpdate update, {required bool isPending}) {
    final statusColor = update.status == 'approved' 
        ? Colors.green 
        : (update.status == 'flagged' ? Colors.orange : Colors.grey);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: isPending ? 3 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isPending
            ? BorderSide(color: Colors.orange.shade300, width: 1.5)
            : BorderSide.none,
      ),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: statusColor.withOpacity(0.1),
          child: Icon(Icons.description, color: statusColor),
        ),
        title: Text(
          update.projectTitle,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Week ${update.weekNumber}, ${update.year}'),
            if (update.status != 'pending')
              Chip(
                label: Text(update.status),
                backgroundColor: statusColor.withOpacity(0.1),
                labelStyle: TextStyle(color: statusColor, fontSize: 10),
                padding: EdgeInsets.zero,
              ),
          ],
        ),
        trailing: isPending
            ? ElevatedButton(
                onPressed: () => _showReviewDialog(update),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
                child: const Text('Review'),
              )
            : null,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSection('📊 Progress Summary', update.progressSummary),
                const SizedBox(height: 12),
                _buildSection('🏆 Achievements', update.achievements),
                const SizedBox(height: 12),
                if (update.challenges.isNotEmpty)
                  _buildSection('⚠️ Challenges', update.challenges),
                const SizedBox(height: 12),
                _buildSection('📅 Next Week Plan', update.nextWeekPlan),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _buildStatChip('Completed', update.tasksCompleted, Colors.green),
                    const SizedBox(width: 8),
                    _buildStatChip('In Progress', update.tasksInProgress, Colors.orange),
                    const SizedBox(width: 8),
                    _buildStatChip('Blocked', update.tasksBlocked, Colors.red),
                  ],
                ),
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: update.currentProgress / 100,
                  backgroundColor: Colors.grey.shade200,
                  valueColor: AlwaysStoppedAnimation(Colors.green),
                  minHeight: 8,
                ),
                const SizedBox(height: 8),
                Text('Progress: ${update.currentProgress.toInt()}%'),
                
                if (update.adminFeedback != null && update.adminFeedback!.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '📝 Admin Feedback:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(update.adminFeedback!),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(content),
      ],
    );
  }
  
  Widget _buildStatChip(String label, int value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text('$label: $value', style: TextStyle(fontSize: 11, color: color)),
    );
  }
  
  void _showExportOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text('Export Report', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Choose how to share the AI summary'),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.copy, color: Colors.blue),
              title: const Text('Copy to Clipboard'),
              onTap: () {
                Navigator.pop(context);
                _copyToClipboard();
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('Share as Text'),
              onTap: () {
                Navigator.pop(context);
                _shareSummary();
              },
            ),
          ],
        ),
      ),
    );
  }
  
  void _copyToClipboard() {
    // Implement copy functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Report copied to clipboard!'), backgroundColor: Colors.green),
    );
  }
  
  void _shareSummary() {
    // Implement share functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Share feature coming soon!'), backgroundColor: Colors.orange),
    );
  }
}