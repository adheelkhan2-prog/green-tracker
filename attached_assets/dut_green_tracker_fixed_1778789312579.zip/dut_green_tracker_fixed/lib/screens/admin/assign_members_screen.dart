// ignore_for_file: unused_field, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/unified_notification_service.dart';

class AssignMembersScreen extends StatefulWidget {
  const AssignMembersScreen({super.key});

  @override
  State<AssignMembersScreen> createState() => _AssignMembersScreenState();
}

class _AssignMembersScreenState extends State<AssignMembersScreen> {
  String? _selectedTeamId;
  List<Map<String, dynamic>> _teams = [];
  List<String> _currentMembers = [];
  List<String> _selectedNewMembers = [];
  bool _isLoading = false;
  
  // Department filtering
  String? _projectDepartment;
  String? _projectVisibility;
  String? _teamProjectId;
  String? _teamName;

  @override
  void initState() {
    super.initState();
    _loadTeams();
  }

  Future<void> _loadTeams() async {
    setState(() => _isLoading = true);
    final snapshot = await FirebaseFirestore.instance.collection('teams').get();
    
    // Load teams with their associated project info
    final List<Map<String, dynamic>> teamsWithProject = [];
    
    for (var doc in snapshot.docs) {
      final teamData = doc.data();
      final teamId = doc.id;
      
      // Find which project this team is assigned to
      final projectQuery = await FirebaseFirestore.instance
          .collection('projects')
          .where('teamId', isEqualTo: teamId)
          .limit(1)
          .get();
      
      String? projectId;
      String? department;
      String? visibility;
      String? projectTitle;
      
      if (projectQuery.docs.isNotEmpty) {
        final projectData = projectQuery.docs.first.data();
        projectId = projectQuery.docs.first.id;
        department = projectData['department'];
        visibility = projectData['visibility'] ?? 'open';
        projectTitle = projectData['title'] ?? 'Project';
      }
      
      teamsWithProject.add({
        'id': teamId,
        'name': teamData['name'] ?? 'Unnamed',
        'memberIds': List<String>.from(teamData['memberIds'] ?? []),
        'maxMembers': teamData['maxMembers'] ?? 5,
        'projectId': projectId,
        'projectDepartment': department,
        'projectVisibility': visibility,
        'projectTitle': projectTitle,
      });
    }
    
    setState(() {
      _teams = teamsWithProject;
      _isLoading = false;
    });
  }

  Future<void> _loadTeamMembers(String teamId) async {
    final team = _teams.firstWhere((t) => t['id'] == teamId);
    setState(() {
      _currentMembers = List<String>.from(team['memberIds']);
      _selectedNewMembers = [];
      _teamProjectId = team['projectId'];
      _projectDepartment = team['projectDepartment'];
      _projectVisibility = team['projectVisibility'];
      _teamName = team['name'];
    });
  }

  Future<void> _assignMembers() async {
    if (_selectedTeamId == null) {
      _showError('Please select a team');
      return;
    }

    if (_selectedNewMembers.isEmpty) {
      _showError('Please select at least one member to add');
      return;
    }

    final team = _teams.firstWhere((t) => t['id'] == _selectedTeamId);
    final currentCount = team['memberIds'].length;
    final maxMembers = team['maxMembers'];
    final projectTitle = team['projectTitle'] ?? 'the project';
    
    if (currentCount + _selectedNewMembers.length > maxMembers) {
      _showError('Cannot add ${_selectedNewMembers.length} members. Team max is $maxMembers (currently $currentCount)');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final updatedMembers = [..._currentMembers, ..._selectedNewMembers];
      
      await FirebaseFirestore.instance
          .collection('teams')
          .doc(_selectedTeamId)
          .update({
        'memberIds': updatedMembers,
      });

      // Also update the project's members list if this team is assigned to a project
      if (_teamProjectId != null && _teamProjectId!.isNotEmpty) {
        await FirebaseFirestore.instance
            .collection('projects')
            .doc(_teamProjectId)
            .update({
          'members': FieldValue.arrayUnion(_selectedNewMembers),
        });
      }

      // Send notifications to new members using UnifiedNotificationService
      for (String userId in _selectedNewMembers) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .get();
        final userName = userDoc.data()?['name'] ?? 'Team Member';
        final userEmail = userDoc.data()?['email'] ?? '';
        
        // Send team addition notification
        await UnifiedNotificationService.sendNotification(
          userId: userId,
          title: 'Added to Team 🎉',
          message: 'You have been added to team: ${team['name']}',
          type: 'success',
          notificationType: 'member_added',
          relatedId: _selectedTeamId,
          sendEmail: true,
          emailData: {
            'teamName': team['name'],
            'projectTitle': projectTitle,
            'addedByName': userName,
          },
        );
        
        // Also send project addition notification if there's a project
        if (_teamProjectId != null && _teamProjectId!.isNotEmpty) {
          await UnifiedNotificationService.sendNotification(
            userId: userId,
            title: 'Added to Project 📁',
            message: 'You have been added to the project: $projectTitle',
            type: 'info',
            notificationType: 'project_assigned',
            relatedId: _teamProjectId,
            sendEmail: false, // Skip email to avoid duplicate emails
          );
        }
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ Added ${_selectedNewMembers.length} members to team. Email notifications sent.'),
            backgroundColor: Colors.green,
          ),
        );
        
        // Refresh team list
        await _loadTeams();
        _loadTeamMembers(_selectedTeamId!);
        
        // Clear selections
        setState(() {
          _selectedNewMembers = [];
        });
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assign Members to Team'),
        backgroundColor: Colors.green,
      ),
      body: _isLoading && _teams.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Team Selection
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: DropdownButtonFormField<String>(
                    value: _selectedTeamId,
                    decoration: const InputDecoration(
                      labelText: 'Select Team',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.group),
                    ),
                    items: _teams.map<DropdownMenuItem<String>>((team) {
                      final memberIds = team['memberIds'] as List? ?? [];
                      final memberCount = memberIds.length;
                      final maxMembers = team['maxMembers'] ?? 0;
                      final visibility = team['projectVisibility'] ?? 'open';
                      final department = team['projectDepartment'];
                      
                      String subtitle = '';
                      if (visibility == 'department' && department != null && department.isNotEmpty) {
                        subtitle = ' (${department.toUpperCase()} only)';
                      } else if (visibility == 'restricted') {
                        subtitle = ' (Restricted)';
                      }
                      
                      return DropdownMenuItem<String>(
                        value: team['id'].toString(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${team['name']} ($memberCount/$maxMembers members)',
                              style: const TextStyle(fontWeight: FontWeight.w500),
                            ),
                            if (subtitle.isNotEmpty)
                              Text(
                                subtitle,
                                style: const TextStyle(fontSize: 11, color: Colors.grey),
                              ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedTeamId = value;
                      });
                      if (value != null) {
                        _loadTeamMembers(value);
                      }
                    },
                  ),
                ),
                
                if (_selectedTeamId != null) ...[
                  // Department Filter Info Banner
                  if (_projectVisibility == 'department' && _projectDepartment != null && _projectDepartment!.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue.shade200),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.filter_alt, color: Colors.blue.shade700, size: 20),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'This team is for ${_projectDepartment!.toUpperCase()} department only. Only users from this department can be added.',
                              style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                            ),
                          ),
                        ],
                      ),
                    ),
                  
                  // Current Members Section
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const Icon(Icons.people, color: Colors.green),
                        const SizedBox(width: 8),
                        Text(
                          'Current Members (${_currentMembers.length})',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 150,
                    child: _currentMembers.isEmpty
                        ? const Center(child: Text('No members yet'))
                        : ListView.builder(
                            itemCount: _currentMembers.length,
                            itemBuilder: (context, index) {
                              final memberId = _currentMembers[index];
                              return _buildUserTile(memberId, isSelected: false);
                            },
                          ),
                  ),
                  
                  const Divider(height: 32),
                  
                  // Add New Members Section
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const Icon(Icons.person_add, color: Colors.blue),
                        const SizedBox(width: 8),
                        const Text(
                          'Add New Members',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          'Selected: ${_selectedNewMembers.length}',
                          style: const TextStyle(color: Colors.green),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _buildAvailableUsersList(),
                  ),
                  
                  // Assign Button
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _assignMembers,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                        child: _isLoading
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text('Add Selected Members', style: TextStyle(fontSize: 16)),
                      ),
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Widget _buildAvailableUsersList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .where('role', whereIn: ['student', 'staff'])
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        
        var users = snapshot.data!.docs;
        
        // Apply department filter if team is for a department-restricted project
        if (_projectVisibility == 'department' && _projectDepartment != null && _projectDepartment!.isNotEmpty) {
          users = users.where((user) {
            final data = user.data() as Map<String, dynamic>;
            return data['department'] == _projectDepartment;
          }).toList();
        }
        
        // Filter out current members
        final availableUsers = users.where((user) {
          return !_currentMembers.contains(user.id);
        }).toList();
        
        if (availableUsers.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.people_outline, size: 64, color: Colors.grey.shade400),
                const SizedBox(height: 16),
                const Text('No available users to add'),
                if (_projectDepartment != null && _projectDepartment!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'Only users in ${_projectDepartment!.toUpperCase()} department can be added to this team.',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                      textAlign: TextAlign.center,
                    ),
                  ),
                const SizedBox(height: 8),
                Text(
                  'Add users to this department first in User Management.',
                  style: TextStyle(fontSize: 11, color: Colors.blue.shade700),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        }
        
        return ListView.builder(
          itemCount: availableUsers.length,
          itemBuilder: (context, index) {
            final user = availableUsers[index];
            final data = user.data() as Map<String, dynamic>;
            final isSelected = _selectedNewMembers.contains(user.id);
            final userDepartment = data['department'] ?? 'No department';
            
            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: CheckboxListTile(
                value: isSelected,
                onChanged: (checked) {
                  setState(() {
                    if (checked == true) {
                      _selectedNewMembers.add(user.id);
                    } else {
                      _selectedNewMembers.remove(user.id);
                    }
                  });
                },
                title: Text(data['name'] ?? 'Unknown'),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data['email'] ?? 'No email'),
                    if (_projectDepartment != null && _projectDepartment!.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.only(top: 2),
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: userDepartment == _projectDepartment 
                              ? Colors.green.shade100 
                              : Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'Department: $userDepartment',
                          style: TextStyle(
                            fontSize: 10,
                            color: userDepartment == _projectDepartment 
                                ? Colors.green.shade700 
                                : Colors.orange.shade700,
                          ),
                        ),
                      ),
                  ],
                ),
                secondary: CircleAvatar(
                  backgroundColor: Colors.green.shade100,
                  child: Text(data['name']?.substring(0, 1).toUpperCase() ?? '?'),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildUserTile(String userId, {required bool isSelected}) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(userId).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const ListTile(title: Text('Loading...'));
        }
        final data = snapshot.data!.data() as Map<String, dynamic>;
        final userDepartment = data['department'] ?? 'No department';
        final matchesDepartment = _projectDepartment == null || 
            _projectVisibility != 'department' ||
            userDepartment == _projectDepartment;
        
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: matchesDepartment ? Colors.green.shade100 : Colors.grey.shade200,
              child: Text(data['name']?.substring(0, 1).toUpperCase() ?? '?'),
            ),
            title: Text(data['name'] ?? 'Unknown'),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(data['role'] ?? 'No role'),
                if (!matchesDepartment && _projectDepartment != null)
                  Text(
                    '⚠️ Different department (${_projectDepartment!.toUpperCase()} required)',
                    style: const TextStyle(fontSize: 10, color: Colors.orange),
                  ),
              ],
            ),
            trailing: isSelected 
                ? const Icon(Icons.check_circle, color: Colors.green) 
                : null,
            tileColor: !matchesDepartment ? Colors.grey.shade50 : null,
          ),
        );
      },
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }
}