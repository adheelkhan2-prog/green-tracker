// ignore_for_file: unnecessary_brace_in_string_interps, deprecated_member_use, use_build_context_synchronously, unused_field, avoid_print, prefer_final_fields, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CreateTeamScreen extends StatefulWidget {
  const CreateTeamScreen({super.key});

  @override
  State<CreateTeamScreen> createState() => _CreateTeamScreenState();
}

class _CreateTeamScreenState extends State<CreateTeamScreen> {
  final _nameController = TextEditingController();
  final _maxMembersController = TextEditingController(text: '5');

  String? _selectedCampusId;
  String? _selectedTeamLeadId;
  String? _selectedProjectId;
  
  // Store project details for filtering
  Map<String, dynamic>? _selectedProjectData;

  List<Map<String, dynamic>> _availableUsers = [];
  List<Map<String, dynamic>> _filteredUsers = []; // Filtered by department
  List<Map<String, dynamic>> _availableProjects = [];
  List<String> _selectedMemberIds = [];

  bool _isLoading = true;
  bool _isSaving = false;
  String? _departmentFilter;

  bool get _isFormValid =>
      _nameController.text.trim().isNotEmpty &&
      _selectedCampusId != null &&
      _selectedTeamLeadId != null &&
      _selectedMemberIds.isNotEmpty;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final users = await FirebaseFirestore.instance.collection('users').get();
      final projects = await FirebaseFirestore.instance.collection('projects').get();

      _availableUsers = users.docs.map((d) {
        final data = d.data();
        return {
          'id': d.id,
          'name': data['name'] ?? 'Unknown',
          'email': data['email'] ?? '',
          'role': data['role'] ?? '',
          'department': data['department'] ?? '',
          'faculty': data['faculty'] ?? '',
        };
      }).toList();

      _availableProjects = projects.docs.map((d) {
        final data = d.data();
        return {
          'id': d.id,
          'title': data['title'] ?? 'Untitled',
          'visibility': data['visibility'] ?? 'open',
          'department': data['department'],
          'faculty': data['faculty'],
        };
      }).toList();

      setState(() => _isLoading = false);
    } catch (e) {
      print("LOAD ERROR: $e");
    }
  }

  // Filter users based on project's department
  void _filterUsersByProject(String? projectId) {
    if (projectId == null || projectId.isEmpty) {
      setState(() {
        _filteredUsers = [];
        _departmentFilter = null;
      });
      return;
    }

    final project = _availableProjects.firstWhere(
      (p) => p['id'] == projectId,
      orElse: () => {},
    );
    
    final visibility = project['visibility'] ?? 'open';
    final projectDepartment = project['department'];
    final projectFaculty = project['faculty'];
    
    List<Map<String, dynamic>> filtered;
    
    if (visibility == 'open') {
      // Open project - show all users
      filtered = List.from(_availableUsers);
      _departmentFilter = null;
    } else if (visibility == 'department') {
      // Department project - only show users in same department
      if (projectDepartment != null && projectDepartment.isNotEmpty) {
        filtered = _availableUsers.where((user) {
          return user['department'] == projectDepartment;
        }).toList();
        _departmentFilter = projectDepartment;
      } else {
        filtered = [];
        _departmentFilter = null;
      }
    } else {
      // Restricted project - only show users from same department/faculty
      filtered = _availableUsers.where((user) {
        bool matches = true;
        if (projectDepartment != null && projectDepartment.isNotEmpty) {
          matches = matches && user['department'] == projectDepartment;
        }
        if (projectFaculty != null && projectFaculty.isNotEmpty) {
          matches = matches && user['faculty'] == projectFaculty;
        }
        return matches;
      }).toList();
      _departmentFilter = projectDepartment ?? projectFaculty;
    }
    
    setState(() {
      _filteredUsers = filtered;
      // Clear selections if they are no longer valid
      if (_selectedTeamLeadId != null && 
          !_filteredUsers.any((u) => u['id'] == _selectedTeamLeadId)) {
        _selectedTeamLeadId = null;
      }
      _selectedMemberIds = _selectedMemberIds.where((id) 
        => _filteredUsers.any((u) => u['id'] == id)).toList();
    });
  }

  Future<void> _createTeam() async {
    if (!_isFormValid) return;

    setState(() => _isSaving = true);

    try {
      final teamRef = await FirebaseFirestore.instance.collection('teams').add({
        'name': _nameController.text,
        'campusId': _selectedCampusId,
        'leaderId': _selectedTeamLeadId,
        'memberIds': _selectedMemberIds,
        'maxMembers': int.tryParse(_maxMembersController.text) ?? 5,
        'isAvailable': true,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (_selectedProjectId != null && _selectedProjectId != 'none') {
        await FirebaseFirestore.instance
            .collection('projects')
            .doc(_selectedProjectId)
            .update({'teamId': teamRef.id});
      }

      // Send notifications to all members
      for (String memberId in _selectedMemberIds) {
        await FirebaseFirestore.instance.collection('notifications').add({
          'userId': memberId,
          'title': 'Added to Team 🎉',
          'message': 'You have been added to team: ${_nameController.text}',
          'type': 'success',
          'notificationType': 'team_created',
          'isRead': false,
          'createdAt': FieldValue.serverTimestamp(),
          'relatedId': teamRef.id,
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✅ Team "${_nameController.text}" created successfully!')),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      print("CREATE ERROR: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _toggleMember(String id) {
    setState(() {
      if (_selectedMemberIds.contains(id)) {
        _selectedMemberIds.remove(id);
      } else {
        _selectedMemberIds.add(id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final leader = _filteredUsers.firstWhere(
      (u) => u['id'] == _selectedTeamLeadId,
      orElse: () => {'name': 'Unknown'},
    );
    
    final canSelectMembers = _selectedProjectId != null && 
        _selectedProjectId != 'none' && 
        _filteredUsers.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: Text("Create Team"), 
        backgroundColor: Colors.green,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        /// TEAM NAME
                        TextField(
                          controller: _nameController,
                          decoration: InputDecoration(
                            labelText: "Team Name *",
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.group),
                          ),
                          onChanged: (_) => setState(() {}),
                        ),
                        SizedBox(height: 16),

                        /// MAX MEMBERS
                        TextField(
                          controller: _maxMembersController,
                          decoration: InputDecoration(
                            labelText: "Max Members",
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.people),
                            helperText: "Default is 5 members",
                          ),
                          keyboardType: TextInputType.number,
                        ),
                        SizedBox(height: 16),

                        /// CAMPUS
                        StreamBuilder<QuerySnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('campuses')
                              .snapshots(),
                          builder: (context, snap) {
                            if (!snap.hasData) return CircularProgressIndicator();
                            return DropdownButtonFormField<String>(
                              hint: Text("Select Campus *"),
                              value: _selectedCampusId,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.location_city),
                              ),
                              items: snap.data!.docs.map((doc) {
                                return DropdownMenuItem<String>(
                                  value: doc.id,
                                  child: Text(doc['name']),
                                );
                              }).toList(),
                              onChanged: (v) => setState(() => _selectedCampusId = v),
                            );
                          },
                        ),
                        SizedBox(height: 16),

                        /// PROJECT SELECTION (Required)
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.orange.shade200),
                            borderRadius: BorderRadius.circular(8),
                            color: Colors.orange.shade50,
                          ),
                          child: DropdownButtonFormField<String>(
                            hint: Text("Select Project *", style: TextStyle(color: Colors.orange)),
                            value: _selectedProjectId,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              prefixIcon: Icon(Icons.folder, color: Colors.orange),
                            ),
                            items: [
                              ..._availableProjects.map((p) {
                                final visibility = p['visibility'] ?? 'open';
                                String subtitle = '';
                                if (visibility == 'department') {
                                  subtitle = ' (${p['department']} only)';
                                } else if (visibility == 'restricted') {
                                  subtitle = ' (Restricted)';
                                }
                                return DropdownMenuItem(
                                  value: p['id'],
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(p['title'], style: TextStyle(fontWeight: FontWeight.w500)),
                                      Text(
                                        'Visibility: $visibility$subtitle',
                                        style: TextStyle(fontSize: 10, color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                );
                              }),
                            ],
                            onChanged: (v) {
                              setState(() {
                                _selectedProjectId = v;
                                _selectedProjectData = _availableProjects.firstWhere(
                                  (p) => p['id'] == v,
                                  orElse: () => {},
                                );
                                _selectedTeamLeadId = null;
                                _selectedMemberIds = [];
                              });
                              _filterUsersByProject(v);
                            },
                          ),
                        ),
                        
                        SizedBox(height: 16),

                        /// DEPARTMENT FILTER INFO
                        if (_departmentFilter != null)
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.blue.shade200),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.filter_alt, color: Colors.blue, size: 20),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Showing only users from: ${_departmentFilter!.toUpperCase()} department',
                                    style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          
                        SizedBox(height: 16),

                        /// TEAM LEADER
                        if (_filteredUsers.isNotEmpty)
                          DropdownButtonFormField<String>(
                            value: _selectedTeamLeadId,
                            hint: Text("Select Team Leader *"),
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              prefixIcon: Icon(Icons.leaderboard),
                              helperText: _departmentFilter != null 
                                  ? "Only showing users in ${_departmentFilter} department"
                                  : null,
                            ),
                            items: _filteredUsers.map((u) {
                              return DropdownMenuItem<String>(
                                value: u['id'],
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(u['name']),
                                    Text(
                                      '${u['role']} • ${u['department'] ?? 'No department'}',
                                      style: TextStyle(fontSize: 11, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (v) {
                              setState(() {
                                _selectedTeamLeadId = v;
                                if (v != null && !_selectedMemberIds.contains(v)) {
                                  _selectedMemberIds.add(v);
                                }
                              });
                            },
                          )
                        else if (_selectedProjectId != null && _selectedProjectId != 'none')
                          Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.red.shade50,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              children: [
                                Icon(Icons.warning, color: Colors.red),
                                SizedBox(height: 8),
                                Text(
                                  'No users available in this department.',
                                  style: TextStyle(color: Colors.red),
                                ),
                                Text(
                                  'Please add users to the ${_departmentFilter ?? "required"} department first.',
                                  style: TextStyle(fontSize: 12, color: Colors.red.shade700),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),

                        SizedBox(height: 16),

                        /// MEMBERS SECTION
                        if (_filteredUsers.isNotEmpty && _selectedProjectId != null && _selectedProjectId != 'none')
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.person_add, color: Colors.green),
                                  SizedBox(width: 8),
                                  Text(
                                    'Select Team Members (${_selectedMemberIds.length} selected)',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Text(
                                _departmentFilter != null 
                                    ? 'Only showing users in ${_departmentFilter} department'
                                    : 'Select members to add to this team',
                                style: TextStyle(fontSize: 12, color: Colors.grey),
                              ),
                              SizedBox(height: 12),
                              ListView.builder(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: _filteredUsers.length,
                                itemBuilder: (context, index) {
                                  final u = _filteredUsers[index];
                                  return CheckboxListTile(
                                    value: _selectedMemberIds.contains(u['id']),
                                    title: Text(u['name']),
                                    subtitle: Text(
                                      '${u['role']} • ${u['department'] ?? 'No department'}',
                                      style: TextStyle(fontSize: 11),
                                    ),
                                    onChanged: (_) => _toggleMember(u['id']),
                                    secondary: CircleAvatar(
                                      backgroundColor: Colors.green.shade100,
                                      child: Text(
                                        u['name'].substring(0, 1).toUpperCase(),
                                        style: TextStyle(color: Colors.green),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),

                        SizedBox(height: 16),

                        /// SUMMARY
                        if (_isFormValid)
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.green.shade50,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  "Team Summary",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                SizedBox(height: 4),
                                Text("Leader: ${leader['name']}"),
                                Text("Members: ${_selectedMemberIds.length}"),
                                if (_departmentFilter != null)
                                  Text(
                                    "Department: ${_departmentFilter!.toUpperCase()}",
                                    style: TextStyle(fontSize: 11, color: Colors.blue),
                                  ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),

                /// CREATE BUTTON
                Padding(
                  padding: EdgeInsets.all(16),
                  child: ElevatedButton(
                    onPressed: _isSaving || !_isFormValid ? null : _createTeam,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: _isSaving
                        ? CircularProgressIndicator(color: Colors.white)
                        : Text("Create Team", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                )
              ],
            ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _maxMembersController.dispose();
    super.dispose();
  }
}