// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EditUserScreen extends StatefulWidget {
  final String userId;

  const EditUserScreen({super.key, required this.userId});

  @override
  State<EditUserScreen> createState() => _EditUserScreenState();
}

class _EditUserScreenState extends State<EditUserScreen> {
  final nameController = TextEditingController();
  String role = "student";
  String? campusId;
  String? department;
  String? faculty;

  final roles = ["admin", "lecturer", "student", "staff", "external"];
  
  // Department list
  final List<String> departments = [
    "Computer Science",
    "Information Technology",
    "Community Health Studies",
    "Biotechnology & Food Science",
    "Horticulture",
    "Mechanical Engineering",
    "Electrical Engineering",
    "Civil Engineering",
    "Business Management",
    "Accounting",
    "Marketing",
    "Communications",
    "Other",
  ];
  
  // Faculty list
  final List<String> faculties = [
     "Faculty of Applied Sciences",
    "Faculty of Accounting & Informatics",
    "Faculty of Engineering & the Built Environment",
    "Faculty of Health Sciences",
    "Faculty of Management Sciences",
    "Faculty of Arts & Design",
    "Other",
  ];

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  Future<void> loadUser() async {
    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .get();

    final data = doc.data()!;

    setState(() {
      nameController.text = data['name'] ?? '';
      role = data['role'] ?? 'student';
      campusId = data['campusId'];
      department = data['department'];
      faculty = data['faculty'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Edit User"),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Name Field
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: "Name",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 16),

            // Role Dropdown
            DropdownButtonFormField<String>(
              value: role,
              decoration: const InputDecoration(
                labelText: "Role",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.badge),
              ),
              items: roles.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
              onChanged: (value) => setState(() => role = value!),
            ),
            const SizedBox(height: 16),

            // Department Dropdown (NEW)
            DropdownButtonFormField<String>(
              value: department,
              hint: const Text("Select Department"),
              decoration: const InputDecoration(
                labelText: "Department",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.business),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text("None")),
                ...departments.map((d) => DropdownMenuItem(value: d, child: Text(d))),
              ],
              onChanged: (value) => setState(() => department = value),
            ),
            const SizedBox(height: 16),

            // Faculty Dropdown (NEW)
            DropdownButtonFormField<String>(
              value: faculty,
              hint: const Text("Select Faculty"),
              decoration: const InputDecoration(
                labelText: "Faculty",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.school),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text("None")),
                ...faculties.map((f) => DropdownMenuItem(value: f, child: Text(f))),
              ],
              onChanged: (value) => setState(() => faculty = value),
            ),
            const SizedBox(height: 16),

            // Campus Dropdown
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('campuses')
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                final campuses = snapshot.data!.docs;

                return DropdownButtonFormField<String>(
                  value: campusId,
                  hint: const Text("Select Campus"),
                  decoration: const InputDecoration(
                    labelText: "Campus",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.location_city),
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text("None")),
                    ...campuses.map((doc) {
                      return DropdownMenuItem(
                        value: doc.id,
                        child: Text(doc['name']),
                      );
                    }),
                  ],
                  onChanged: (value) => setState(() => campusId = value),
                );
              },
            ),
            const SizedBox(height: 24),

            // Update Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () async {
                  await FirebaseFirestore.instance
                      .collection('users')
                      .doc(widget.userId)
                      .update({
                    "name": nameController.text,
                    "role": role,
                    "campusId": campusId,
                    "department": department,
                    "faculty": faculty,
                  });

                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('User updated successfully!'),
                      backgroundColor: Colors.green,
                    ),
                  );
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text("Update User", style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}