import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SelectMembersScreen extends StatefulWidget {
  final List<String> selectedMembers;

  const SelectMembersScreen({
    super.key,
    required this.selectedMembers,
  });

  @override
  State<SelectMembersScreen> createState() =>
      _SelectMembersScreenState();
}

class _SelectMembersScreenState
    extends State<SelectMembersScreen> {

  late List<String> selected;

  @override
  void initState() {
    super.initState();
    selected = List.from(widget.selectedMembers);
  }

  void toggleSelection(String userId) {
    setState(() {
      if (selected.contains(userId)) {
        selected.remove(userId);
      } else {
        selected.add(userId);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Select Members"),
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: () {
              Navigator.pop(context, selected);
            },
          )
        ],
      ),

      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .snapshots(),
        builder: (context, snapshot) {

          if (snapshot.connectionState ==
              ConnectionState.waiting) {
            return const Center(
                child: CircularProgressIndicator());
          }

          if (!snapshot.hasData ||
              snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No users found"));
          }

          final users = snapshot.data!.docs;

          return ListView.builder(
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index];
              final data =
                  user.data() as Map<String, dynamic>;

              final isSelected = selected.contains(user.id);

              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isSelected
                        ? Colors.green
                        : Colors.grey,
                    child: Text(
                      (data['name'] ?? "U")[0],
                    ),
                  ),

                  title: Text(data['name'] ?? "No Name"),

                  subtitle: Text(data['email'] ?? ""),

                  trailing: Icon(
                    isSelected
                        ? Icons.check_circle
                        : Icons.radio_button_unchecked,
                    color: isSelected
                        ? Colors.green
                        : Colors.grey,
                  ),

                  onTap: () => toggleSelection(user.id),
                ),
              );
            },
          );
        },
      ),
    );
  }
}