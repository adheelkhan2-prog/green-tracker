import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:file_picker/file_picker.dart';
import 'package:excel/excel.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import 'add_user_screen.dart';
import 'edit_user_screen.dart';

class UserListScreen extends StatelessWidget {
  const UserListScreen({super.key});

  // ===============================
  // 📥 IMPORT USERS FROM excel
  // ===============================
 Future<void> importUsersFromExcel(BuildContext context) async {
  try {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );

    if (result == null) return;

    final bytes = result.files.single.bytes;
    if (bytes == null) throw Exception("File not loaded");

    final excel = Excel.decodeBytes(bytes);

    final sheetName = excel.tables.keys.first;
    final rows = excel.tables[sheetName]!.rows;

    int added = 0;
    int skipped = 0;

    for (int i = 1; i < rows.length; i++) {
      final row = rows[i];

      final name = row[0]?.value?.toString().trim();
      final email = row[1]?.value?.toString().trim();
      final role = row[2]?.value?.toString().trim() ?? "student";
      final campusId = row[3]?.value?.toString().trim() ?? "";

      if (email == null || email.isEmpty) continue;

      // 🔍 CHECK DUPLICATE BY EMAIL
      final existing = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      if (existing.docs.isNotEmpty) {
        skipped++;
        continue;
      }

      // ➕ ADD USER
      await FirebaseFirestore.instance.collection('users').add({
        "name": name ?? "",
        "email": email,
        "role": role,
        "campusId": campusId,
        "createdAt": FieldValue.serverTimestamp(),
      });

      added++;
    }

    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Import complete: $added added, $skipped skipped"),
      ),
    );
  } catch (e) {
    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Import failed: $e")),
    );
  }
}

// ======================================
  // 📤 DOWNLOAD EXCEL TEMPLATE
  // ======================================
  Future<void> downloadExcelTemplate(BuildContext context) async {
  try {
    // 1. Ask permission (important for Android < 13)
    await Permission.storage.request();

    // 2. Create Excel file
    var excel = Excel.createExcel();
    Sheet sheet = excel['Users'];

    sheet.appendRow([
      TextCellValue("name"),
      TextCellValue("email"),
      TextCellValue("role"),
      TextCellValue("campusId"),
    ]);

    final bytes = excel.save();
    if (bytes == null) throw Exception("Failed to create file");

    // 3. Get Downloads folder (ANDROID SAFE METHOD)
    Directory? dir;

    if (Platform.isAndroid) {
      dir = Directory('/storage/emulated/0/Download');
    } else {
      dir = await getApplicationDocumentsDirectory();
    }

    final file = File("${dir.path}/user_template.xlsx");

    await file.writeAsBytes(bytes);

    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Saved to Downloads: ${file.path}"),
      ),
    );
  } catch (e) {
    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Save failed: $e")),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    // 🔐 GET CURRENT USER ROLE
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .get(),
      builder: (context, userSnapshot) {
        if (!userSnapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final currentUser =
            userSnapshot.data!.data() as Map<String, dynamic>;

        final isAdmin = currentUser['role'] == 'admin';

        return Scaffold(
          appBar: AppBar(
            title: const Text("All Users"),
            actions: [
              // 📥 IMPORT BUTTON
              IconButton(
                icon: const Icon(Icons.upload_file),
                onPressed: () => importUsersFromExcel(context),
              ),
              // 📤 DOWNLOAD TEMPLATE
              IconButton(
                icon: const Icon(Icons.download),
                onPressed: () => downloadExcelTemplate(context),
              ),
            ],
          ),

          // ===============================
          // 📊 USER LIST
          // ===============================
          body: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState ==
                  ConnectionState.waiting) {
                return const Center(
                    child: CircularProgressIndicator());
              }

              if (!snapshot.hasData ||
                  snapshot.data!.docs.isEmpty) {
                return const Center(child: Text("No users found"));
              }

              final users = snapshot.data!.docs;

              return ListView.builder(
                itemCount: users.length,
                itemBuilder: (context, index) {
                  final user = users[index];
                  final data =
                      user.data() as Map<String, dynamic>;

                  return Card(
                    margin: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    child: ListTile(
                      leading: const Icon(Icons.person,
                          color: Colors.green),

                      title: Text(data['name'] ?? "No Name"),

                      subtitle: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text("Email: ${data['email']}"),
                          Text("Role: ${data['role']}"),

                          // 🎯 FETCH CAMPUS NAME
                          StreamBuilder<DocumentSnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('campuses')
                                .doc(data['campusId'])
                                .snapshots(),
                            builder: (context, campusSnapshot) {
                              String campusName = "Loading...";

                              if (campusSnapshot.hasData &&
                                  campusSnapshot.data!.exists) {
                                final campusData =
                                    campusSnapshot.data!.data()
                                        as Map<String, dynamic>;

                                campusName =
                                    campusData['name'] ??
                                        "Unknown";
                              }

                              return Text(
                                  "Campus: $campusName");
                            },
                          ),
                        ],
                      ),

                      // ===============================
                      // ACTION BUTTONS
                      // ===============================
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // ✏️ EDIT
                          IconButton(
                            icon: const Icon(Icons.edit,
                                color: Colors.blue),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      EditUserScreen(
                                    userId: user.id,
                                  ),
                                ),
                              );
                            },
                          ),

                          // 🗑 DELETE (ADMIN ONLY)
                          if (isAdmin)
                            IconButton(
                              icon: const Icon(Icons.delete,
                                  color: Colors.red),
                              onPressed: () async {
                                final confirm =
                                    await showDialog(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                    title: const Text(
                                        "Delete User"),
                                    content: const Text(
                                        "Are you sure you want to delete this user?"),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(
                                                context, false),
                                        child:
                                            const Text("Cancel"),
                                      ),
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(
                                                context, true),
                                        child:
                                            const Text("Delete"),
                                      ),
                                    ],
                                  ),
                                );

                                if (confirm == true) {
                                  await FirebaseFirestore
                                      .instance
                                      .collection('users')
                                      .doc(user.id)
                                      .delete();
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),

          // ===============================
          // ➕ ADD + IMPORT BUTTONS
          // ===============================
          floatingActionButton: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // IMPORT
              FloatingActionButton(
                heroTag: "import",
                backgroundColor: Colors.blue,
                child: const Icon(Icons.upload),
                onPressed: () => importUsersFromExcel(context),
              ),

              const SizedBox(height: 10),

              // ADD USER
              FloatingActionButton.extended(
                heroTag: "add",
                backgroundColor: const Color(0xFF00A86B),
                icon: const Icon(Icons.add),
                label: const Text("Add User"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const AddUserScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}