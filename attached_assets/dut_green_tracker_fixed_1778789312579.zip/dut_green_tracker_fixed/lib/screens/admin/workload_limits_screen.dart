// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class WorkloadLimitsScreen extends StatefulWidget {
  const WorkloadLimitsScreen({super.key});

  @override
  State<WorkloadLimitsScreen> createState() => _WorkloadLimitsScreenState();
}

class _WorkloadLimitsScreenState extends State<WorkloadLimitsScreen> {
  String? _selectedTeamId;
  List<Map<String, dynamic>> _teams = [];
  bool _isLoading = false;
  bool _isSaving = false;

  // Workload limit controllers
  final _dailyLimitController = TextEditingController();
  final _weeklyLimitController = TextEditingController();
  final _monthlyLimitController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadTeams();
  }

  Future<void> _loadTeams() async {
    setState(() => _isLoading = true);
    final snapshot = await FirebaseFirestore.instance.collection('teams').get();
    setState(() {
      _teams = snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'name': data['name'] ?? 'Unnamed',
          'maxProjectsPerDay': data['maxProjectsPerDay'] ?? 2,
          'maxProjectsPerWeek': data['maxProjectsPerWeek'] ?? 5,
          'maxProjectsPerMonth': data['maxProjectsPerMonth'] ?? 10,
        };
      }).toList();
      _isLoading = false;
    });
  }

  void _loadTeamLimits(String teamId) {
    final team = _teams.firstWhere((t) => t['id'] == teamId);
    _dailyLimitController.text = team['maxProjectsPerDay'].toString();
    _weeklyLimitController.text = team['maxProjectsPerWeek'].toString();
    _monthlyLimitController.text = team['maxProjectsPerMonth'].toString();
  }

  Future<void> _saveWorkloadLimits() async {
    if (_selectedTeamId == null) {
      _showError('Please select a team');
      return;
    }

    final dailyLimit = int.tryParse(_dailyLimitController.text);
    final weeklyLimit = int.tryParse(_weeklyLimitController.text);
    final monthlyLimit = int.tryParse(_monthlyLimitController.text);

    if (dailyLimit == null || weeklyLimit == null || monthlyLimit == null) {
      _showError('Please enter valid numbers for all limits');
      return;
    }

    if (dailyLimit < 0 || weeklyLimit < 0 || monthlyLimit < 0) {
      _showError('Limits cannot be negative');
      return;
    }

    setState(() => _isSaving = true);

    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      
      await FirebaseFirestore.instance
          .collection('teams')
          .doc(_selectedTeamId)
          .update({
        'maxProjectsPerDay': dailyLimit,
        'maxProjectsPerWeek': weeklyLimit,
        'maxProjectsPerMonth': monthlyLimit,
        'workloadUpdatedAt': FieldValue.serverTimestamp(),
        'workloadUpdatedBy': currentUser?.uid ?? 'unknown',
      });

      // Update local list
      final index = _teams.indexWhere((t) => t['id'] == _selectedTeamId);
      if (index != -1) {
        setState(() {
          _teams[index]['maxProjectsPerDay'] = dailyLimit;
          _teams[index]['maxProjectsPerWeek'] = weeklyLimit;
          _teams[index]['maxProjectsPerMonth'] = monthlyLimit;
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Workload limits updated successfully!')),
        );
      }
    } catch (e) {
      _showError('Error saving limits: $e');
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Set Workload Limits'),
        backgroundColor: Colors.green,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Team Selection
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: DropdownButtonFormField<String>(
                    value: _selectedTeamId,
                    decoration: const InputDecoration(
                      labelText: 'Select Team',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.group),
                      helperText: 'Choose a team to configure workload limits',
                    ),
                    items: _teams.map<DropdownMenuItem<String>>((team) {
                      return DropdownMenuItem<String>(
                        value: team['id'].toString(),
                        child: Text(team['name'].toString()),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedTeamId = value;
                      });
                      if (value != null) {
                        _loadTeamLimits(value);
                      }
                    },
                  ),
                ),
                
                if (_selectedTeamId != null) ...[
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Info Card
                          Card(
                            color: Colors.blue.shade50,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  Icon(Icons.info_outline, color: Colors.blue.shade700),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      'Set maximum number of projects this team can handle',
                                      style: TextStyle(color: Colors.blue.shade700),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          
                          const SizedBox(height: 24),
                          
                          // Daily Limit
                          Card(
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.today, color: Colors.orange),
                                      const SizedBox(width: 8),
                                      const Text(
                                        'Daily Limit',
                                        style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    'Maximum projects per day',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  const SizedBox(height: 12),
                                  TextField(
                                    controller: _dailyLimitController,
                                    keyboardType: TextInputType.number,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      prefixIcon: Icon(Icons.numbers),
                                      suffixText: 'projects/day',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          
                          const SizedBox(height: 16),
                          
                          // Weekly Limit
                          Card(
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.calendar_view_week, color: Colors.blue),
                                      const SizedBox(width: 8),
                                      const Text(
                                        'Weekly Limit',
                                        style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    'Maximum projects per week',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  const SizedBox(height: 12),
                                  TextField(
                                    controller: _weeklyLimitController,
                                    keyboardType: TextInputType.number,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      prefixIcon: Icon(Icons.numbers),
                                      suffixText: 'projects/week',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          
                          const SizedBox(height: 16),
                          
                          // Monthly Limit
                          Card(
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.calendar_month, color: Colors.purple),
                                      const SizedBox(width: 8),
                                      const Text(
                                        'Monthly Limit',
                                        style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    'Maximum projects per month',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  const SizedBox(height: 12),
                                  TextField(
                                    controller: _monthlyLimitController,
                                    keyboardType: TextInputType.number,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      prefixIcon: Icon(Icons.numbers),
                                      suffixText: 'projects/month',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          
                          const SizedBox(height: 24),
                          
                          // Current Limits Summary
                          Card(
                            color: Colors.green.shade50,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Current Limits:',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  _buildLimitRow(
                                    'Daily:',
                                    '${_dailyLimitController.text} project(s) per day',
                                    Icons.today,
                                  ),
                                  _buildLimitRow(
                                    'Weekly:',
                                    '${_weeklyLimitController.text} project(s) per week',
                                    Icons.calendar_view_week,
                                  ),
                                  _buildLimitRow(
                                    'Monthly:',
                                    '${_monthlyLimitController.text} project(s) per month',
                                    Icons.calendar_month,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  // Save Button
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _isSaving ? null : _saveWorkloadLimits,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                        child: _isSaving
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text('Save Workload Limits', style: TextStyle(fontSize: 16)),
                      ),
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Widget _buildLimitRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.green.shade700),
          const SizedBox(width: 8),
          SizedBox(
            width: 60,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(width: 8),
          Text(value),
        ],
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  void dispose() {
    _dailyLimitController.dispose();
    _weeklyLimitController.dispose();
    _monthlyLimitController.dispose();
    super.dispose();
  }
}