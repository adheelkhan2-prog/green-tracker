// ignore_for_file: prefer_const_constructors, use_build_context_synchronously, unused_element, deprecated_member_use, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/ai_service.dart';

class AIAnalysisScreen extends StatefulWidget {
  const AIAnalysisScreen({super.key});

  @override
  State<AIAnalysisScreen> createState() => _AIAnalysisScreenState();
}

class _AIAnalysisScreenState extends State<AIAnalysisScreen> {
  String? _selectedProjectId;
  List<Map<String, dynamic>> _projects = [];
  bool _isLoading = true;
  bool _isAnalyzing = false;
  Map<String, dynamic>? _analysisResult;
  String? _error;
  bool _isTestMode = false;

  @override
  void initState() {
    super.initState();
    _loadProjects();
  }

  Future<void> _testAIConnection() async {
    setState(() {
      _isAnalyzing = true;
      _isTestMode = true;
      _error = null;
    });
    
    try {
      final isWorking = await AIService.testConnection();
      if (mounted) {
        if (isWorking) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ AI is working! Mistral API connected successfully.'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 3),
            ),
          );
          
          // Show a sample response to prove it's working
          setState(() {
            _analysisResult = {
              'summary': '🎉 AI Connection Successful!\n\nMistral AI is now ready to analyze your projects. Select a project and click "Analyze with AI" to get started.',
              'strengths': ['✅ API connection working', '✅ Free tier active (1B tokens/month)', '✅ Ready for project analysis'],
              'weaknesses': ['No projects analyzed yet', 'Select a project to begin'],
              'recommendations': ['Select a project from the dropdown', 'Click "Analyze with AI" button', 'Review the AI-generated insights'],
              'timeline': 'Immediate - Start analyzing now!',
            };
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('❌ AI connection failed. Check your API key.'),
              backgroundColor: Colors.red,
              duration: Duration(seconds: 5),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ AI Error: $e'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
        setState(() {
          _error = 'Connection failed: $e\n\nMake sure you have:\n1. Created an account at console.mistral.ai\n2. Verified your phone number\n3. Added your API key to ai_service.dart';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isAnalyzing = false;
          _isTestMode = false;
        });
      }
    }
  }

  Future<void> _loadProjects() async {
    setState(() {
      _isLoading = true;
      _error = null;
      _analysisResult = null;
      _selectedProjectId = null;
    });
    
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('projects')
          .orderBy('createdAt', descending: true)
          .get();
      
      print('Loaded ${snapshot.docs.length} projects');
      
      if (snapshot.docs.isEmpty) {
        setState(() {
          _error = 'No projects found. Create a project first to analyze.';
          _isLoading = false;
        });
        return;
      }
      
      setState(() {
        _projects = snapshot.docs.map((doc) {
          final data = doc.data();
          return {
            'id': doc.id,
            'title': data['title'] ?? 'Untitled',
            'description': data['description'] ?? '',
            'status': data['status'] ?? 'pending',
            'progress': data['progress'] ?? 0,
            'sustainabilityScore': (data['sustainabilityScore'] ?? 0).toDouble(),
            'environment': (data['environment'] ?? 0).toDouble(),
            'energy': (data['energy'] ?? 0).toDouble(),
            'waste': (data['waste'] ?? 0).toDouble(),
            'community': (data['community'] ?? 0).toDouble(),
            'innovation': (data['innovation'] ?? 0).toDouble(),
            'projectType': data['projectTypeId'],
          };
        }).toList();
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading projects: $e');
      setState(() {
        _error = 'Error loading projects: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _analyzeProject() async {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a project first'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isAnalyzing = true;
      _error = null;
      _analysisResult = null;
    });

    try {
      final project = _projects.firstWhere((p) => p['id'] == _selectedProjectId);
      
      // Show loading message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('🤖 AI is analyzing your project... This may take a few seconds.'),
          backgroundColor: Colors.blue,
          duration: Duration(seconds: 2),
        ),
      );
      
      final result = await AIService.analyzeProject(project);
      
      if (mounted) {
        setState(() {
          _analysisResult = result;
          _isAnalyzing = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Analysis complete! AI insights are ready.'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      print('Analysis error: $e');
      if (mounted) {
        setState(() {
          _error = 'Analysis failed: $e\n\nPlease check:\n1. Internet connection\n2. API key is valid\n3. Mistral account has free tier credits';
          _isAnalyzing = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Analysis failed: $e'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Project Analysis'),
        backgroundColor: Colors.green,
        actions: [
          // Test Connection Button
          IconButton(
            icon: const Icon(Icons.science),
            onPressed: _isAnalyzing ? null : _testAIConnection,
            tooltip: 'Test AI Connection',
          ),
          // Refresh Button
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _isAnalyzing ? null : _loadProjects,
            tooltip: 'Refresh Projects',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading projects...'),
                ],
              ),
            )
          : _error != null && _projects.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, size: 64, color: Colors.red),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(
                          _error!,
                          style: const TextStyle(color: Colors.red),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadProjects,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // API Status Card
                      Card(
                        color: Colors.blue.shade50,
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              const Icon(Icons.info_outline, color: Colors.blue),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      '🤖 Mistral AI Active',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                    Text(
                                      'Free tier: 1B tokens/month • Tap 🧪 to test connection',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Colors.blue.shade700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.science, size: 20),
                                onPressed: _isAnalyzing ? null : _testAIConnection,
                                tooltip: 'Test Connection',
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Project Selection Card
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Select Project',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 12),
                              
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey.shade300),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: _selectedProjectId,
                                    isExpanded: true,
                                    hint: const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 16),
                                      child: Text('-- Select a project to analyze --'),
                                    ),
                                    items: [
                                      ..._projects.map<DropdownMenuItem<String>>((project) {
                                        final score = (project['sustainabilityScore'] ?? 0).toDouble();
                                        return DropdownMenuItem<String>(
                                          value: project['id'].toString(),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  project['title'].toString(),
                                                  style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                                const SizedBox(height: 4),
                                                Row(
                                                  children: [
                                                    Icon(
                                                      Icons.eco,
                                                      size: 14,
                                                      color: _getScoreColor(score),
                                                    ),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      'Score: ${score.toStringAsFixed(1)}/100',
                                                      style: TextStyle(
                                                        fontSize: 12,
                                                        color: _getScoreColor(score),
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                    const SizedBox(width: 12),
                                                    Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      decoration: BoxDecoration(
                                                        color: Colors.grey.shade200,
                                                        borderRadius: BorderRadius.circular(12),
                                                      ),
                                                      child: Text(
                                                        project['status'].toString(),
                                                        style: const TextStyle(fontSize: 10),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 12),
                                                    Text(
                                                      'Progress: ${project['progress']}%',
                                                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      }),
                                    ],
                                    onChanged: (value) {
                                      setState(() {
                                        _selectedProjectId = value;
                                        _analysisResult = null;
                                        _error = null;
                                      });
                                    },
                                  ),
                                ),
                              ),
                              
                              const SizedBox(height: 16),
                              
                              // Analyze Button
                              SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: ElevatedButton(
                                  onPressed: (_isAnalyzing || _selectedProjectId == null) ? null : _analyzeProject,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                  child: _isAnalyzing
                                      ? const SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : const Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Icon(Icons.auto_awesome, size: 18),
                                            SizedBox(width: 8),
                                            Text(
                                              'Analyze with AI',
                                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Analysis Results
                      if (_analysisResult != null)
                        _buildAnalysisResult(),
                      
                      // Error Display
                      if (_error != null && _analysisResult == null && !_isAnalyzing)
                        Card(
                          color: Colors.red.shade50,
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                const Icon(Icons.error_outline, color: Colors.red, size: 48),
                                const SizedBox(height: 8),
                                Text(
                                  _error!,
                                  style: const TextStyle(color: Colors.red),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 16),
                                ElevatedButton.icon(
                                  onPressed: _testAIConnection,
                                  icon: const Icon(Icons.science),
                                  label: const Text('Test AI Connection'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.orange,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      
                      // Help Card for first-time users
                      if (_analysisResult == null && _error == null && !_isAnalyzing && _projects.isNotEmpty)
                        Card(
                          color: Colors.grey.shade50,
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                const Icon(Icons.auto_awesome, size: 48, color: Colors.grey),
                                const SizedBox(height: 12),
                                const Text(
                                  'Ready to analyze!',
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Select a project above and tap "Analyze with AI" to get sustainability insights powered by Mistral AI.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.grey.shade600),
                                ),
                                const SizedBox(height: 12),
                                const Text(
                                  '🧪 Tap the science icon to test your AI connection first',
                                  style: TextStyle(fontSize: 12, color: Colors.blue),
                                ),
                              ],
                            ),
                          ),
                        ),
                      
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 70) return Colors.green;
    if (score >= 40) return Colors.orange;
    return Colors.red;
  }

  Widget _buildAnalysisResult() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.auto_awesome, color: Colors.green, size: 28),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'AI Analysis Results',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Powered by Mistral AI',
                        style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
                if (!_isTestMode)
                  IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    onPressed: () {
                      setState(() {
                        _analysisResult = null;
                      });
                    },
                  ),
              ],
            ),
            const SizedBox(height: 20),
            
            if (_analysisResult?['summary'] != null && _analysisResult!['summary'].toString().isNotEmpty)
              _buildSection(
                '📊 Executive Summary',
                _analysisResult!['summary'].toString(),
                Icons.assessment,
                Colors.blue,
              ),
            
            const SizedBox(height: 16),
            
            if (_analysisResult?['strengths'] != null && (_analysisResult!['strengths'] as List).isNotEmpty)
              _buildListSection(
                '✅ Strengths',
                List<String>.from(_analysisResult!['strengths']),
                Colors.green,
              ),
            
            const SizedBox(height: 16),
            
            if (_analysisResult?['weaknesses'] != null && (_analysisResult!['weaknesses'] as List).isNotEmpty)
              _buildListSection(
                '⚠️ Areas for Improvement',
                List<String>.from(_analysisResult!['weaknesses']),
                Colors.orange,
              ),
            
            const SizedBox(height: 16),
            
            if (_analysisResult?['recommendations'] != null && (_analysisResult!['recommendations'] as List).isNotEmpty)
              _buildListSection(
                '🎯 Recommended Actions',
                List<String>.from(_analysisResult!['recommendations']),
                Colors.purple,
              ),
            
            const SizedBox(height: 16),
            
            if (_analysisResult?['timeline'] != null && _analysisResult!['timeline'].toString().isNotEmpty)
              _buildSection(
                '⏰ Estimated Timeline',
                _analysisResult!['timeline'].toString(),
                Icons.timeline,
                Colors.teal,
              ),
            
            const SizedBox(height: 8),
            
            if (_isTestMode)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.science, size: 16, color: Colors.blue),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Test mode: Connection successful! Your API is working.',
                          style: TextStyle(fontSize: 12, color: Colors.blue),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content, IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 20, color: color),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              content,
              style: const TextStyle(height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListSection(String title, List<String> items, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.list_alt, size: 20, color: color),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ...items.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('• ', style: TextStyle(color: color, fontSize: 14)),
                  Expanded(child: Text(item)),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }
}