// lib/screens/ai/ai_chatbot_screen.dart
// ignore_for_file: prefer_const_constructors, unused_field

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/ai_service.dart';
import 'package:intl/intl.dart';

class AIChatbotScreen extends StatefulWidget {
  const AIChatbotScreen({super.key});

  @override
  State<AIChatbotScreen> createState() => _AIChatbotScreenState();
}

class _AIChatbotScreenState extends State<AIChatbotScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  String? _currentProjectId;
  List<Map<String, dynamic>> _userProjects = [];
  String _userRole = 'student';
  String _userName = '';

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _addWelcomeMessage();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _addWelcomeMessage() {
    _messages.add(ChatMessage(
      text: '👋 Hello! I\'m your AI project assistant.\n\nI can help you with:\n• 📋 Checking your tasks and projects\n• ⏰ Tracking deadlines and progress\n• 💡 Getting project recommendations\n• 📊 Understanding project metrics\n\nWhat would you like to know?',
      isUser: false,
      timestamp: DateTime.now(),
    ));
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();
    
    if (userDoc.exists) {
      final data = userDoc.data() as Map<String, dynamic>;
      setState(() {
        _userRole = data['role'] ?? 'student';
        _userName = data['name'] ?? 'User';
      });
      
      await _loadUserProjects(user.uid);
    }
  }

  Future<void> _loadUserProjects(String userId) async {
    // Get projects where user is member or leader
    final projectsSnapshot = await FirebaseFirestore.instance
        .collection('projects')
        .where('members', arrayContains: userId)
        .get();
    
    final ledProjectsSnapshot = await FirebaseFirestore.instance
        .collection('projects')
        .where('leaderId', isEqualTo: userId)
        .get();
    
    final allProjects = <Map<String, dynamic>>[];
    
    for (var doc in projectsSnapshot.docs) {
      final data = doc.data();
      allProjects.add({
        'id': doc.id,
        'title': data['title'] ?? 'Untitled',
        'status': data['status'] ?? 'pending',
        'progress': data['progress'] ?? 0,
      });
    }
    
    for (var doc in ledProjectsSnapshot.docs) {
      final data = doc.data();
      if (!allProjects.any((p) => p['id'] == doc.id)) {
        allProjects.add({
          'id': doc.id,
          'title': data['title'] ?? 'Untitled',
          'status': data['status'] ?? 'pending',
          'progress': data['progress'] ?? 0,
        });
      }
    }
    
    setState(() {
      _userProjects = allProjects;
      if (_userProjects.isNotEmpty) {
        _currentProjectId = _userProjects.first['id'];
      }
    });
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    // Add user message
    setState(() {
      _messages.add(ChatMessage(
        text: message,
        isUser: true,
        timestamp: DateTime.now(),
      ));
      _messageController.clear();
      _isLoading = true;
    });

    _scrollToBottom();

    try {
      // Get project context if a project is selected
      String projectContext = '';
      String projectTitle = '';
      
      if (_currentProjectId != null) {
        final projectDoc = await FirebaseFirestore.instance
            .collection('projects')
            .doc(_currentProjectId)
            .get();
        
        if (projectDoc.exists) {
          final data = projectDoc.data() as Map<String, dynamic>;
          projectTitle = data['title'] ?? 'Project';
          projectContext = '''
Project Context:
- Title: ${data['title']}
- Status: ${data['status']}
- Progress: ${data['progress']}%
- Sustainability Score: ${data['sustainabilityScore'] ?? 0}/100
- Environment: ${data['environment'] ?? 0}/100
- Energy: ${data['energy'] ?? 0}/100
- Waste: ${data['waste'] ?? 0}/100
- Community: ${data['community'] ?? 0}/100
- Innovation: ${data['innovation'] ?? 0}/100
''';
        }
      }

      // Get user's recent tasks for context
      final currentUser = FirebaseAuth.instance.currentUser;
      String tasksContext = '';
      
      if (currentUser != null) {
        final tasksSnapshot = await FirebaseFirestore.instance
            .collection('tasks')
            .where('assignedTo', isEqualTo: currentUser.uid)
            .where('status', isNotEqualTo: 'completed')
            .limit(5)
            .get();
        
        if (tasksSnapshot.docs.isNotEmpty) {
          tasksContext = '\nYour Active Tasks:\n';
          for (var doc in tasksSnapshot.docs) {
            final data = doc.data();
            tasksContext += '• ${data['title']} - ${data['progress']}% complete\n';
          }
        }
      }

      // Call AI service
      final response = await AIService.chatWithProjectAI(
        userMessage: message,
        projectContext: projectContext,
        tasksContext: tasksContext,
        userRole: _userRole,
        projectTitle: projectTitle,
      );

      setState(() {
        _messages.add(ChatMessage(
          text: response,
          isUser: false,
          timestamp: DateTime.now(),
        ));
        _isLoading = false;
      });
      
      _scrollToBottom();
      
    } catch (e) {
      setState(() {
        _messages.add(ChatMessage(
          text: 'Sorry, I encountered an error. Please try again.\n\nError: $e',
          isUser: false,
          timestamp: DateTime.now(),
        ));
        _isLoading = false;
      });
    }
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showQuickActions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Quick Questions',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            const Divider(),
            _buildQuickAction('📋 Show me my tasks', 'What tasks are assigned to me?'),
            _buildQuickAction('⏰ Upcoming deadlines', 'What tasks are due soon?'),
            _buildQuickAction('📊 Project progress', 'How is my project progressing?'),
            _buildQuickAction('💡 Get advice', 'Give me advice to improve my project'),
            _buildQuickAction('🎯 Sustainability tips', 'How can I improve sustainability?'),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAction(String label, String message) {
    return ListTile(
      leading: const Icon(Icons.auto_awesome, color: Colors.green),
      title: Text(label),
      onTap: () {
        Navigator.pop(context);
        _messageController.text = message;
        _sendMessage();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Assistant'),
        backgroundColor: Colors.green,
        actions: [
          // Project selector dropdown
          if (_userProjects.isNotEmpty)
            Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(20),
              ),
              child: DropdownButton<String>(
                value: _currentProjectId,
                dropdownColor: Colors.green,
                underline: const SizedBox(),
                style: const TextStyle(color: Colors.white),
                icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
                items: [
                  const DropdownMenuItem(
                    value: null,
                    child: Text('All Projects'),
                  ),
                  ..._userProjects.map((project) {
                    return DropdownMenuItem(
                      value: project['id'].toString(),
                      child: Text(project['title'].toString()),
                    );
                  }),
                ],
                onChanged: (value) {
                  setState(() {
                    _currentProjectId = value;
                  });
                },
              ),
            ),
          // Clear chat button
          IconButton(
            icon: const Icon(Icons.delete_sweep),
            onPressed: () {
              setState(() {
                _messages.clear();
                _addWelcomeMessage();
              });
            },
            tooltip: 'Clear chat',
          ),
        ],
      ),
      body: Column(
        children: [
          // Chat messages area
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              reverse: true,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[_messages.length - 1 - index];
                return _buildMessageBubble(message);
              },
            ),
          ),
          
          // Typing indicator
          if (_isLoading)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                      SizedBox(width: 8),
                      Text('AI is thinking...'),
                    ],
                  ),
                ),
              ),
            ),
          
          // Input area
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade300,
                  offset: const Offset(0, -2),
                  blurRadius: 4,
                ),
              ],
            ),
            child: Row(
              children: [
                // Quick actions button
                IconButton(
                  icon: const Icon(Icons.bolt, color: Colors.green),
                  onPressed: _showQuickActions,
                  tooltip: 'Quick actions',
                ),
                
                // Text input
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Ask me anything about your projects...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    ),
                    maxLines: null,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                
                // Send button
                Container(
                  margin: const EdgeInsets.only(left: 8),
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 20),
                    onPressed: _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isUser = message.isUser;
    
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        child: Column(
          crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isUser ? Colors.green : Colors.grey.shade200,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                message.text,
                style: TextStyle(
                  color: isUser ? Colors.white : Colors.black87,
                  fontSize: 14,
                ),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              DateFormat('HH:mm').format(message.timestamp),
              style: TextStyle(
                fontSize: 10,
                color: Colors.grey.shade500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  
  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}