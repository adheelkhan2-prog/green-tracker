// ignore_for_file: prefer_const_constructors, avoid_print, use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/ai_service.dart';

class ImpactPredictionScreen extends StatefulWidget {
  const ImpactPredictionScreen({super.key});

  @override
  State<ImpactPredictionScreen> createState() => _ImpactPredictionScreenState();
}

class _ImpactPredictionScreenState extends State<ImpactPredictionScreen> {
  String? _selectedProjectId;
  List<Map<String, dynamic>> _projects = [];
  bool _isLoading = true;
  bool _isPredicting = false;
  Map<String, dynamic>? _prediction;
  String? _comparisonResult;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadProjects();
  }

  Future<void> _loadProjects() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('projects')
          .orderBy('sustainabilityScore', descending: true)
          .get();
      
      if (snapshot.docs.isEmpty) {
        setState(() {
          _error = 'No projects found. Create a project first to predict impact.';
          _isLoading = false;
        });
        return;
      }
      
      setState(() {
        _projects = snapshot.docs.map((doc) {
          final data = doc.data();
          return {
            'id': doc.id,
            'title': data['title'] ?? 'Untitled',
            'description': data['description'] ?? '',
            'status': data['status'] ?? 'pending',
            'progress': data['progress'] ?? 0,
            'sustainabilityScore': (data['sustainabilityScore'] ?? 0).toDouble(),
            'environment': (data['environment'] ?? 0).toDouble(),
            'energy': (data['energy'] ?? 0).toDouble(),
            'waste': (data['waste'] ?? 0).toDouble(),
            'community': (data['community'] ?? 0).toDouble(),
            'innovation': (data['innovation'] ?? 0).toDouble(),
            'projectType': data['projectTypeId'],
          };
        }).toList();
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading projects: $e');
      setState(() {
        _error = 'Error loading projects: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _testPredictionConnection() async {
    setState(() {
      _isPredicting = true;
      _error = null;
    });
    
    try {
      final isWorking = await AIService.testConnection();
      if (mounted) {
        if (isWorking) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ AI Prediction service is working! Mistral API connected.'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 3),
            ),
          );
          
          // Show a sample prediction to demonstrate it's working
          setState(() {
            _prediction = {
              'carbonReduction': 1250,
              'wasteReduction': 45,
              'energySavings': 35,
              'waterConservation': 25000,
              'communityReach': 500,
              'roiTimeline': '8-12 months',
              'impactScore': 78,
              'successProbability': 82,
              'nextSteps': [
                '✅ AI connection successful!',
                '📋 Select a project to predict impact',
                '🎯 Click "Predict Impact" to generate insights',
              ],
              'risks': [
                '⚠️ None - This is a test message',
                '💡 Your API is working correctly',
              ],
            };
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('❌ AI service not responding. Check API key in ai_service.dart'),
              backgroundColor: Colors.red,
              duration: Duration(seconds: 5),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Connection Error: $e'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isPredicting = false);
      }
    }
  }

  Future<void> _predictImpact() async {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a project first'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isPredicting = true;
      _prediction = null;
      _error = null;
    });

    try {
      final project = _projects.firstWhere((p) => p['id'] == _selectedProjectId);
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('🤖 AI is predicting impact... This may take a few seconds.'),
          backgroundColor: Colors.blue,
          duration: Duration(seconds: 2),
        ),
      );
      
      final result = await AIService.predictImpact(project);
      
      if (mounted) {
        setState(() {
          _prediction = result;
          _isPredicting = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Impact prediction complete!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      print('Prediction error: $e');
      if (mounted) {
        setState(() {
          _error = 'Prediction failed: $e';
          _isPredicting = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Prediction failed: $e'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
      }
    }
  }

  Future<void> _compareProjects() async {
    if (_projects.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Need at least 2 projects to compare'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isPredicting = true;
      _comparisonResult = null;
      _error = null;
    });
    
    try {
      final topProjects = _projects.take(3).toList();
      final result = await AIService.compareProjects(topProjects);
      
      if (mounted) {
        setState(() {
          _comparisonResult = result;
          _isPredicting = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Comparison complete!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      print('Comparison error: $e');
      if (mounted) {
        setState(() {
          _error = 'Comparison failed: $e';
          _isPredicting = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Comparison failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Impact Prediction'),
        backgroundColor: Colors.green,
        actions: [
          // Test Connection Button
          IconButton(
            icon: const Icon(Icons.science),
            onPressed: _isPredicting ? null : _testPredictionConnection,
            tooltip: 'Test AI Connection',
          ),
          // Compare Projects Button
          IconButton(
            icon: const Icon(Icons.compare_arrows),
            onPressed: _isPredicting ? null : _compareProjects,
            tooltip: 'Compare Projects',
          ),
          // Refresh Button
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _isPredicting ? null : _loadProjects,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading projects...'),
                ],
              ),
            )
          : _error != null && _projects.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, size: 64, color: Colors.red),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(
                          _error!,
                          style: const TextStyle(color: Colors.red),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadProjects,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // API Status Card
                      Card(
                        color: Colors.blue.shade50,
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              const Icon(Icons.auto_awesome, color: Colors.blue),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      '🤖 Mistral AI Impact Predictor',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                    Text(
                                      'Predicts carbon reduction, energy savings, and community impact',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Colors.blue.shade700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.science, size: 20),
                                onPressed: _isPredicting ? null : _testPredictionConnection,
                                tooltip: 'Test Connection',
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Project Selection Card
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Select Project for Impact Prediction',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 12),
                              
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey.shade300),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: _selectedProjectId,
                                    isExpanded: true,
                                    hint: const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 16),
                                      child: Text('-- Select a project --'),
                                    ),
                                    items: [
                                      ..._projects.map<DropdownMenuItem<String>>((project) {
                                        final score = (project['sustainabilityScore'] ?? 0).toDouble();
                                        return DropdownMenuItem<String>(
                                          value: project['id'].toString(),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  project['title'].toString(),
                                                  style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                                const SizedBox(height: 4),
                                                Row(
                                                  children: [
                                                    Icon(
                                                      Icons.eco,
                                                      size: 14,
                                                      color: _getScoreColor(score),
                                                    ),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      'Score: ${score.toStringAsFixed(1)}/100',
                                                      style: TextStyle(
                                                        fontSize: 12,
                                                        color: _getScoreColor(score),
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                    const SizedBox(width: 12),
                                                    Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      decoration: BoxDecoration(
                                                        color: Colors.grey.shade200,
                                                        borderRadius: BorderRadius.circular(12),
                                                      ),
                                                      child: Text(
                                                        project['status'].toString(),
                                                        style: const TextStyle(fontSize: 10),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 12),
                                                    Text(
                                                      'Progress: ${project['progress']}%',
                                                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      }),
                                    ],
                                    onChanged: (value) {
                                      setState(() {
                                        _selectedProjectId = value;
                                        _prediction = null;
                                        _error = null;
                                      });
                                    },
                                  ),
                                ),
                              ),
                              
                              const SizedBox(height: 16),
                              
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: (_isPredicting || _selectedProjectId == null) ? null : _predictImpact,
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                        padding: const EdgeInsets.symmetric(vertical: 14),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                      ),
                                      child: _isPredicting
                                          ? const SizedBox(
                                              width: 24,
                                              height: 24,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                                color: Colors.white,
                                              ),
                                            )
                                          : const Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Icon(Icons.trending_up, size: 18),
                                                SizedBox(width: 8),
                                                Text(
                                                  'Predict Impact',
                                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                                ),
                                              ],
                                            ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: OutlinedButton(
                                      onPressed: _isPredicting ? null : _compareProjects,
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: Colors.green,
                                        padding: const EdgeInsets.symmetric(vertical: 14),
                                        side: const BorderSide(color: Colors.green),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                      ),
                                      child: const Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.compare_arrows, size: 18),
                                          SizedBox(width: 8),
                                          Text('Compare'),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Error Display
                      if (_error != null && _prediction == null && _comparisonResult == null && !_isPredicting)
                        Card(
                          color: Colors.red.shade50,
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                const Icon(Icons.error_outline, color: Colors.red, size: 48),
                                const SizedBox(height: 12),
                                Text(
                                  _error!,
                                  style: const TextStyle(color: Colors.red),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 16),
                                ElevatedButton.icon(
                                  onPressed: _testPredictionConnection,
                                  icon: const Icon(Icons.science),
                                  label: const Text('Test AI Connection'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.orange,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      
                      // Prediction Results
                      if (_prediction != null)
                        _buildPredictionResult(),
                      
                      // Comparison Results
                      if (_comparisonResult != null)
                        _buildComparisonResult(),
                      
                      // Help Card
                      if (_prediction == null && _comparisonResult == null && _error == null && !_isPredicting && _projects.isNotEmpty)
                        Card(
                          color: Colors.grey.shade50,
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                const Icon(Icons.trending_up, size: 48, color: Colors.grey),
                                const SizedBox(height: 12),
                                const Text(
                                  'Ready to predict impact!',
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Select a project above and tap "Predict Impact" to see AI-powered predictions about carbon reduction, energy savings, and community impact.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.grey.shade600),
                                ),
                                const SizedBox(height: 12),
                                const Text(
                                  '🧪 Tap the science icon to test your AI connection first',
                                  style: TextStyle(fontSize: 12, color: Colors.blue),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildPredictionResult() {
    // Check if this is a test result
    final isTestResult = _prediction!['carbonReduction'] == 1250 && 
                         _prediction!['wasteReduction'] == 45;
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.trending_up, color: Colors.green, size: 28),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Impact Predictions',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      if (isTestResult)
                        Text(
                          'Test Mode - Connection Successful',
                          style: TextStyle(fontSize: 11, color: Colors.blue.shade700),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => setState(() => _prediction = null),
                ),
              ],
            ),
            const SizedBox(height: 20),
            
            // Carbon Reduction
            if (_prediction!['carbonReduction'] != null)
              _buildMetricCard(
                '🌍 Carbon Reduction',
                '${_prediction!['carbonReduction']} tons CO2/year',
                'Expected annual reduction in carbon emissions',
                Colors.green,
              ),
            
            const SizedBox(height: 12),
            
            // Waste Reduction
            if (_prediction!['wasteReduction'] != null)
              _buildMetricCard(
                '♻️ Waste Reduction',
                '${_prediction!['wasteReduction']}%',
                'Expected reduction in waste generation',
                Colors.blue,
              ),
            
            const SizedBox(height: 12),
            
            // Energy Savings
            if (_prediction!['energySavings'] != null)
              _buildMetricCard(
                '⚡ Energy Savings',
                '${_prediction!['energySavings']}%',
                'Expected reduction in energy consumption',
                Colors.cyan,
              ),
            
            const SizedBox(height: 12),
            
            // Water Conservation
            if (_prediction!['waterConservation'] != null)
              _buildMetricCard(
                '💧 Water Conservation',
                '${_prediction!['waterConservation']} liters/year',
                'Estimated water savings annually',
                Colors.teal,
              ),
            
            const SizedBox(height: 12),
            
            // Community Impact
            if (_prediction!['communityReach'] != null)
              _buildMetricCard(
                '👥 Community Impact',
                '${_prediction!['communityReach']}+ people',
                'Estimated number of beneficiaries',
                Colors.purple,
              ),
            
            const SizedBox(height: 12),
            
            // ROI Timeline
            if (_prediction!['roiTimeline'] != null)
              _buildMetricCard(
                '💰 ROI Timeline',
                _prediction!['roiTimeline'],
                'Expected time to see returns on investment',
                Colors.orange,
              ),
            
            const SizedBox(height: 12),
            
            // Impact Score
            if (_prediction!['impactScore'] != null)
              _buildImpactScoreCard(),
            
            const SizedBox(height: 12),
            
            // Success Probability
            if (_prediction!['successProbability'] != null)
              _buildProbabilityCard(),
            
            const SizedBox(height: 16),
            
            // Next Steps
            if (_prediction!['nextSteps'] != null)
              _buildNextStepsCard(),
            
            const SizedBox(height: 16),
            
            // Risk Factors
            if (_prediction!['risks'] != null)
              _buildRiskFactors(),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricCard(String title, String value, String subtitle, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 12,
                      color: color,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImpactScoreCard() {
    final impactScore = (_prediction!['impactScore'] as num).toInt();
    Color scoreColor;
    String impactLevel;
    
    if (impactScore >= 70) {
      scoreColor = Colors.green;
      impactLevel = 'High Impact Potential';
    } else if (impactScore >= 40) {
      scoreColor = Colors.orange;
      impactLevel = 'Moderate Impact Potential';
    } else {
      scoreColor = Colors.red;
      impactLevel = 'Low Impact Potential';
    }
    
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [scoreColor.withOpacity(0.1), scoreColor.withOpacity(0.05)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: scoreColor.withOpacity(0.3)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              '🎯 Overall Impact Score',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  height: 100,
                  width: 100,
                  child: CircularProgressIndicator(
                    value: impactScore / 100,
                    strokeWidth: 8,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation(scoreColor),
                  ),
                ),
                Column(
                  children: [
                    Text(
                      '$impactScore',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: scoreColor,
                      ),
                    ),
                    const Text(
                      'out of 100',
                      style: TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              impactLevel,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: scoreColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProbabilityCard() {
    final probability = (_prediction!['successProbability'] as num).toInt();
    Color probabilityColor;
    if (probability >= 70) {
      probabilityColor = Colors.green;
    } else if (probability >= 40) {
      probabilityColor = Colors.orange;
    } else {
      probabilityColor = Colors.red;
    }
    
    return Container(
      decoration: BoxDecoration(
        color: probabilityColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: probabilityColor.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '📈 Success Probability',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: LinearProgressIndicator(
                    value: probability / 100,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation(probabilityColor),
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  '$probability%',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: probabilityColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNextStepsCard() {
    final nextSteps = List<String>.from(_prediction!['nextSteps']);
    
    return Container(
      decoration: BoxDecoration(
        color: Colors.green.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '🎯 Recommended Next Steps',
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green),
            ),
            const SizedBox(height: 8),
            ...nextSteps.map((step) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.arrow_forward, size: 14, color: Colors.green),
                  const SizedBox(width: 8),
                  Expanded(child: Text(step)),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildRiskFactors() {
    final risks = List<String>.from(_prediction!['risks']);
    
    return Container(
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '⚠️ Risk Factors to Consider',
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
            ),
            const SizedBox(height: 8),
            ...risks.map((risk) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  const Icon(Icons.warning, size: 14, color: Colors.red),
                  const SizedBox(width: 8),
                  Expanded(child: Text(risk)),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildComparisonResult() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade100,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.compare, color: Colors.blue),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Project Comparison',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => setState(() => _comparisonResult = null),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                _comparisonResult ?? '',
                style: const TextStyle(height: 1.6),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 70) return Colors.green;
    if (score >= 40) return Colors.orange;
    return Colors.red;
  }
}