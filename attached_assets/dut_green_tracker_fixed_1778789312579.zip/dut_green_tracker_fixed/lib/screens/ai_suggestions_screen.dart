// ignore_for_file: prefer_const_constructors, prefer_const_declarations, avoid_print, deprecated_member_use, unnecessary_brace_in_string_interps

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/ai_service.dart';

class AISuggestionsScreen extends StatefulWidget {
  const AISuggestionsScreen({super.key});

  @override
  State<AISuggestionsScreen> createState() => _AISuggestionsScreenState();
}

class _AISuggestionsScreenState extends State<AISuggestionsScreen> {
  String? _selectedProjectId;
  List<Map<String, dynamic>> _projects = [];
  Map<String, dynamic>? _suggestions;
  bool _isLoading = false;
  
  // Chat related
  final TextEditingController _chatController = TextEditingController();
  final List<Map<String, dynamic>> _chatMessages = [];
  bool _isChatLoading = false;
  bool _showChat = false;

  @override
  void initState() {
    super.initState();
    _loadProjects();
    _addWelcomeMessage();
  }

  void _addWelcomeMessage() {
    _chatMessages.add({
      'isUser': false,
      'message': '👋 Hi! I\'m your AI project assistant. Ask me anything about this project!',
      'timestamp': DateTime.now(),
    });
  }

  Future<void> _loadProjects() async {
    final snapshot = await FirebaseFirestore.instance.collection('projects').get();
    setState(() {
      _projects = snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Untitled',
          'progress': data['progress'] ?? 0,
          'status': data['status'] ?? 'pending',
          'description': data['description'] ?? '',
          'sustainabilityScore': data['sustainabilityScore'] ?? 0,
          'environment': data['environment'] ?? 0,
          'energy': data['energy'] ?? 0,
          'waste': data['waste'] ?? 0,
          'community': data['community'] ?? 0,
          'innovation': data['innovation'] ?? 0,
        };
      }).toList();
    });
  }

  Future<void> _getSuggestions() async {
    if (_selectedProjectId == null) return;
    
    setState(() => _isLoading = true);
    
    try {
      final project = _projects.firstWhere((p) => p['id'] == _selectedProjectId);
      
      // Call real AI service for analysis
      final aiResult = await AIService.analyzeProject(project);
      
      // Get additional project data
      final progress = project['progress'];
      final title = project['title'];
      final score = project['sustainabilityScore'] ?? 0;
      
      // Determine color based on progress and AI analysis
      Color color;
      if (progress < 30) {
        color = Colors.blue;
      } else if (progress < 70) {
        color = Colors.orange;
      } else if (progress < 100) {
        color = Colors.green;
      } else {
        color = Colors.purple;
      }
      
      // Adjust color based on sustainability score
      if (score < 40 && color != Colors.blue) {
        color = Colors.red;
      } else if (score > 80 && progress < 100) {
        color = Colors.teal;
      }
      
      // Create suggestion title based on AI summary
      String suggestion = aiResult['summary']?.substring(0, 50) ?? '';
      if (progress < 30) {
        suggestion = "🚀 ${suggestion.isNotEmpty ? suggestion : 'Project Just Started'}";
      } else if (progress < 70) {
        suggestion = "⚡ ${suggestion.isNotEmpty ? suggestion : 'Project In Progress'}";
      } else if (progress < 100) {
        suggestion = "🎯 ${suggestion.isNotEmpty ? suggestion : 'Project Near Completion'}";
      } else {
        suggestion = "🏆 ${suggestion.isNotEmpty ? suggestion : 'Project Completed'}";
      }
      
      setState(() {
        _suggestions = {
          'suggestion': suggestion,
          'recommendation': aiResult['recommendations']?.join('\n• ') ?? 'Continue making progress on your project.',
          'actionItems': aiResult['recommendations'] ?? [
            'Review project metrics regularly',
            'Communicate with team members',
            'Update task progress daily',
          ],
          'strengths': aiResult['strengths'] ?? [],
          'weaknesses': aiResult['weaknesses'] ?? [],
          'timeline': aiResult['timeline'] ?? 'Timeline not specified',
          'color': color,
          'progress': progress,
          'title': title,
          'score': score,
        };
        _isLoading = false;
      });
    } catch (e) {
      print('Error getting AI suggestions: $e');
      setState(() {
        _isLoading = false;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      });
    }
  }

  Future<void> _sendChatMessage() async {
    final message = _chatController.text.trim();
    if (message.isEmpty || _selectedProjectId == null) return;
    
    // Add user message
    setState(() {
      _chatMessages.add({
        'isUser': true,
        'message': message,
        'timestamp': DateTime.now(),
      });
      _chatController.clear();
      _isChatLoading = true;
    });
    
    // Get project context
    final project = _projects.firstWhere((p) => p['id'] == _selectedProjectId);
    
    try {
      // Build context for AI
      final projectContext = '''
Project: ${project['title']}
Progress: ${project['progress']}%
Status: ${project['status']}
Sustainability Score: ${project['sustainabilityScore']}/100
Environment: ${project['environment']}/100
Energy: ${project['energy']}/100
Waste: ${project['waste']}/100
Community: ${project['community']}/100
Innovation: ${project['innovation']}/100
Description: ${project['description']}
''';
      
      final tasksContext = ''; // Can add tasks if needed
      
      // Call real AI service for chat
      final aiResponse = await AIService.chatWithProjectAI(
        userMessage: message,
        projectContext: projectContext,
        tasksContext: tasksContext,
        userRole: 'user',
        projectTitle: project['title'],
      );
      
      setState(() {
        _chatMessages.add({
          'isUser': false,
          'message': aiResponse,
          'timestamp': DateTime.now(),
        });
        _isChatLoading = false;
      });
    } catch (e) {
      print('Chat error: $e');
      setState(() {
        _chatMessages.add({
          'isUser': false,
          'message': 'Sorry, I encountered an error. Please try again.\n\nError: $e',
          'timestamp': DateTime.now(),
        });
        _isChatLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Project Assistant'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              _loadProjects();
            },
          ),
          IconButton(
            icon: Icon(_showChat ? Icons.analytics : Icons.chat),
            onPressed: () {
              setState(() {
                _showChat = !_showChat;
              });
            },
            tooltip: _showChat ? 'View Suggestions' : 'Chat with AI',
          ),
        ],
      ),
      body: Column(
        children: [
          // Project Selection (always visible)
          Padding(
            padding: const EdgeInsets.all(16),
            child: DropdownButtonFormField<String>(
              value: _selectedProjectId,
              decoration: const InputDecoration(
                labelText: 'Select Project',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.folder),
              ),
              items: [
                const DropdownMenuItem(
                  value: null,
                  child: Text('-- Select a project --'),
                ),
                ..._projects.map((project) {
                  return DropdownMenuItem(
                    value: project['id'],
                    child: Row(
                      children: [
                        Expanded(child: Text(project['title'])),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: _getProgressColor(project['progress']),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${project['progress']}%',
                            style: const TextStyle(fontSize: 12, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ],
              onChanged: (value) {
                setState(() {
                  _selectedProjectId = value;
                  _suggestions = null;
                  _chatMessages.clear();
                  _addWelcomeMessage();
                });
              },
            ),
          ),
          
          // Toggle between Suggestions and Chat
          Expanded(
            child: _showChat ? _buildChatView() : _buildSuggestionsView(),
          ),
        ],
      ),
    );
  }

  Widget _buildSuggestionsView() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Get Suggestions Button
          ElevatedButton(
            onPressed: _selectedProjectId == null ? null : _getSuggestions,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              minimumSize: const Size(double.infinity, 50),
              disabledBackgroundColor: Colors.grey[300],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              'Get AI Suggestions',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Loading Indicator
          if (_isLoading)
            const Expanded(
              child: Center(child: CircularProgressIndicator()),
            ),
          
          // Suggestions Result
          if (_suggestions != null && !_isLoading)
            Expanded(
              child: SingleChildScrollView(
                child: Card(
                  elevation: 4,
                  color: _suggestions!['color'].withOpacity(0.1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Icon(
                          Icons.auto_awesome,
                          size: 64,
                          color: _suggestions!['color'],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _suggestions!['suggestion'],
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: _suggestions!['color'],
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        
                        // Progress Section
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            children: [
                              const Text(
                                'Current Progress',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey,
                                ),
                              ),
                              const SizedBox(height: 8),
                              LinearProgressIndicator(
                                value: _suggestions!['progress'] / 100,
                                backgroundColor: Colors.grey[200],
                                valueColor: AlwaysStoppedAnimation<Color>(_suggestions!['color']),
                                minHeight: 10,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '${_suggestions!['progress']}% Complete',
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        const SizedBox(height: 16),
                        
                        // Sustainability Score
                        if (_suggestions!['score'] != null)
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _getScoreColor(_suggestions!['score']).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.eco, color: _getScoreColor(_suggestions!['score'])),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Sustainability Score',
                                        style: TextStyle(fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        '${_suggestions!['score']}/100',
                                        style: TextStyle(
                                          color: _getScoreColor(_suggestions!['score']),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        
                        const SizedBox(height: 16),
                        
                        // AI Recommendation
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.blue.shade50,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                '🤖 AI Recommendation',
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                _suggestions!['recommendation'],
                                style: const TextStyle(height: 1.4),
                              ),
                            ],
                          ),
                        ),
                        
                        const SizedBox(height: 16),
                        
                        // Strengths
                        if (_suggestions!['strengths'] != null && (_suggestions!['strengths'] as List).isNotEmpty)
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.green.shade50,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  '✅ Strengths',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 8),
                                ...(_suggestions!['strengths'] as List<String>).map((item) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 2),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.check_circle, size: 14, color: Colors.green),
                                        const SizedBox(width: 8),
                                        Expanded(child: Text(item)),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),
                        
                        const SizedBox(height: 16),
                        
                        // Weaknesses
                        if (_suggestions!['weaknesses'] != null && (_suggestions!['weaknesses'] as List).isNotEmpty)
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.orange.shade50,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  '⚠️ Areas for Improvement',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 8),
                                ...(_suggestions!['weaknesses'] as List<String>).map((item) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 2),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.warning, size: 14, color: Colors.orange),
                                        const SizedBox(width: 8),
                                        Expanded(child: Text(item)),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),
                        
                        const SizedBox(height: 16),
                        
                        // Action Items
                        if (_suggestions!['actionItems'] != null && (_suggestions!['actionItems'] as List).isNotEmpty)
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.purple.shade50,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  '🎯 Recommended Actions',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 8),
                                ...(_suggestions!['actionItems'] as List<String>).map((item) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 2),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.star, size: 14, color: Colors.purple),
                                        const SizedBox(width: 8),
                                        Expanded(child: Text(item)),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),
                        
                        // Estimated Timeline
                        if (_suggestions!['timeline'] != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 16),
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.teal.shade50,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                children: [
                                  Icon(Icons.timeline, color: Colors.teal),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Estimated Timeline',
                                          style: TextStyle(fontWeight: FontWeight.bold),
                                        ),
                                        Text(_suggestions!['timeline']),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        
                        const SizedBox(height: 16),
                        
                        if (_suggestions!['progress'] < 100)
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Update project progress from project details'),
                                  ),
                                );
                              },
                              icon: const Icon(Icons.trending_up),
                              label: const Text('Update Progress'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _suggestions!['color'],
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          
          // Empty state
          if (_suggestions == null && !_isLoading && _selectedProjectId != null)
            const Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.psychology, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text(
                      'Tap "Get AI Suggestions" to see insights',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
          
          if (_selectedProjectId == null)
            const Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.folder_open, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text(
                      'Select a project to get AI insights',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildChatView() {
    return Column(
      children: [
        // Chat Messages
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            reverse: false,
            itemCount: _chatMessages.length,
            itemBuilder: (context, index) {
              final message = _chatMessages[index];
              final isUser = message['isUser'];
              final time = message['timestamp'] as DateTime;
              
              return Align(
                alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: isUser ? Colors.green : Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.75,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        message['message'],
                        style: TextStyle(
                          color: isUser ? Colors.white : Colors.black87,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}',
                        style: TextStyle(
                          fontSize: 10,
                          color: isUser ? Colors.white70 : Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        
        // Typing indicator
        if (_isChatLoading)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    SizedBox(width: 8),
                    Text('AI is typing...'),
                  ],
                ),
              ),
            ),
          ),
        
        // Chat Input
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.shade300,
                offset: const Offset(0, -2),
                blurRadius: 4,
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatController,
                  decoration: InputDecoration(
                    hintText: _selectedProjectId == null 
                        ? 'Select a project first' 
                        : 'Ask me about the project...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  onSubmitted: (_) => _sendChatMessage(),
                  enabled: _selectedProjectId != null,
                ),
              ),
              const SizedBox(width: 8),
              CircleAvatar(
                backgroundColor: Colors.green,
                child: IconButton(
                  icon: const Icon(Icons.send, color: Colors.white, size: 20),
                  onPressed: _selectedProjectId == null ? null : _sendChatMessage,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Color _getProgressColor(int progress) {
    if (progress < 30) return Colors.blue;
    if (progress < 70) return Colors.orange;
    return Colors.green;
  }

  Color _getScoreColor(double score) {
    if (score >= 70) return Colors.green;
    if (score >= 40) return Colors.orange;
    return Colors.red;
  }

  @override
  void dispose() {
    _chatController.dispose();
    super.dispose();
  }
}