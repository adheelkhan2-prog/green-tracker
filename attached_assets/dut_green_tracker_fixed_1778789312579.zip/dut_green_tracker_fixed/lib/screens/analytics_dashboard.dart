// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fl_chart/fl_chart.dart';

class AnalyticsDashboard extends StatefulWidget {
  const AnalyticsDashboard({super.key});

  @override
  State<AnalyticsDashboard> createState() => _AnalyticsDashboardState();
}

class _AnalyticsDashboardState extends State<AnalyticsDashboard> {
  bool _isLoading = true;
  String? _error;
  
  // Analytics data
  int _totalProjects = 0;
  int _activeProjects = 0;
  int _completedProjects = 0;
  int _totalTasks = 0;
  int _completedTasks = 0;
  double _avgSustainabilityScore = 0;
  
  // Chart data
  List<BarChartGroupData> _projectStatusData = [];
  List<BarChartGroupData> _taskProgressData = [];
  List<PieChartSectionData> _sustainabilityPieData = [];

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
  }

  Future<void> _loadAnalytics() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() {
          _error = 'Please login to view analytics';
          _isLoading = false;
        });
        return;
      }

      // Load projects
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .get();

      final projects = projectsSnapshot.docs;
      _totalProjects = projects.length;
      _activeProjects = projects.where((p) => 
        p['status'].toString().toLowerCase() == 'active' || 
        p['status'].toString().toLowerCase() == 'in_progress'
      ).length;
      _completedProjects = projects.where((p) => 
        p['status'].toString().toLowerCase() == 'completed'
      ).length;

      // Calculate average sustainability score
      double totalScore = 0;
      for (var project in projects) {
        totalScore += (project['sustainabilityScore'] ?? 0).toDouble();
      }
      _avgSustainabilityScore = _totalProjects > 0 ? totalScore / _totalProjects : 0;

      // Load tasks
      final tasksSnapshot = await FirebaseFirestore.instance
          .collection('tasks')
          .get();

      _totalTasks = tasksSnapshot.docs.length;
      _completedTasks = tasksSnapshot.docs.where((t) => 
        t['progress'] == 100
      ).length;

      // Build chart data
      _buildChartData(projects, tasksSnapshot.docs);

      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Error loading analytics: $e';
        _isLoading = false;
      });
    }
  }

  void _buildChartData(List<QueryDocumentSnapshot> projects, List<QueryDocumentSnapshot> tasks) {
    // Project status bar chart data
    _projectStatusData = [
      BarChartGroupData(
        x: 0,
        barRods: [
          BarChartRodData(
            toY: _activeProjects.toDouble(),
            color: Colors.orange,
            width: 30,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
      BarChartGroupData(
        x: 1,
        barRods: [
          BarChartRodData(
            toY: _completedProjects.toDouble(),
            color: Colors.green,
            width: 30,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
      BarChartGroupData(
        x: 2,
        barRods: [
          BarChartRodData(
            toY: (_totalProjects - _activeProjects - _completedProjects).toDouble(),
            color: Colors.grey,
            width: 30,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    ];

    // Task progress bar chart data
    final pendingTasks = _totalTasks - _completedTasks;
    _taskProgressData = [
      BarChartGroupData(
        x: 0,
        barRods: [
          BarChartRodData(
            toY: _completedTasks.toDouble(),
            color: Colors.green,
            width: 30,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
      BarChartGroupData(
        x: 1,
        barRods: [
          BarChartRodData(
            toY: pendingTasks.toDouble(),
            color: Colors.orange,
            width: 30,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    ];

    // Sustainability pie chart data
    _sustainabilityPieData = [
      PieChartSectionData(
        value: _avgSustainabilityScore,
        title: '${_avgSustainabilityScore.toStringAsFixed(0)}%',
        color: _getScoreColor(_avgSustainabilityScore),
        radius: 80,
        titleStyle: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      PieChartSectionData(
        value: 100 - _avgSustainabilityScore,
        title: '',
        color: Colors.grey.shade300,
        radius: 80,
      ),
    ];
  }

  Color _getScoreColor(double score) {
    if (score >= 70) return Colors.green;
    if (score >= 40) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics Dashboard'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadAnalytics,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, size: 64, color: Colors.red),
                      const SizedBox(height: 16),
                      Text(_error!, style: const TextStyle(color: Colors.red)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadAnalytics,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Stats Cards Row 1
                      Row(
                        children: [
                          _buildStatCard('Total Projects', _totalProjects.toString(), Icons.folder, Colors.blue),
                          const SizedBox(width: 12),
                          _buildStatCard('Active Projects', _activeProjects.toString(), Icons.play_circle, Colors.orange),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _buildStatCard('Completed Projects', _completedProjects.toString(), Icons.check_circle, Colors.green),
                          const SizedBox(width: 12),
                          _buildStatCard('Total Tasks', _totalTasks.toString(), Icons.task, Colors.purple),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _buildStatCard('Completed Tasks', _completedTasks.toString(), Icons.done_all, Colors.teal),
                          const SizedBox(width: 12),
                          _buildStatCard('Avg Sustainability', '${_avgSustainabilityScore.toStringAsFixed(1)}%', Icons.eco, _getScoreColor(_avgSustainabilityScore)),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // Project Status Chart
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Project Status',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 16),
                              SizedBox(
                                height: 250,
                                child: BarChart(
                                  BarChartData(
                                    alignment: BarChartAlignment.spaceAround,
                                    maxY: (_totalProjects + 2).toDouble(),
                                    titlesData: FlTitlesData(
                                      leftTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          reservedSize: 40,
                                          getTitlesWidget: (value, meta) {
                                            return Text(value.toInt().toString());
                                          },
                                        ),
                                      ),
                                      bottomTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          getTitlesWidget: (value, meta) {
                                            const titles = ['Active', 'Completed', 'Pending'];
                                            if (value.toInt() >= 0 && value.toInt() < titles.length) {
                                              return Text(titles[value.toInt()]);
                                            }
                                            return const Text('');
                                          },
                                        ),
                                      ),
                                      topTitles: const AxisTitles(
                                        sideTitles: SideTitles(showTitles: false),
                                      ),
                                      rightTitles: const AxisTitles(
                                        sideTitles: SideTitles(showTitles: false),
                                      ),
                                    ),
                                    borderData: FlBorderData(show: false),
                                    barGroups: _projectStatusData,
                                    gridData: const FlGridData(show: true),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Task Progress Chart
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Task Progress',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 16),
                              SizedBox(
                                height: 250,
                                child: BarChart(
                                  BarChartData(
                                    alignment: BarChartAlignment.spaceAround,
                                    maxY: (_totalTasks + 2).toDouble(),
                                    titlesData: FlTitlesData(
                                      leftTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          reservedSize: 40,
                                          getTitlesWidget: (value, meta) {
                                            return Text(value.toInt().toString());
                                          },
                                        ),
                                      ),
                                      bottomTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          getTitlesWidget: (value, meta) {
                                            const titles = ['Completed', 'Pending'];
                                            if (value.toInt() >= 0 && value.toInt() < titles.length) {
                                              return Text(titles[value.toInt()]);
                                            }
                                            return const Text('');
                                          },
                                        ),
                                      ),
                                      topTitles: const AxisTitles(
                                        sideTitles: SideTitles(showTitles: false),
                                      ),
                                      rightTitles: const AxisTitles(
                                        sideTitles: SideTitles(showTitles: false),
                                      ),
                                    ),
                                    borderData: FlBorderData(show: false),
                                    barGroups: _taskProgressData,
                                    gridData: const FlGridData(show: true),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Sustainability Score Card
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Sustainability Score',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 16),
                              Center(
                                child: SizedBox(
                                  height: 200,
                                  width: 200,
                                  child: PieChart(
                                    PieChartData(
                                      sections: _sustainabilityPieData,
                                      centerSpaceRadius: 40,
                                      sectionsSpace: 2,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Center(
                                child: Text(
                                  'Average Sustainability Score: ${_avgSustainabilityScore.toStringAsFixed(1)}%',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Center(
                                child: Text(
                                  _getSustainabilityMessage(),
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: _getScoreColor(_avgSustainabilityScore),
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color),
                  ),
                  Text(
                    title,
                    style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getSustainabilityMessage() {
    if (_avgSustainabilityScore >= 70) {
      return 'Excellent! Your projects are making a great environmental impact. 🌟';
    } else if (_avgSustainabilityScore >= 40) {
      return 'Good progress! Focus on improving key metrics to reach higher scores. 📈';
    } else {
      return 'Needs attention. Consider implementing more sustainable practices. ⚠️';
    }
  }
}