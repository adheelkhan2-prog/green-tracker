// ignore_for_file: use_build_context_synchronously, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import './admin/admin_dashboard.dart';
import './dashboards/student_dashboard.dart';
import './dashboards/lecturer_dashboard.dart';
import './dashboards/team_leader_dashboard.dart';

class DashboardRouter extends StatefulWidget {
  const DashboardRouter({super.key});

  @override
  State<DashboardRouter> createState() => _DashboardRouterState();
}

class _DashboardRouterState extends State<DashboardRouter> {
  bool _isChecking = true;
  String? _dashboardType; // 'admin', 'team_leader', 'lecturer', 'student'
  String? _errorMessage;
  String? _activeProjectTitle;
  int _activeProjectCount = 0;

  @override
  void initState() {
    super.initState();
    _determineDashboard();
  }

  Future<void> _determineDashboard() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    
    if (currentUser == null) {
      setState(() {
        _errorMessage = 'Please login';
        _isChecking = false;
      });
      return;
    }

    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      
      if (!userDoc.exists) {
        setState(() {
          _errorMessage = 'User not found';
          _isChecking = false;
        });
        return;
      }

      final userData = userDoc.data() as Map<String, dynamic>;
      final role = userData['role'] ?? 'student';

      if (role == 'admin') {
        setState(() {
          _dashboardType = 'admin';
          _isChecking = false;
        });
        return;
      }

      if (role == 'lecturer') {
        // Check for stored preference
        final prefs = await _getStoredDashboardPreference(currentUser.uid);
        
        if (prefs != null && prefs['manualOverride'] == true) {
          // User manually selected a dashboard
          setState(() {
            _dashboardType = prefs['dashboardType'];
            _isChecking = false;
          });
          return;
        }
        
        // Check for active projects
        final activeProjectsQuery = await FirebaseFirestore.instance
            .collection('projects')
            .where('leaderId', isEqualTo: currentUser.uid)
            .where('status', isNotEqualTo: 'completed')
            .get();
        
        final hasActiveProjects = activeProjectsQuery.docs.isNotEmpty;
        _activeProjectCount = activeProjectsQuery.docs.length;
        
        if (activeProjectsQuery.docs.isNotEmpty) {
          _activeProjectTitle = activeProjectsQuery.docs.first.data()['title'];
        }
        
        if (hasActiveProjects) {
          // Show notification asking to switch to Team Leader Dashboard
          _showDashboardSwitchNotification(currentUser.uid);
          
          setState(() {
            _dashboardType = 'lecturer'; // Start with lecturer dashboard
            _isChecking = false;
          });
        } else {
          setState(() {
            _dashboardType = 'lecturer';
            _isChecking = false;
          });
        }
        return;
      }

      setState(() {
        _dashboardType = 'student';
        _isChecking = false;
      });
      
    } catch (e) {
      print('Error determining dashboard: $e');
      setState(() {
        _errorMessage = 'Error: $e';
        _isChecking = false;
      });
    }
  }

  Future<Map<String, dynamic>?> _getStoredDashboardPreference(String userId) async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('user_preferences')
          .doc(userId)
          .get();
      
      if (doc.exists) {
        return doc.data() as Map<String, dynamic>;
      }
    } catch (e) {
      print('Error getting preferences: $e');
    }
    return null;
  }

  Future<void> _saveDashboardPreference(String userId, String dashboardType, bool manualOverride) async {
    try {
      await FirebaseFirestore.instance
          .collection('user_preferences')
          .doc(userId)
          .set({
        'dashboardType': dashboardType,
        'manualOverride': manualOverride,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error saving preference: $e');
    }
  }

  void _showDashboardSwitchNotification(String userId) {
    // Show a persistent notification that user can act on
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.leaderboard, color: Colors.green, size: 24),
                ),
                const SizedBox(width: 12),
                const Text('Team Leader Available'),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'You are the team leader for active project(s):',
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '🎯 $_activeProjectCount active project(s)',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      if (_activeProjectTitle != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            'Current: $_activeProjectTitle',
                            style: TextStyle(fontSize: 12, color: Colors.green.shade700),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Switch to Team Leader Dashboard to:',
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                _buildBulletPoint('✓ Manage team members'),
                _buildBulletPoint('✓ Assign and track tasks'),
                _buildBulletPoint('✓ Submit weekly updates'),
                _buildBulletPoint('✓ View team feed and chat'),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  // Stay on Lecturer Dashboard
                  await _saveDashboardPreference(userId, 'lecturer', true);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('You can switch anytime from the dashboard menu'),
                      backgroundColor: Colors.grey,
                      duration: Duration(seconds: 3),
                    ),
                  );
                },
                child: const Text('Stay Here'),
              ),
              ElevatedButton(
                onPressed: () async {
                  Navigator.pop(context);
                  // Switch to Team Leader Dashboard
                  await _saveDashboardPreference(userId, 'team_leader', true);
                  setState(() {
                    _dashboardType = 'team_leader';
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Switched to Team Leader Dashboard'),
                      backgroundColor: Colors.green,
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Switch to Team Leader'),
              ),
            ],
          ),
        );
      }
    });
  }

  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          const Icon(Icons.check_circle, size: 14, color: Colors.green),
          const SizedBox(width: 8),
          Text(text),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isChecking) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Loading dashboard...'),
            ],
          ),
        ),
      );
    }

    if (_errorMessage != null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              Text(_errorMessage!),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _determineDashboard,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    switch (_dashboardType) {
      case 'admin':
        return const AdminDashboard();
        
      case 'team_leader':
        return const TeamLeaderDashboard();
        
      case 'lecturer':
        return const LecturerDashboard();
        
      default:
        return const StudentDashboard();
    }
  }
}