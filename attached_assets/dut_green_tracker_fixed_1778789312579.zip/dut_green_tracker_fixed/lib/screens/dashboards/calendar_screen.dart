// ignore_for_file: deprecated_member_use, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../models/task.dart';
import 'package:intl/intl.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  Map<DateTime, List<Task>> _tasksByDate = {};
  List<Task> _selectedDayTasks = [];
  bool _isLoading = true;
  String _viewMode = 'month'; // month, week, day

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    setState(() => _isLoading = true);
    
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    // Get tasks assigned to current user
    final tasksSnapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .where('assignedTo', isEqualTo: currentUser.uid)
        .get();

    final Map<DateTime, List<Task>> tasksByDate = {};

    for (var doc in tasksSnapshot.docs) {
      final data = doc.data();
      final task = Task.fromMap(data, doc.id);
      final deadline = task.deadline;
      
      // Normalize date (remove time component)
      final normalizedDate = DateTime(deadline.year, deadline.month, deadline.day);
      
      if (!tasksByDate.containsKey(normalizedDate)) {
        tasksByDate[normalizedDate] = [];
      }
      tasksByDate[normalizedDate]!.add(task);
    }

    setState(() {
      _tasksByDate = tasksByDate;
      _isLoading = false;
    });
    
    _updateSelectedDayTasks();
  }

  void _updateSelectedDayTasks() {
    if (_selectedDay != null) {
      final normalizedDate = DateTime(_selectedDay!.year, _selectedDay!.month, _selectedDay!.day);
      setState(() {
        _selectedDayTasks = _tasksByDate[normalizedDate] ?? [];
        // Sort by difficulty (hardest first)
        _selectedDayTasks.sort((a, b) => b.difficultyLevel.compareTo(a.difficultyLevel));
      });
    }
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _selectedDay = selectedDay;
      _focusedDay = focusedDay;
    });
    _updateSelectedDayTasks();
  }

  Color _getDifficultyColor(int difficulty) {
    if (difficulty <= 3) return Colors.green;
    if (difficulty <= 6) return Colors.orange;
    if (difficulty <= 8) return Colors.deepOrange;
    return Colors.red;
  }

  String _getDifficultyLabel(int difficulty) {
    if (difficulty <= 3) return 'Easy';
    if (difficulty <= 5) return 'Moderate';
    if (difficulty <= 7) return 'Challenging';
    if (difficulty <= 9) return 'Difficult';
    return 'Very Difficult';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task Calendar'),
        backgroundColor: Colors.green,
        centerTitle: false,
        actions: [
          // View mode toggle
          PopupMenuButton<String>(
            icon: const Icon(Icons.view_week),
            onSelected: (value) {
              setState(() {
                _viewMode = value;
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'month', child: Text('Month View')),
              const PopupMenuItem(value: 'week', child: Text('Week View')),
              const PopupMenuItem(value: 'day', child: Text('Day View')),
            ],
          ),
          // Refresh button
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadTasks,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Calendar
                TableCalendar(
                  firstDay: DateTime.now().subtract(const Duration(days: 365)),
                  lastDay: DateTime.now().add(const Duration(days: 365)),
                  focusedDay: _focusedDay,
                  selectedDayPredicate: (day) {
                    return isSameDay(_selectedDay, day);
                  },
                  onDaySelected: _onDaySelected,
                  calendarFormat: _viewMode == 'month' 
                      ? CalendarFormat.month 
                      : (_viewMode == 'week' ? CalendarFormat.week : CalendarFormat.twoWeeks),
                  eventLoader: (day) {
                    final normalizedDate = DateTime(day.year, day.month, day.day);
                    return _tasksByDate[normalizedDate] ?? [];
                  },
                  calendarStyle: CalendarStyle(
                    markerDecoration: const BoxDecoration(
                      color: Colors.orange,
                      shape: BoxShape.circle,
                    ),
                    todayDecoration: BoxDecoration(
                      color: Colors.green.shade100,
                      shape: BoxShape.circle,
                    ),
                    selectedDecoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                    ),
                  ),
                  headerStyle: const HeaderStyle(
                    titleCentered: true,
                    formatButtonVisible: false,
                    titleTextStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                const Divider(height: 20),
                
                // Selected Day Tasks
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const Icon(Icons.task, color: Colors.orange),
                      const SizedBox(width: 8),
                      Text(
                        'Tasks for ${DateFormat('dd MMM yyyy').format(_selectedDay!)}',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${_selectedDayTasks.length} tasks',
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                
                // Tasks List
                Expanded(
                  child: _selectedDayTasks.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.celebration, size: 64, color: Colors.grey),
                              SizedBox(height: 16),
                              Text(
                                'No tasks due on this day!',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Enjoy your day 🎉',
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _selectedDayTasks.length,
                          itemBuilder: (context, index) {
                            final task = _selectedDayTasks[index];
                            return _buildTaskCard(task);
                          },
                        ),
                ),
              ],
            ),
    );
  }

  Widget _buildTaskCard(Task task) {
    final difficultyColor = _getDifficultyColor(task.difficultyLevel);
    final isOverdue = task.deadline.isBefore(DateTime.now()) && task.progress != 100;
    final isCompleted = task.progress == 100;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isOverdue ? Colors.red : difficultyColor,
          width: isOverdue ? 2 : 1,
        ),
      ),
      child: InkWell(
        onTap: () {
          // Navigate to task evidence screen
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Task: ${task.title}'), backgroundColor: Colors.green),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              // Difficulty indicator
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: difficultyColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    task.difficultyLevel.toString(),
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: difficultyColor,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              
              // Task info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.title,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        decoration: isCompleted ? TextDecoration.lineThrough : null,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _getDifficultyLabel(task.difficultyLevel),
                      style: TextStyle(
                        fontSize: 10,
                        color: difficultyColor,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.assignment, size: 12, color: Colors.grey),
                        const SizedBox(width: 4),
                        Expanded(
                          child: FutureBuilder<DocumentSnapshot>(
                            future: FirebaseFirestore.instance
                                .collection('projects')
                                .doc(task.projectId)
                                .get(),
                            builder: (context, snapshot) {
                              final projectName = snapshot.hasData && snapshot.data!.exists
                                  ? (snapshot.data!.data() as Map)['title'] ?? 'Unknown'
                                  : 'Loading...';
                              return Text(
                                projectName,
                                style: const TextStyle(fontSize: 10, color: Colors.grey),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Progress indicator
              Column(
                children: [
                  Text(
                    '${task.progress}%',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: difficultyColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    width: 40,
                    height: 3,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(2),
                    ),
                    child: LinearProgressIndicator(
                      value: task.progress / 100,
                      backgroundColor: Colors.transparent,
                      valueColor: AlwaysStoppedAnimation(difficultyColor),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}