// ignore_for_file: use_build_context_synchronously, prefer_const_constructors, sort_child_properties_last, avoid_print, unused_field, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../dashboards/notifications_screen.dart';
import '../dashboards/calendar_screen.dart';
import '../projects/project_detail_screen.dart';
import '../../models/project.dart';
import '../../models/task.dart';
import '../ai/ai_chatbot_screen.dart';
import '../tasks/task_evidence_screen.dart';
import '../../services/ai_difficulty_service.dart';
import 'package:intl/intl.dart';
import '../dashboards/team_leader_dashboard.dart';
class LecturerDashboard extends StatefulWidget {
  const LecturerDashboard({super.key});

  @override
  State<LecturerDashboard> createState() => _LecturerDashboardState();
}

class _LecturerDashboardState extends State<LecturerDashboard> {
  String? _campusId;
  List<Map<String, dynamic>> _myProjects = [];
  List<Map<String, dynamic>> _allProjects = [];
  List<Map<String, dynamic>> _myTasks = [];
  bool _isLoading = true;
  bool _isRefreshing = false;
  String _userName = '';
  int _selectedTabIndex = 0; // 0 = My Tasks, 1 = My Projects, 2 = All Projects
  String? _errorMessage;
  
  // Search and filter
  String _searchQuery = "";
  String _selectedStatus = "All";
  final List<String> _statuses = ["All", "Pending", "Active", "Completed"];

  // Helper method to normalize status
  String _normalizeStatusForDisplay(String status) {
    if (status.isEmpty) return 'Pending';
    final lowerStatus = status.toLowerCase();
    if (lowerStatus == 'active') return 'Active';
    if (lowerStatus == 'pending') return 'Pending';
    if (lowerStatus == 'completed') return 'Completed';
    return status;
  }

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadAllProjects();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _loadAllProjects() async {
    try {
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .get();
      
      if (mounted) {
        setState(() {
          _allProjects = projectsSnapshot.docs.map((doc) {
            final data = doc.data();
            return {
              'id': doc.id,
              'title': data['title'] ?? 'Untitled',
              'description': data['description'] ?? '',
              'status': data['status'] ?? 'pending',
              'progress': data['progress'] ?? 0,
              'sustainabilityScore': data['sustainabilityScore'] ?? 0,
              'leaderId': data['leaderId'],
              'createdAt': data['createdAt'],
            };
          }).toList();
        });
      }
    } catch (e) {
      print('Error loading all projects: $e');
    }
  }

  Future<void> _loadUserData() async {
    if (_isRefreshing) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) {
      setState(() {
        _errorMessage = 'Please login again';
        _isLoading = false;
      });
      return;
    }
    
    final uid = currentUser.uid;
    
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      
      if (userDoc.exists) {
        _campusId = userDoc.data()?['campusId'];
        _userName = userDoc.data()?['name'] ?? 'Lecturer';
      } else {
        _userName = 'Lecturer';
      }
      
      await Future.wait([
        _loadMyProjects(uid),
        _loadMyTasks(uid),
      ]);
      
    } catch (e) {
      print('Error loading user data: $e');
      setState(() {
        _errorMessage = 'Failed to load data: $e';
      });
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _loadMyProjects(String uid) async {
    try {
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .where('leaderId', isEqualTo: uid)
          .get();

      print('Projects found: ${projectsSnapshot.docs.length}');

      final projects = projectsSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Untitled',
          'description': data['description'] ?? '',
          'status': data['status'] ?? 'pending',
          'progress': data['progress'] ?? 0,
          'members': List<String>.from(data['members'] ?? []),
          'sustainabilityScore': data['sustainabilityScore'] ?? 0,
          'createdAt': data['createdAt'],
        };
      }).toList();
      
      if (mounted) {
        setState(() {
          _myProjects = projects;
        });
      }
    } catch (e) {
      print('Error loading projects: $e');
      rethrow;
    }
  }

  Future<void> _loadMyTasks(String uid) async {
    try {
      final tasksSnapshot = await FirebaseFirestore.instance
          .collection('tasks')
          .where('assignedTo', isEqualTo: uid)
          .get();

      print('Tasks found: ${tasksSnapshot.docs.length}');

      final tasks = tasksSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? '',
          'description': data['description'] ?? '',
          'projectId': data['projectId'] ?? '',
          'deadline': (data['deadline'] as Timestamp?)?.toDate(),
          'difficulty': data['difficultyLevel'] ?? 1,
          'progress': data['progress'] ?? 0,
          'status': data['status'] ?? 'pending',
          'evidenceImages': List<String>.from(data['evidenceImages'] ?? []),
        };
      }).toList();
      
      // Sort tasks by deadline (closest first)
      tasks.sort((a, b) {
        if (a['deadline'] == null) return 1;
        if (b['deadline'] == null) return -1;
        return a['deadline'].compareTo(b['deadline']);
      });
      
      if (mounted) {
        setState(() {
          _myTasks = tasks;
        });
      }
    } catch (e) {
      print('Error loading tasks: $e');
    }
  }

  Future<void> _refreshData() async {
    if (_isRefreshing) return;
    
    setState(() {
      _isRefreshing = true;
      _errorMessage = null;
    });
    
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        await Future.wait([
          _loadMyProjects(currentUser.uid),
          _loadMyTasks(currentUser.uid),
          _loadAllProjects(),
        ]);
      }
    } catch (e) {
      print('Refresh error: $e');
      setState(() {
        _errorMessage = 'Failed to refresh: $e';
      });
    } finally {
      if (mounted) {
        setState(() => _isRefreshing = false);
      }
    }
  }

  // ==================== DASHBOARD SWITCHING METHODS ====================
  
  Future<void> _resetToAutoDashboard() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    
    try {
      await FirebaseFirestore.instance
          .collection('user_preferences')
          .doc(currentUser.uid)
          .delete();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Dashboard will now auto-switch based on your active projects'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );
        // Reload the router
        Navigator.pushReplacementNamed(context, '/dashboard');
      }
    } catch (e) {
      print('Error resetting preference: $e');
    }
  }

  Future<void> _checkAndSwitchToTeamLeader() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    
    // Check for active projects
    final projectsSnapshot = await FirebaseFirestore.instance
        .collection('projects')
        .where('leaderId', isEqualTo: currentUser.uid)
        .where('status', isNotEqualTo: 'completed')
        .get();
    
    if (projectsSnapshot.docs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You have no active projects as Team Leader.'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    
    final projectCount = projectsSnapshot.docs.length;
    final projectTitle = projectsSnapshot.docs.first.data()['title'];
    
    // Show confirmation dialog
    final shouldSwitch = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.green.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.leaderboard, color: Colors.green, size: 24),
            ),
            const SizedBox(width: 12),
            const Text('Switch to Team Leader?'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('You are the team leader for $projectCount active project(s):'),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('🎯 $projectCount active project(s)'),
                  Text(
                    'Latest: $projectTitle',
                    style: TextStyle(fontSize: 12, color: Colors.green.shade700),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Text('Team Leader Dashboard allows you to:'),
            const SizedBox(height: 8),
            const Text('• Manage team members'),
            const Text('• Assign tasks to members'),
            const Text('• Submit weekly updates'),
            const Text('• View team feed and chat'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: const Text('Switch Now'),
          ),
        ],
      ),
    );
    
    if (shouldSwitch == true) {
      // Save preference and navigate
      await FirebaseFirestore.instance
          .collection('user_preferences')
          .doc(currentUser.uid)
          .set({
        'dashboardType': 'team_leader',
        'manualOverride': true,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => const TeamLeaderDashboard(),
          ),
        );
      }
    }
  }

  // ==================== END DASHBOARD SWITCHING METHODS ====================

  Future<void> _showLogoutDialog(BuildContext context) async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (shouldLogout == true) {
      await FirebaseAuth.instance.signOut();
      if (context.mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      }
    }
  }

  void _showProfileDialog() {
    final currentUser = FirebaseAuth.instance.currentUser;
    
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser?.uid)
            .get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!.data() as Map<String, dynamic>;
          return AlertDialog(
            title: const Text('My Profile'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(data['name'] ?? 'Unknown'),
                  subtitle: const Text('Name'),
                ),
                ListTile(
                  leading: const Icon(Icons.email),
                  title: Text(data['email'] ?? 'No email'),
                  subtitle: const Text('Email'),
                ),
                ListTile(
                  leading: const Icon(Icons.assignment_ind),
                  title: Text(data['role'] ?? 'Lecturer'),
                  subtitle: const Text('Role'),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _respondToProject(String projectId, String action) async {
    setState(() => _isLoading = true);
    
    try {
      await FirebaseFirestore.instance
          .collection('projects')
          .doc(projectId)
          .update({
        'status': action == 'accept' ? 'active' : 'rejected',
        'respondedAt': FieldValue.serverTimestamp(),
        'respondedBy': FirebaseAuth.instance.currentUser?.uid,
      });

      final currentUser = FirebaseAuth.instance.currentUser;
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser?.uid)
          .get();
      final teamLeaderName = userDoc.data()?['name'] ?? 'Team Leader';

      final adminQuery = await FirebaseFirestore.instance
          .collection('users')
          .where('role', isEqualTo: 'admin')
          .limit(1)
          .get();
      
      if (adminQuery.docs.isNotEmpty) {
        await FirebaseFirestore.instance.collection('notifications').add({
          'userId': adminQuery.docs.first.id,
          'title': action == 'accept' ? 'Project Accepted' : 'Project Rejected',
          'message': '$teamLeaderName has ${action}ed the project',
          'type': action == 'accept' ? 'success' : 'warning',
          'notificationType': action == 'accept' ? 'project_accepted' : 'project_rejected',
          'isRead': false,
          'createdAt': FieldValue.serverTimestamp(),
          'relatedId': projectId,
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Project ${action}ed successfully'), backgroundColor: Colors.green),
        );
        await _refreshData();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    final pendingProjects = _myProjects.where((p) {
      final status = p['status'].toString().toLowerCase();
      return status == 'pending' || status == 'pending_assignment';
    }).toList();
    
    final activeProjects = _myProjects.where((p) {
      final status = p['status'].toString().toLowerCase();
      return status == 'active' || status == 'in_progress';
    }).toList();

    final completedProjects = _myProjects.where((p) {
      final status = p['status'].toString().toLowerCase();
      return status == 'completed';
    }).toList();

    // Filter all projects
    final filteredAllProjects = _allProjects.where((p) {
      final title = p['title'].toString().toLowerCase();
      final status = p['status'].toString().toLowerCase();
      final matchesSearch = title.contains(_searchQuery.toLowerCase());
      final matchesStatus = _selectedStatus == "All" || 
          (status == _selectedStatus.toLowerCase()) ||
          (_selectedStatus == "Active" && status == "active") ||
          (_selectedStatus == "Completed" && status == "completed") ||
          (_selectedStatus == "Pending" && status == "pending");
      return matchesSearch && matchesStatus;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Lecturer Dashboard"),
        backgroundColor: Colors.green,
        centerTitle: false,
        actions: [
          // Switch to Team Leader Button
          IconButton(
            icon: const Icon(Icons.leaderboard),
            onPressed: _checkAndSwitchToTeamLeader,
            tooltip: 'Switch to Team Leader Dashboard',
          ),
          
          // Calendar Button
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const CalendarScreen(),
                ),
              );
            },
            tooltip: 'Task Calendar',
          ),
          
          // Notifications
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection("notifications")
                .where("userId", isEqualTo: currentUser?.uid)
                .where("isRead", isEqualTo: false)
                .snapshots(),
            builder: (context, snapshot) {
              int count = snapshot.data?.docs.length ?? 0;
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const NotificationsScreen(),
                        ),
                      );
                    },
                  ),
                  if (count > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          count > 9 ? '9+' : count.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          
          // Profile Menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle),
            onSelected: (value) async {
              if (value == 'profile') {
                _showProfileDialog();
              } else if (value == 'reset_dashboard') {
                await _resetToAutoDashboard();
              } else if (value == 'logout') {
                await _showLogoutDialog(context);
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person, size: 20),
                    SizedBox(width: 12),
                    Text('Profile'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'reset_dashboard',
                child: Row(
                  children: [
                    Icon(Icons.refresh, size: 20),
                    SizedBox(width: 12),
                    Text('Reset to Auto Dashboard'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, size: 20, color: Colors.red),
                    SizedBox(width: 12),
                    Text('Logout', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading your data...'),
                ],
              ),
            )
          : _errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red),
                      const SizedBox(height: 16),
                      Text(_errorMessage!, style: const TextStyle(color: Colors.red)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadUserData,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : Column(
                  children: [
                    // Tab Bar
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border(
                          bottom: BorderSide(color: Colors.grey.shade200),
                        ),
                      ),
                      child: Row(
                        children: [
                          _buildTabButton('My Tasks', 0, Icons.assignment_turned_in),
                          _buildTabButton('My Projects', 1, Icons.folder),
                          _buildTabButton('All Projects', 2, Icons.eco),
                        ],
                      ),
                    ),
                    
                    // Tab Content
                    Expanded(
                      child: IndexedStack(
                        index: _selectedTabIndex,
                        children: [
                          _buildMyTasksTab(),
                          _buildMyProjectsTab(pendingProjects, activeProjects, completedProjects),
                          _buildAllProjectsTab(filteredAllProjects),
                        ],
                      ),
                    ),
                  ],
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        child: const Icon(Icons.chat, color: Colors.white),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AIChatbotScreen(),
            ),
          );
        },
        tooltip: 'Ask AI Assistant',
      ),
    );
  }

  Widget _buildTabButton(String title, int index, IconData icon) {
    final isSelected = _selectedTabIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedTabIndex = index;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: isSelected ? Colors.green : Colors.transparent,
                width: 3,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? Colors.green : Colors.grey, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  color: isSelected ? Colors.green : Colors.grey,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== MY TASKS TAB ====================
  Widget _buildMyTasksTab() {
    if (_myTasks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.assignment_turned_in, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            const Text('No tasks assigned to you yet'),
            const SizedBox(height: 8),
            Text(
              'When projects assign tasks to you, they will appear here',
              style: TextStyle(color: Colors.grey.shade600),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _myTasks.length,
        itemBuilder: (context, index) {
          final task = _myTasks[index];
          return _buildTaskCard(task);
        },
      ),
    );
  }

  Widget _buildTaskCard(Map<String, dynamic> task) {
    final difficultyColor = AIDifficultyService.getDifficultyColor(task['difficulty']);
    final isCompleted = task['progress'] == 100;
    final isOverdue = task['deadline'] != null && 
        task['deadline'].isBefore(DateTime.now()) && !isCompleted;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isOverdue ? Colors.red : difficultyColor,
          width: isOverdue ? 2 : 1,
        ),
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TaskEvidenceScreen(task: Task.fromMap(task, task['id'])),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: difficultyColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: difficultyColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.trending_up, size: 14, color: difficultyColor),
                        const SizedBox(width: 4),
                        Text(
                          'Difficulty: ${task['difficulty']}/10',
                          style: TextStyle(fontSize: 12, color: difficultyColor),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  if (isCompleted)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_circle, size: 14, color: Colors.green),
                          SizedBox(width: 4),
                          Text('Completed'),
                        ],
                      ),
                    ),
                  if (isOverdue && !isCompleted)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.warning, size: 14, color: Colors.red),
                          SizedBox(width: 4),
                          Text('Overdue'),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                task['title'],
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  decoration: isCompleted ? TextDecoration.lineThrough : null,
                ),
              ),
              const SizedBox(height: 8),
              if (task['description'].toString().isNotEmpty)
                Text(
                  task['description'].length > 100 
                      ? '${task['description'].substring(0, 100)}...' 
                      : task['description'],
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(Icons.calendar_today, size: 14, color: isOverdue ? Colors.red : Colors.grey),
                  const SizedBox(width: 4),
                  Text(
                    task['deadline'] != null 
                        ? 'Due: ${DateFormat('dd MMM yyyy').format(task['deadline'])}'
                        : 'No deadline',
                    style: TextStyle(
                      fontSize: 12,
                      color: isOverdue ? Colors.red : Colors.grey,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    'Progress: ${task['progress']}%',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: task['progress'] / 100,
                backgroundColor: Colors.grey.shade200,
                valueColor: AlwaysStoppedAnimation(difficultyColor),
                minHeight: 6,
                borderRadius: BorderRadius.circular(3),
              ),
              if (task['evidenceImages'].isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Row(
                    children: [
                      Icon(Icons.image, size: 14, color: Colors.green),
                      const SizedBox(width: 4),
                      Text(
                        '${task['evidenceImages'].length} evidence image(s) uploaded',
                        style: const TextStyle(fontSize: 12, color: Colors.green),
                      ),
                    ],
                  ),
                ),
              if (!isCompleted)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => TaskEvidenceScreen(task: Task.fromMap(task, task['id'])),
                          ),
                        );
                      },
                      icon: const Icon(Icons.edit),
                      label: const Text('Update Progress & Upload Evidence'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== MY PROJECTS TAB ====================
  Widget _buildMyProjectsTab(
    List<Map<String, dynamic>> pendingProjects,
    List<Map<String, dynamic>> activeProjects,
    List<Map<String, dynamic>> completedProjects,
  ) {
    return RefreshIndicator(
      onRefresh: _refreshData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Colors.green, Colors.greenAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Text(
                      _userName.isNotEmpty ? _userName[0].toUpperCase() : 'L',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Welcome back,',
                          style: TextStyle(color: Colors.white70, fontSize: 14),
                        ),
                        Text(
                          _userName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Stats Row
            Row(
              children: [
                _buildStatCard('Total', _myProjects.length.toString(), Icons.folder, Colors.blue),
                const SizedBox(width: 12),
                _buildStatCard('Active', activeProjects.length.toString(), Icons.play_circle, Colors.green),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _buildStatCard('Pending', pendingProjects.length.toString(), Icons.pending, Colors.orange),
                const SizedBox(width: 12),
                _buildStatCard('Completed', completedProjects.length.toString(), Icons.check_circle, Colors.purple),
              ],
            ),
            const SizedBox(height: 20),

            // Pending Projects Section
            if (pendingProjects.isNotEmpty) ...[
              _buildSectionHeader('Pending Projects', Icons.pending_actions),
              const SizedBox(height: 12),
              _buildPendingProjectsList(pendingProjects),
              const SizedBox(height: 20),
            ],

            // Active Projects Section
            if (activeProjects.isNotEmpty) ...[
              _buildSectionHeader('Active Projects', Icons.play_circle),
              const SizedBox(height: 12),
              _buildActiveProjectsList(activeProjects),
              const SizedBox(height: 20),
            ],

            // All My Projects Section
            if (_myProjects.isNotEmpty) ...[
              _buildSectionHeader('All My Projects', Icons.folder),
              const SizedBox(height: 12),
              _buildAllProjectsList(),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(40),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Column(
                    children: [
                      Icon(Icons.folder_open, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('No projects assigned to you yet'),
                      SizedBox(height: 8),
                      Text(
                        'When projects are assigned, they will appear here',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ==================== ALL PROJECTS TAB ====================
  Widget _buildAllProjectsTab(List<Map<String, dynamic>> filteredProjects) {
    return Column(
      children: [
        // Search Bar
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search projects...",
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              filled: true,
              fillColor: Colors.grey.shade50,
            ),
            onChanged: (value) {
              setState(() => _searchQuery = value.toLowerCase());
            },
          ),
        ),
        
        // Filter Dropdown
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButtonFormField<String>(
            value: _selectedStatus,
            items: _statuses.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
            onChanged: (value) {
              setState(() => _selectedStatus = value!);
            },
            decoration: const InputDecoration(
              labelText: "Filter by Status",
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),
        
        const SizedBox(height: 10),
        
        // Project List
        Expanded(
          child: filteredProjects.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.folder_open, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('No projects found'),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _refreshData,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: filteredProjects.length,
                    itemBuilder: (context, index) {
                      final project = filteredProjects[index];
                      return _buildAllProjectCard(project);
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildAllProjectCard(Map<String, dynamic> project) {
    final score = (project['sustainabilityScore'] ?? 0).toDouble();
    final displayStatus = _normalizeStatusForDisplay(project['status']);
    final isMyProject = project['leaderId'] == FirebaseAuth.instance.currentUser?.uid;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isMyProject 
            ? BorderSide(color: Colors.green.shade300, width: 1.5)
            : BorderSide.none,
      ),
      child: ListTile(
        leading: Container(
          width: 45,
          height: 45,
          decoration: BoxDecoration(
            color: _getScoreColor(score).withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: _getScoreIcon(score),
        ),
        title: Text(
          project['title'],
          style: const TextStyle(fontWeight: FontWeight.bold),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Status: $displayStatus"),
            const SizedBox(height: 2),
            Text(
              "🌱 Score: ${score.toStringAsFixed(1)}",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: _getScoreColor(score),
                fontSize: 12,
              ),
            ),
            if (isMyProject)
              Container(
                margin: const EdgeInsets.only(top: 4),
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  'You are the leader',
                  style: TextStyle(fontSize: 10, color: Colors.green),
                ),
              ),
          ],
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _getScoreColor(score).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            "${project['progress'] ?? 0}%",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: _getScoreColor(score),
            ),
          ),
        ),
        onTap: () {
          final projectModel = Project.fromMap(project, project['id']);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProjectDetailScreen(project: projectModel),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 16),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color),
                  ),
                  Text(
                    title,
                    style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: Colors.green, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildPendingProjectsList(List<Map<String, dynamic>> projects) {
    return SizedBox(
      height: 180,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: projects.length,
        itemBuilder: (context, index) {
          final project = projects[index];
          return Container(
            width: 280,
            margin: const EdgeInsets.only(right: 12),
            child: Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: Colors.orange.shade100,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.assignment, size: 16, color: Colors.orange.shade700),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            project['title'],
                            style: const TextStyle(fontWeight: FontWeight.bold),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Waiting for your response',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _respondToProject(project['id'], 'accept'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                            ),
                            child: const Text('Accept'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _respondToProject(project['id'], 'reject'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                              side: const BorderSide(color: Colors.red),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                            ),
                            child: const Text('Decline'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActiveProjectsList(List<Map<String, dynamic>> projects) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: projects.length,
      itemBuilder: (context, index) {
        final project = projects[index];
        final score = (project['sustainabilityScore'] ?? 0).toDouble();
        final displayStatus = _normalizeStatusForDisplay(project['status']);
        
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            leading: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _getScoreColor(score).withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.eco, color: _getScoreColor(score)),
            ),
            title: Text(
              project['title'],
              style: const TextStyle(fontWeight: FontWeight.w500),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              'Status: $displayStatus • Progress: ${project['progress']}% • Members: ${project['members'].length}',
              style: const TextStyle(fontSize: 12),
            ),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () {
              final projectModel = Project.fromMap(project, project['id']);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProjectDetailScreen(project: projectModel),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildAllProjectsList() {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _myProjects.length,
      itemBuilder: (context, index) {
        final project = _myProjects[index];
        final score = (project['sustainabilityScore'] ?? 0).toDouble();
        final displayStatus = _normalizeStatusForDisplay(project['status']);
        
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            leading: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _getScoreColor(score).withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.eco, color: _getScoreColor(score)),
            ),
            title: Text(
              project['title'],
              style: const TextStyle(fontWeight: FontWeight.w500),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              'Status: $displayStatus | Progress: ${project['progress']}%',
              style: const TextStyle(fontSize: 12),
            ),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () {
              final projectModel = Project.fromMap(project, project['id']);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProjectDetailScreen(project: projectModel),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 70) return Colors.green;
    if (score >= 40) return Colors.orange;
    return Colors.red;
  }

  Widget _getScoreIcon(double score) {
    if (score >= 75) {
      return const Icon(Icons.emoji_events, color: Colors.amber, size: 28);
    } else if (score >= 50) {
      return const Icon(Icons.eco, color: Colors.green, size: 28);
    } else {
      return const Icon(Icons.warning, color: Colors.red, size: 28);
    }
  }
}