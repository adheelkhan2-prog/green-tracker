// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, avoid_print, prefer_final_fields, unused_field, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final Map<String, bool> _expandedStates = {};
  String _filter = 'all';
  bool _isLoading = true;
  String? _errorMessage;
  
  // Notification type configurations
  final Map<String, Map<String, dynamic>> _notificationConfigs = {
    'project_created': {
      'icon': Icons.folder, 
      'color': Colors.blue,
      'title': 'New Project Created',
    },
    'project_assigned': {
      'icon': Icons.assignment_turned_in, 
      'color': Colors.green,
      'title': 'Project Assigned',
    },
    'team_created': {
      'icon': Icons.group_add, 
      'color': Colors.purple,
      'title': 'Team Created',
    },
    'member_added': {
      'icon': Icons.person_add, 
      'color': Colors.teal,
      'title': 'Added to Team',
    },
    'task_assigned': {
      'icon': Icons.task, 
      'color': Colors.orange,
      'title': 'New Task Assigned',
    },
    'task_completed': {
      'icon': Icons.check_circle, 
      'color': Colors.green,
      'title': 'Task Completed',
    },
    'project_accepted': {
      'icon': Icons.check, 
      'color': Colors.green,
      'title': 'Project Accepted',
    },
    'project_rejected': {
      'icon': Icons.close, 
      'color': Colors.red,
      'title': 'Project Rejected',
    },
    'deadline_reminder': {
      'icon': Icons.alarm, 
      'color': Colors.red,
      'title': 'Deadline Reminder',
    },
    'join_request': {
      'icon': Icons.person, 
      'color': Colors.amber,
      'title': 'Join Request',
    },
    'resource_request': {
      'icon': Icons.request_page, 
      'color': Colors.orange,
      'title': 'Resource Request',
    },
    'evidence_submitted': {
      'icon': Icons.image, 
      'color': Colors.purple,
      'title': 'Evidence Submitted',
    },
  };

  Future<void> _markAllAsRead() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;
    
    try {
      final notifications = await FirebaseFirestore.instance
          .collection("notifications")
          .where("userId", isEqualTo: userId)
          .where("isRead", isEqualTo: false)
          .get();
      
      final batch = FirebaseFirestore.instance.batch();
      for (var doc in notifications.docs) {
        batch.update(doc.reference, {"isRead": true});
      }
      await batch.commit();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('All notifications marked as read')),
        );
      }
    } catch (e) {
      print('Error marking all as read: $e');
    }
  }

  Future<void> _deleteNotification(String notificationId) async {
    try {
      await FirebaseFirestore.instance
          .collection("notifications")
          .doc(notificationId)
          .delete();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Notification deleted')),
        );
      }
    } catch (e) {
      print('Error deleting notification: $e');
    }
  }

  Future<void> _deleteAllRead() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;
    
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete All Read'),
        content: const Text('Are you sure you want to delete all read notifications?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      try {
        final notifications = await FirebaseFirestore.instance
            .collection("notifications")
            .where("userId", isEqualTo: userId)
            .where("isRead", isEqualTo: true)
            .get();
        
        final batch = FirebaseFirestore.instance.batch();
        for (var doc in notifications.docs) {
          batch.delete(doc.reference);
        }
        await batch.commit();
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('All read notifications deleted')),
          );
        }
      } catch (e) {
        print('Error deleting all read: $e');
      }
    }
  }

  bool _shouldShowNotification(Map<String, dynamic> data, DateTime? createdAt) {
    if (_filter == 'unread' && data['isRead'] == true) return false;
    
    if (_filter == 'today' && createdAt != null) {
      final now = DateTime.now();
      return createdAt.year == now.year && 
             createdAt.month == now.month && 
             createdAt.day == now.day;
    }
    
    if (_filter == 'this_week' && createdAt != null) {
      final now = DateTime.now();
      final weekAgo = now.subtract(const Duration(days: 7));
      return createdAt.isAfter(weekAgo);
    }
    
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    
    if (userId == null) {
      return const Scaffold(
        body: Center(child: Text('Please login to view notifications')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Notifications"),
        backgroundColor: Colors.green,
        centerTitle: false,
        actions: [
          // Filter menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            onSelected: (value) {
              setState(() {
                _filter = value;
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'all',
                child: Row(
                  children: [
                    Icon(Icons.all_inclusive, size: 20),
                    SizedBox(width: 12),
                    Text('All Notifications'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'unread',
                child: Row(
                  children: [
                    Icon(Icons.mark_chat_unread, size: 20),
                    SizedBox(width: 12),
                    Text('Unread Only'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'today',
                child: Row(
                  children: [
                    Icon(Icons.today, size: 20),
                    SizedBox(width: 12),
                    Text('Today'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'this_week',
                child: Row(
                  children: [
                    Icon(Icons.calendar_view_week, size: 20),
                    SizedBox(width: 12),
                    Text('This Week'),
                  ],
                ),
              ),
            ],
          ),
          // Mark all read
          TextButton(
            onPressed: _markAllAsRead,
            child: const Text(
              'Mark All Read',
              style: TextStyle(color: Colors.white),
            ),
          ),
          // More options
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (value) {
              if (value == 'delete_read') {
                _deleteAllRead();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'delete_read',
                child: Row(
                  children: [
                    Icon(Icons.delete_sweep, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete All Read'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        key: ValueKey(_filter),
        stream: FirebaseFirestore.instance
            .collection("notifications")
            .where("userId", isEqualTo: userId)
            .orderBy("createdAt", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            print('Stream error: ${snapshot.error}');
            
            // Try without ordering if there's an index error
            if (snapshot.error.toString().contains('index')) {
              return _buildSimpleNotificationsList(userId);
            }
            
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 64, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(
                    'Error loading notifications: ${snapshot.error}',
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => setState(() {}),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_none, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No notifications yet'),
                  SizedBox(height: 8),
                  Text(
                    'You will receive notifications for:\n• Project assignments\n• Task updates\n• Team invitations\n• Deadline reminders',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            );
          }

          final allNotifications = snapshot.data!.docs;
          
          // Apply filter
          final notifications = allNotifications.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
            return _shouldShowNotification(data, createdAt);
          }).toList();
          
          if (notifications.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.filter_alt_off, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  Text('No notifications match the filter'),
                  const SizedBox(height: 8),
                  Text(
                    'Try changing the filter option',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            );
          }
          
          int unreadCount = notifications.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return data['isRead'] != true;
          }).length;

          return Column(
            children: [
              // Unread count banner
              if (unreadCount > 0)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  color: Colors.green.shade100,
                  child: Text(
                    '$unreadCount unread notification${unreadCount > 1 ? 's' : ''}',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.green.shade800,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: notifications.length,
                  itemBuilder: (context, index) {
                    final doc = notifications[index];
                    final data = doc.data() as Map<String, dynamic>;
                    final isRead = data['isRead'] ?? false;
                    final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
                    final relatedId = data['relatedId'];
                    final notificationType = data['notificationType'] ?? 'general';
                    
                    final config = _notificationConfigs[notificationType] ?? {
                      'icon': Icons.notifications,
                      'color': Colors.grey,
                      'title': data['title'] ?? 'Notification',
                    };
                    
                    final isExpanded = _expandedStates[doc.id] ?? false;

                    return Card(
                      elevation: isRead ? 1 : 3,
                      margin: const EdgeInsets.only(bottom: 12),
                      color: isRead ? null : config['color'].withOpacity(0.05),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: !isRead
                            ? BorderSide(color: config['color'], width: 1.5)
                            : BorderSide.none,
                      ),
                      child: InkWell(
                        onTap: () async {
                          if (!isRead) {
                            await doc.reference.update({"isRead": true});
                            setState(() {});
                          }
                          setState(() {
                            _expandedStates[doc.id] = !isExpanded;
                          });
                        },
                        borderRadius: BorderRadius.circular(12),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Icon
                                  Container(
                                    width: 45,
                                    height: 45,
                                    decoration: BoxDecoration(
                                      color: config['color'].withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(
                                      config['icon'],
                                      color: config['color'],
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  
                                  // Content
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          config['title'],
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: isRead ? FontWeight.normal : FontWeight.bold,
                                            color: config['color'],
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          data['message'] ?? '',
                                          style: TextStyle(
                                            fontWeight: isRead ? FontWeight.normal : FontWeight.w500,
                                            fontSize: 13,
                                            color: Colors.grey.shade800,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        if (createdAt != null)
                                          Text(
                                            _formatTimeAgo(createdAt),
                                            style: const TextStyle(
                                              fontSize: 11,
                                              color: Colors.grey,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                  
                                  // Actions
                                  Column(
                                    children: [
                                      if (!isRead)
                                        Container(
                                          width: 10,
                                          height: 10,
                                          decoration: BoxDecoration(
                                            color: config['color'],
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      const SizedBox(height: 8),
                                      PopupMenuButton<String>(
                                        icon: const Icon(Icons.more_vert, size: 18),
                                        onSelected: (value) async {
                                          if (value == 'mark_read') {
                                            await doc.reference.update({"isRead": true});
                                            setState(() {});
                                            if (mounted) {
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                const SnackBar(content: Text('Marked as read')),
                                              );
                                            }
                                          } else if (value == 'delete') {
                                            await _deleteNotification(doc.id);
                                          }
                                        },
                                        itemBuilder: (context) => [
                                          if (!isRead)
                                            const PopupMenuItem(
                                              value: 'mark_read',
                                              child: Row(
                                                children: [
                                                  Icon(Icons.mark_chat_read),
                                                  SizedBox(width: 8),
                                                  Text('Mark as read'),
                                                ],
                                              ),
                                            ),
                                          const PopupMenuItem(
                                            value: 'delete',
                                            child: Row(
                                              children: [
                                                Icon(Icons.delete, color: Colors.red),
                                                SizedBox(width: 8),
                                                Text('Delete'),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            
                            // Expanded content
                            if (isExpanded && relatedId != null && relatedId.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: ElevatedButton.icon(
                                        onPressed: () {
                                          _navigateToRelatedContent(context, notificationType, relatedId);
                                        },
                                        icon: const Icon(Icons.open_in_new, size: 16),
                                        label: const Text('View Details'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: config['color'],
                                          foregroundColor: Colors.white,
                                          padding: const EdgeInsets.symmetric(vertical: 10),
                                          textStyle: const TextStyle(fontSize: 13),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: OutlinedButton.icon(
                                        onPressed: () async {
                                          await doc.reference.update({"isRead": true});
                                          setState(() {
                                            _expandedStates[doc.id] = false;
                                          });
                                          if (mounted) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('Dismissed')),
                                            );
                                          }
                                        },
                                        icon: const Icon(Icons.close, size: 16),
                                        label: const Text('Dismiss'),
                                        style: OutlinedButton.styleFrom(
                                          foregroundColor: Colors.grey,
                                          padding: const EdgeInsets.symmetric(vertical: 10),
                                          textStyle: const TextStyle(fontSize: 13),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // Fallback simple list without ordering (to avoid index errors)
  Widget _buildSimpleNotificationsList(String userId) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection("notifications")
          .where("userId", isEqualTo: userId)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        
        final notifications = snapshot.data!.docs;
        
        // Sort manually
        notifications.sort((a, b) {
          final aDate = (a.data() as Map)['createdAt'] as Timestamp?;
          final bDate = (b.data() as Map)['createdAt'] as Timestamp?;
          if (aDate == null && bDate == null) return 0;
          if (aDate == null) return 1;
          if (bDate == null) return -1;
          return bDate.toDate().compareTo(aDate.toDate());
        });
        
        if (notifications.isEmpty) {
          return const Center(child: Text('No notifications'));
        }
        
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: notifications.length,
          itemBuilder: (context, index) {
            final doc = notifications[index];
            final data = doc.data() as Map<String, dynamic>;
            final isRead = data['isRead'] ?? false;
            final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
            final notificationType = data['notificationType'] ?? 'general';
            
            final config = _notificationConfigs[notificationType] ?? {
              'icon': Icons.notifications,
              'color': Colors.grey,
              'title': data['title'] ?? 'Notification',
            };
            
            return Card(
              elevation: isRead ? 1 : 3,
              margin: const EdgeInsets.only(bottom: 12),
              color: isRead ? null : config['color'].withOpacity(0.05),
              child: ListTile(
                leading: Icon(config['icon'], color: config['color']),
                title: Text(data['title'] ?? 'Notification'),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data['message'] ?? ''),
                    if (createdAt != null)
                      Text(
                        _formatTimeAgo(createdAt),
                        style: const TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                  ],
                ),
                trailing: !isRead
                    ? IconButton(
                        icon: Icon(Icons.mark_chat_read, color: config['color']),
                        onPressed: () async {
                          await doc.reference.update({"isRead": true});
                          setState(() {});
                        },
                      )
                    : null,
                onTap: () async {
                  if (!isRead) {
                    await doc.reference.update({"isRead": true});
                    setState(() {});
                  }
                },
              ),
            );
          },
        );
      },
    );
  }

  void _navigateToRelatedContent(BuildContext context, String notificationType, String relatedId) {
    switch (notificationType) {
      case 'task_assigned':
      case 'task_completed':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Opening task details...'), backgroundColor: Colors.green),
        );
        break;
      case 'project_created':
      case 'project_assigned':
      case 'project_accepted':
      case 'project_rejected':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Opening project details...'), backgroundColor: Colors.green),
        );
        break;
      case 'join_request':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Opening join requests...'), backgroundColor: Colors.green),
        );
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Opening related content...'), backgroundColor: Colors.green),
        );
    }
  }

  String _formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inDays > 7) {
      return DateFormat('dd MMM yyyy').format(dateTime);
    } else if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    } else {
      return 'Just now';
    }
  }
}