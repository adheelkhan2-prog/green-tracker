import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class RankingDashboard extends StatelessWidget {
  const RankingDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("🏆 AI Ranking Dashboard"),
        backgroundColor: Colors.green,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('projects')
            .orderBy('sustainabilityScore', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final projects = snapshot.data!.docs;

          if (projects.isEmpty) {
            return const Center(child: Text("No projects yet"));
          }

          return ListView.builder(
            itemCount: projects.length,
            itemBuilder: (context, index) {
              final data = projects[index].data() as Map<String, dynamic>;

              final score =
                  (data['sustainabilityScore'] ?? 0).toDouble();

              return Card(
                margin: const EdgeInsets.all(10),
                child: ListTile(
                  leading: _buildRankIcon(index),

                  title: Text(
                    data['title'] ?? '',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),

                  subtitle: Text("Score: ${score.toStringAsFixed(1)}"),

                  trailing: _buildScoreColor(score),
                ),
              );
            },
          );
        },
      ),
    );
  }

  // 🥇🥈🥉 Rank Icons
  Widget _buildRankIcon(int index) {
    if (index == 0) {
      return const Text("🥇", style: TextStyle(fontSize: 24));
    } else if (index == 1) {
      return const Text("🥈", style: TextStyle(fontSize: 24));
    } else if (index == 2) {
      return const Text("🥉", style: TextStyle(fontSize: 24));
    } else {
      return CircleAvatar(
        backgroundColor: Colors.grey[300],
        child: Text("${index + 1}"),
      );
    }
  }

  // 🌈 Score Color Indicator
  Widget _buildScoreColor(double score) {
    Color color;

    if (score >= 75) {
      color = Colors.green;
    } else if (score >= 50) {
      color = Colors.orange;
    } else {
      color = Colors.red;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        score.toStringAsFixed(1),
        style: const TextStyle(color: Colors.white),
      ),
    );
  }
}