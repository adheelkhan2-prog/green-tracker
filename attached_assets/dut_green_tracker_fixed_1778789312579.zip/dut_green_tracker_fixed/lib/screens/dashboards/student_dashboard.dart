// ignore_for_file: unused_field, avoid_print, sort_child_properties_last, prefer_const_constructors, deprecated_member_use

import 'package:dut_green_tracker_fixed/screens/dashboards/notifications_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../projects/project_detail_screen.dart';
import '../../models/project.dart';
import '../../models/task.dart';
import '../dashboards/ranking_dashboard.dart';
import '../tasks/task_evidence_screen.dart';
import '../../services/ai_difficulty_service.dart';
import '../dashboards/calendar_screen.dart'; 
import 'package:intl/intl.dart';
import '../ai/ai_chatbot_screen.dart';
import '../../services/ai_risk_prediction.dart';
import '../../widgets/risk_badge.dart';
import '../team/team_feed_screen.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override 
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> with AutomaticKeepAliveClientMixin {
  String searchQuery = "";
  String selectedStatus = "All";
  final statuses = ["All", "Pending", "Active", "Completed"];
  int _selectedTabIndex = 0;
  
  // Cache for risk predictions
  final Map<String, RiskPrediction> _riskCache = {};
  final Map<String, bool> _riskLoadingCache = {};
  
  // Prevent unnecessary rebuilds
  bool _isLoadingProjects = true;
  List<Map<String, dynamic>> _filteredProjects = [];
  String? _errorMessage;
  
  // User data for filtering
  String? _userDepartment;
  String? _userFaculty;
  String? _userRole;
  String? _userId;
  
  // Pagination
  int _currentPage = 0;
  final int _pageSize = 10;
  bool _isLoadingMore = false;
  bool _hasMoreProjects = true;
  List<Map<String, dynamic>> _paginatedProjects = [];
  
  // Team Feed
  String? _selectedProjectForFeed;
  List<Map<String, dynamic>> _userProjects = [];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadUserAndProjects();
    _loadUserProjects();
  }

  String _normalizeStatusForDisplay(String status) {
    if (status.isEmpty) return 'Pending';
    final lowerStatus = status.toLowerCase();
    if (lowerStatus == 'active') return 'Active';
    if (lowerStatus == 'pending') return 'Pending';
    if (lowerStatus == 'completed') return 'Completed';
    return status;
  }

  Future<void> _loadUserProjects() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    
    try {
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .where('members', arrayContains: currentUser.uid)
          .get();
      
      setState(() {
        _userProjects = projectsSnapshot.docs.map((doc) {
          final data = doc.data();
          return {
            'id': doc.id,
            'title': data['title'] ?? 'Untitled',
          };
        }).toList();
      });
    } catch (e) {
      print('Error loading user projects: $e');
    }
  }

  Future<void> _loadUserAndProjects() async {
    setState(() {
      _isLoadingProjects = true;
      _errorMessage = null;
      _currentPage = 0;
      _hasMoreProjects = true;
      _paginatedProjects = [];
    });
    
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        setState(() {
          _errorMessage = 'Please login';
          _isLoadingProjects = false;
        });
        return;
      }
      
      _userId = currentUser.uid;
      
      // Get user details
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      
      if (userDoc.exists) {
        _userDepartment = userDoc.data()?['department'];
        _userFaculty = userDoc.data()?['faculty'];
        _userRole = userDoc.data()?['role'];
      }
      
      // Get all projects
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .get();
      
      // Filter projects based on user's department/faculty and visibility
      final filtered = <Map<String, dynamic>>[];
      
      for (var doc in projectsSnapshot.docs) {
        final data = doc.data();
        final visibility = data['visibility'] ?? 'open';
        final projectDepartment = data['department'];
        final projectFaculty = data['faculty'];
        final members = List<String>.from(data['members'] ?? []);
        final leaderId = data['leaderId'];
        final isMember = members.contains(currentUser.uid) || leaderId == currentUser.uid;
        
        bool canSee = false;
        
        // Admin sees all projects
        if (_userRole == 'admin') {
          canSee = true;
        }
        // Open projects - visible to all
        else if (visibility == 'open') {
          canSee = true;
        }
        // Department projects - only same department
        else if (visibility == 'department') {
          if (projectDepartment != null && projectDepartment == _userDepartment) {
            canSee = true;
          }
          // Also show if user is a member
          if (isMember) canSee = true;
        }
        // Restricted projects - only members/leaders
        else if (visibility == 'restricted') {
          if (isMember) canSee = true;
        }
        
        if (canSee) {
          filtered.add({
            'id': doc.id,
            'title': data['title'] ?? 'Untitled',
            'status': data['status'] ?? 'pending',
            'progress': data['progress'] ?? 0,
            'sustainabilityScore': data['sustainabilityScore'] ?? 0,
            'description': data['description'] ?? '',
            'visibility': visibility,
            'department': projectDepartment,
          });
        }
      }
      
      // Sort by sustainability score (highest first)
      filtered.sort((a, b) => (b['sustainabilityScore'] ?? 0).compareTo(a['sustainabilityScore'] ?? 0));
      
      if (mounted) {
        setState(() {
          _filteredProjects = filtered;
          _loadMoreProjects();
        });
      }
    } catch (e) {
      print('Error loading projects: $e');
      if (mounted) {
        setState(() {
          _errorMessage = 'Failed to load projects: $e';
          _isLoadingProjects = false;
        });
      }
    }
  }
  
  void _loadMoreProjects() {
    if (_isLoadingMore || !_hasMoreProjects) return;
    
    setState(() {
      _isLoadingMore = true;
    });
    
    final startIndex = _currentPage * _pageSize;
    final endIndex = startIndex + _pageSize;
    
    if (startIndex >= _filteredProjects.length) {
      setState(() {
        _hasMoreProjects = false;
        _isLoadingMore = false;
      });
      return;
    }
    
    final newProjects = _filteredProjects.sublist(
      startIndex,
      endIndex > _filteredProjects.length ? _filteredProjects.length : endIndex,
    );
    
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _paginatedProjects.addAll(newProjects);
          _currentPage++;
          _hasMoreProjects = endIndex < _filteredProjects.length;
          _isLoadingMore = false;
          _isLoadingProjects = false;
        });
      }
    });
  }
  
  void _showTeamFeedDialog() {
    if (_userProjects.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You are not a member of any project yet.'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          String? selectedProjectId = _userProjects.first['id'];
          String? selectedProjectTitle = _userProjects.first['title'];
          
          return Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Select Project for Team Feed',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedProjectId,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.folder),
                  ),
                  items: _userProjects.map((project) {
                    return DropdownMenuItem<String>(
                      value: project['id'] as String,
                      child: Text(project['title']),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setModalState(() {
                      selectedProjectId = value;
                      selectedProjectTitle = _userProjects.firstWhere((p) => p['id'] == value)['title'];
                    });
                  },
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => TeamFeedScreen(
                                projectId: selectedProjectId!,
                                projectTitle: selectedProjectTitle!,
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                        child: const Text('Open Feed'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    
    final currentUser = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dashboard"),
        backgroundColor: Colors.green,
        centerTitle: false,
        actions: [
          // Team Feed Button
          IconButton(
            icon: const Icon(Icons.rss_feed),
            onPressed: _showTeamFeedDialog,
            tooltip: 'Team Feed',
          ),
          // Calendar Button
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CalendarScreen()),
              );
            },
            tooltip: 'Task Calendar',
          ),
          // Leaderboard Button
          IconButton(
            icon: const Icon(Icons.leaderboard),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RankingDashboard()),
              );
            },
            tooltip: 'Leaderboard',
          ),
          // AI Feedback Button
          IconButton(
            icon: const Icon(Icons.auto_awesome),
            onPressed: _generateAiFeedback,
            tooltip: 'AI Feedback',
          ),
          // Notifications
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection("notifications")
                .where("userId", isEqualTo: currentUser?.uid)
                .where("isRead", isEqualTo: false)
                .snapshots(),
            builder: (context, snapshot) {
              int count = snapshot.data?.docs.length ?? 0;
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                      );
                    },
                  ),
                  if (count > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                        constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                        child: Text(
                          count > 9 ? '9+' : count.toString(),
                          style: const TextStyle(color: Colors.white, fontSize: 10),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          // Profile Menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle),
            onSelected: (value) async {
              if (value == 'logout') {
                await _showLogoutDialog(context);
              } else if (value == 'profile') {
                _showProfileDialog(context);
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person, size: 20),
                    SizedBox(width: 12),
                    Text('My Profile'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, size: 20, color: Colors.red),
                    SizedBox(width: 12),
                    Text('Logout', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Tab Bar
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
            ),
            child: Row(
              children: [
                _buildTabButton('My Tasks', 0, Icons.assignment_turned_in),
                _buildTabButton('All Projects', 1, Icons.eco),
              ],
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: _selectedTabIndex,
              children: [
                _buildMyTasksTab(currentUser?.uid),
                _buildAllProjectsTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        child: const Icon(Icons.chat, color: Colors.white),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AIChatbotScreen()),
          );
        },
        tooltip: 'Ask AI Assistant',
      ),
    );
  }
    
  Widget _buildTabButton(String title, int index, IconData icon) {
    final isSelected = _selectedTabIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedTabIndex = index;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: isSelected ? Colors.green : Colors.transparent,
                width: 3,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? Colors.green : Colors.grey, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  color: isSelected ? Colors.green : Colors.grey,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // =========================
  // 📋 MY TASKS TAB
  // =========================
  Widget _buildMyTasksTab(String? userId) {
    if (userId == null) {
      return const Center(child: Text('Please login'));
    }

    return StreamBuilder<QuerySnapshot>(
      key: ValueKey('tasks_stream_$userId'),
      stream: FirebaseFirestore.instance
          .collection('tasks')
          .where('assignedTo', isEqualTo: userId)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, size: 64, color: Colors.red),
                const SizedBox(height: 16),
                Text('Error: ${snapshot.error}'),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => setState(() {}),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.assignment_turned_in, size: 64, color: Colors.grey.shade400),
                const SizedBox(height: 16),
                const Text('No tasks assigned yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(
                  'When a team leader assigns tasks to you,\nthey will appear here.',
                  style: TextStyle(color: Colors.grey.shade600),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        }

        final tasks = snapshot.data!.docs;
        final sortedTasks = List.from(tasks);
        sortedTasks.sort((a, b) {
          final aData = a.data() as Map<String, dynamic>;
          final bData = b.data() as Map<String, dynamic>;
          final aDiff = aData['difficultyLevel'] ?? 0;
          final bDiff = bData['difficultyLevel'] ?? 0;
          return bDiff.compareTo(aDiff);
        });
        
        return RefreshIndicator(
          onRefresh: () async {
            _riskCache.clear();
            _riskLoadingCache.clear();
            setState(() {});
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: sortedTasks.length,
            itemBuilder: (context, index) {
              final data = sortedTasks[index].data() as Map<String, dynamic>;
              final task = Task.fromMap(data, sortedTasks[index].id);
              return _buildTaskCard(task);
            },
          ),
        );
      },
    );
  }

  // =========================
  // 🎴 TASK CARD
  // =========================
  Widget _buildTaskCard(Task task) {
    final difficultyColor = AIDifficultyService.getDifficultyColor(task.difficultyLevel);
    final isCompleted = task.progress == 100;
    final isOverdue = task.deadline.isBefore(DateTime.now()) && !isCompleted;
    
    if (!_riskCache.containsKey(task.id) && !isCompleted && !(_riskLoadingCache[task.id] ?? false)) {
      _riskLoadingCache[task.id] = true;
      _loadRiskPrediction(task);
    }
    
    final cachedRisk = _riskCache[task.id];
    final isLoadingRisk = _riskLoadingCache[task.id] == true && cachedRisk == null;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: cachedRisk != null && cachedRisk.riskLevel == 'High Risk' 
              ? Colors.red 
              : (isOverdue ? Colors.red : difficultyColor),
          width: (cachedRisk != null && cachedRisk.riskLevel == 'High Risk') || isOverdue ? 2 : 1,
        ),
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => TaskEvidenceScreen(task: task)),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (!isCompleted)
                    isLoadingRisk
                        ? Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                              shape: BoxShape.circle,
                            ),
                            child: const Center(
                              child: SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              ),
                            ),
                          )
                        : (cachedRisk != null ? RiskBadge(risk: cachedRisk, size: 50) : const SizedBox.shrink()),
                  if (!isCompleted && !isLoadingRisk) const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: difficultyColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: difficultyColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.trending_up, size: 14, color: difficultyColor),
                        const SizedBox(width: 4),
                        Text(
                          'Difficulty: ${task.difficultyLevel}/10',
                          style: TextStyle(fontSize: 12, color: difficultyColor, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  if (isCompleted)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_circle, size: 14, color: Colors.green),
                          SizedBox(width: 4),
                          Text('Completed', style: TextStyle(fontSize: 12, color: Colors.green)),
                        ],
                      ),
                    ),
                  if (isOverdue && !isCompleted)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.warning, size: 14, color: Colors.red),
                          SizedBox(width: 4),
                          Text('Overdue', style: TextStyle(fontSize: 12, color: Colors.red)),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                task.title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  decoration: isCompleted ? TextDecoration.lineThrough : null,
                ),
              ),
              const SizedBox(height: 8),
              if (task.description.isNotEmpty)
                Text(
                  task.description.length > 100 
                      ? '${task.description.substring(0, 100)}...' 
                      : task.description,
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
              const SizedBox(height: 12),
              if (cachedRisk != null && cachedRisk.riskLevel == 'High Risk' && !isCompleted)
                Container(
                  padding: const EdgeInsets.all(8),
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.warning, size: 16, color: Colors.red.shade700),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          cachedRisk.suggestion,
                          style: TextStyle(fontSize: 12, color: Colors.red.shade700),
                        ),
                      ),
                    ],
                  ),
                ),
              Row(
                children: [
                  Icon(Icons.calendar_today, size: 14, color: isOverdue ? Colors.red : Colors.grey),
                  const SizedBox(width: 4),
                  Text(
                    'Due: ${_formatDate(task.deadline)}',
                    style: TextStyle(
                      fontSize: 12,
                      color: isOverdue ? Colors.red : Colors.grey,
                      fontWeight: isOverdue ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  const Spacer(),
                  Text('Progress: ${task.progress}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: task.progress / 100,
                backgroundColor: Colors.grey.shade200,
                valueColor: AlwaysStoppedAnimation(
                  cachedRisk != null && cachedRisk.riskLevel == 'High Risk' && !isCompleted
                      ? Colors.red : difficultyColor
                ),
                minHeight: 6,
                borderRadius: BorderRadius.circular(3),
              ),
              if (cachedRisk != null && cachedRisk.predictedDaysLate > 0 && !isCompleted && !isOverdue)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    '⚠️ Predicted: ${cachedRisk.predictedDaysLate} day(s) late if no changes',
                    style: const TextStyle(fontSize: 11, color: Colors.red),
                  ),
                ),
              if (task.evidenceImages.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Row(
                    children: [
                      Icon(Icons.image, size: 14, color: Colors.green),
                      const SizedBox(width: 4),
                      Text(
                        '${task.evidenceImages.length} evidence image(s) uploaded',
                        style: const TextStyle(fontSize: 12, color: Colors.green),
                      ),
                    ],
                  ),
                ),
              if (!isCompleted)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => TaskEvidenceScreen(task: task)),
                        );
                      },
                      icon: const Icon(Icons.edit),
                      label: const Text('Update Progress & Upload Evidence'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
  
  Future<void> _loadRiskPrediction(Task task) async {
    try {
      final risk = await AIRiskPrediction.predictTaskRisk(
        taskId: task.id,
        title: task.title,
        progress: task.progress,
        deadline: task.deadline,
        difficultyLevel: task.difficultyLevel,
        assignedTo: task.assignedTo,
      );
      
      if (mounted) {
        setState(() {
          _riskCache[task.id] = risk;
        });
      }
    } catch (e) {
      print('Risk prediction error: $e');
    } finally {
      if (mounted) {
        setState(() {
          _riskLoadingCache[task.id] = false;
        });
      }
    }
  }

  // =========================
  // 📊 ALL PROJECTS TAB (With Pagination)
  // =========================
  Widget _buildAllProjectsTab() {
    if (_isLoadingProjects && _paginatedProjects.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    
    if (_errorMessage != null && _paginatedProjects.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(_errorMessage!),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadUserAndProjects,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    // Apply search and status filters locally
    final filteredBySearch = _paginatedProjects.where((project) {
      final title = project['title'].toString().toLowerCase();
      final matchesSearch = title.contains(searchQuery.toLowerCase());
      final status = project['status'].toString().toLowerCase();
      final matchesStatus = selectedStatus == "All" || status == selectedStatus.toLowerCase();
      return matchesSearch && matchesStatus;
    }).toList();

    if (filteredBySearch.isEmpty && !_isLoadingProjects) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.folder_open, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text(searchQuery.isEmpty ? 'No projects available' : 'No matching projects'),
            const SizedBox(height: 8),
            if (_userDepartment != null)
              Text(
                'Showing projects for department: $_userDepartment',
                style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
              ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadUserAndProjects,
      child: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search projects...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                filled: true,
                fillColor: Colors.grey.shade50,
              ),
              onChanged: (value) {
                setState(() => searchQuery = value.toLowerCase());
              },
            ),
          ),
          
          // Filter Dropdown
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: DropdownButtonFormField<String>(
              value: selectedStatus,
              items: statuses.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (value) {
                setState(() => selectedStatus = value!);
              },
              decoration: const InputDecoration(
                labelText: "Filter by Status",
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
          ),
          
          // Department Info Banner
          if (_userDepartment != null && _userDepartment!.isNotEmpty)
            Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(Icons.business, size: 16, color: Colors.blue.shade700),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Showing projects for department: ${_userDepartment!.toUpperCase()}',
                      style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                    ),
                  ),
                ],
              ),
            ),
          
          const SizedBox(height: 10),
          
          // Project List with Pagination
          Expanded(
            child: NotificationListener<ScrollNotification>(
              onNotification: (ScrollNotification scrollInfo) {
                if (!_isLoadingMore && _hasMoreProjects && 
                    scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent) {
                  _loadMoreProjects();
                }
                return false;
              },
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: filteredBySearch.length + (_isLoadingMore ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == filteredBySearch.length && _isLoadingMore) {
                    return const Padding(
                      padding: EdgeInsets.all(16),
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    );
                  }
                  final project = filteredBySearch[index];
                  return _buildProjectCard(project['id'], project);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProjectCard(String projectId, Map<String, dynamic> data) {
    final score = (data['sustainabilityScore'] ?? 0).toDouble();
    final displayStatus = _normalizeStatusForDisplay(data['status'] ?? 'Unknown');
    final visibility = data['visibility'] ?? 'open';
    
    // Visibility icon
    Widget visibilityIcon;
    switch (visibility) {
      case 'open':
        visibilityIcon = Icon(Icons.public, size: 14, color: Colors.green);
        break;
      case 'department':
        visibilityIcon = Icon(Icons.business, size: 14, color: Colors.orange);
        break;
      case 'restricted':
        visibilityIcon = Icon(Icons.lock, size: 14, color: Colors.red);
        break;
      default:
        visibilityIcon = const SizedBox.shrink();
    }
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Container(
          width: 45,
          height: 45,
          decoration: BoxDecoration(
            color: _getScoreColor(score).withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: _getScoreIcon(score),
        ),
        title: Text(
          data['title']?.toString() ?? "Untitled",
          style: const TextStyle(fontWeight: FontWeight.bold),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                visibilityIcon,
                const SizedBox(width: 4),
                Text("Status: $displayStatus"),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              "🌱 Score: ${score.toStringAsFixed(1)}",
              style: TextStyle(fontWeight: FontWeight.bold, color: _getScoreColor(score), fontSize: 12),
            ),
          ],
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _getScoreColor(score).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            "${data['progress'] ?? 0}%",
            style: TextStyle(fontWeight: FontWeight.bold, color: _getScoreColor(score)),
          ),
        ),
        onTap: () {
          final projectModel = Project.fromMap(data, projectId);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProjectDetailScreen(project: projectModel)),
          );
        },
      ),
    );
  }

  // =========================
  // 🤖 AI FEEDBACK
  // =========================
  Future<void> _generateAiFeedback() async {
    final snapshot = await FirebaseFirestore.instance.collection('projects').get();

    if (snapshot.docs.isEmpty) {
      _showDialog("No projects found for analysis.");
      return;
    }

    List<String> feedbackList = [];

    for (var doc in snapshot.docs) {
      final data = doc.data();
      final title = data['title'] ?? "Unnamed Project";

      double energy = (data['energy'] ?? 0).toDouble();
      double waste = (data['waste'] ?? 0).toDouble();
      double environment = (data['environment'] ?? 0).toDouble();
      double community = (data['community'] ?? 0).toDouble();
      double innovation = (data['innovation'] ?? 0).toDouble();

      List<String> tips = [];

      if (energy < 60) tips.add("⚡ Improve energy (+${(60 - energy).toInt()}%)");
      if (waste < 60) tips.add("🗑 Reduce waste (+${(60 - waste).toInt()}%)");
      if (environment < 60) tips.add("🌍 Improve environment score");
      if (community < 60) tips.add("👥 Improve community engagement");
      if (innovation < 60) tips.add("💡 Boost innovation");

      if (tips.isEmpty) {
        feedbackList.add("✅ $title is performing very well.");
      } else {
        feedbackList.add("📌 $title:\n- ${tips.join("\n- ")}");
      }
    }

    _showDialog(feedbackList.join("\n\n"));
  }

  // =========================
  // 💬 DIALOG & HELPERS
  // =========================
  void _showDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("AI Feedback 🤖"),
        content: SingleChildScrollView(child: Text(message)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Close"),
          ),
        ],
      ),
    );
  }

  Future<void> _showLogoutDialog(BuildContext context) async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (shouldLogout == true) {
      await FirebaseAuth.instance.signOut();
      if (context.mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      }
    }
  }

  void _showProfileDialog(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(currentUser?.uid).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!.data() as Map<String, dynamic>;
          return AlertDialog(
            title: const Text('My Profile'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(data['name'] ?? 'Unknown'),
                  subtitle: const Text('Name'),
                ),
                ListTile(
                  leading: const Icon(Icons.email),
                  title: Text(data['email'] ?? 'No email'),
                  subtitle: const Text('Email'),
                ),
                ListTile(
                  leading: const Icon(Icons.assignment_ind),
                  title: Text(data['role'] ?? 'Student'),
                  subtitle: const Text('Role'),
                ),
                if (data['department'] != null)
                  ListTile(
                    leading: const Icon(Icons.business),
                    title: Text(data['department']),
                    subtitle: const Text('Department'),
                  ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy').format(date);
  }

  Color _getScoreColor(double score) {
    if (score >= 70) return Colors.green;
    if (score >= 40) return Colors.orange;
    return Colors.red;
  }

  Widget _getScoreIcon(double score) {
    if (score >= 75) {
      return const Icon(Icons.emoji_events, color: Colors.amber, size: 28);
    } else if (score >= 50) {
      return const Icon(Icons.eco, color: Colors.green, size: 28);
    } else {
      return const Icon(Icons.warning, color: Colors.red, size: 28);
    }
  }
}