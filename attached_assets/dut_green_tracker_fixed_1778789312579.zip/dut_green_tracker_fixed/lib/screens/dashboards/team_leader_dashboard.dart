// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, sort_child_properties_last, unnecessary_null_comparison, unnecessary_brace_in_string_interps, avoid_print, deprecated_member_use, use_build_context_synchronously, unused_field

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/ai_difficulty_service.dart';
import '../dashboards/notifications_screen.dart';
import '../dashboards/calendar_screen.dart';
import 'package:intl/intl.dart';
import '../ai/ai_chatbot_screen.dart';
import '../team/weekly_update_screen.dart';
import '../team/team_feed_screen.dart';
import '../team/manage_team_screen.dart';
import '../tasks/assign_tasks_screen.dart';

class TeamLeaderDashboard extends StatefulWidget {
  final String? initialProjectId;
  
  const TeamLeaderDashboard({super.key, this.initialProjectId});

  @override
  State<TeamLeaderDashboard> createState() => _TeamLeaderDashboardState();
}

class _TeamLeaderDashboardState extends State<TeamLeaderDashboard> {
  String? _selectedProjectId;
  List<Map<String, dynamic>> _myProjects = [];
  List<Map<String, dynamic>> _projectMembers = [];
  List<Map<String, dynamic>> _projectTasks = [];
  List<Map<String, dynamic>> _unassignedTasks = [];
  bool _isLoading = true;
  bool _isUpdating = false;
  String? _errorMessage;
  String? _userName;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) {
      setState(() {
        _errorMessage = 'Please login first';
        _isLoading = false;
      });
      return;
    }

    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      _userName = userDoc.data()?['name'] ?? 'Team Leader';

      await _loadMyProjects();
      
      setState(() => _isLoading = false);
    } catch (e) {
      print('Error loading user data: $e');
      setState(() {
        _errorMessage = 'Error loading data: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadMyProjects() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    
    try {
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .where('leaderId', isEqualTo: currentUser.uid)
          .get();

      print('Projects found: ${projectsSnapshot.docs.length}');

      final projects = projectsSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Untitled',
          'description': data['description'] ?? '',
          'status': data['status'] ?? 'pending',
          'progress': data['progress'] ?? 0,
          'members': List<String>.from(data['members'] ?? []),
          'teamId': data['teamId'],
          'createdAt': data['createdAt'],
        };
      }).toList();
      
      setState(() {
        _myProjects = projects;
        
        if (widget.initialProjectId != null && _myProjects.any((p) => p['id'] == widget.initialProjectId)) {
          _selectedProjectId = widget.initialProjectId;
          _loadProjectData(_selectedProjectId!);
        } else if (_myProjects.isNotEmpty && _selectedProjectId == null) {
          _selectedProjectId = _myProjects.first['id'];
          _loadProjectData(_selectedProjectId!);
        }
      });
    } catch (e) {
      print('Error loading projects: $e');
      rethrow;
    }
  }

  Future<void> _loadProjectData(String projectId) async {
    setState(() => _isLoading = true);
    try {
      await Future.wait([
        _loadProjectMembers(projectId),
        _loadProjectTasks(projectId),
      ]);
    } catch (e) {
      print('Error loading project data: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadProjectMembers(String projectId) async {
    try {
      final project = _myProjects.firstWhere((p) => p['id'] == projectId);
      final teamId = project['teamId'];
      
      if (teamId != null && teamId.isNotEmpty) {
        final teamDoc = await FirebaseFirestore.instance
            .collection('teams')
            .doc(teamId)
            .get();
        
        final memberIds = List<String>.from(teamDoc.data()?['memberIds'] ?? []);
        final leaderId = teamDoc.data()?['leaderId'];
        
        final members = <Map<String, dynamic>>[];
        for (String id in memberIds) {
          final userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(id)
              .get();
          if (userDoc.exists) {
            members.add({
              'id': id,
              'name': userDoc.data()?['name'] ?? 'Unknown',
              'email': userDoc.data()?['email'] ?? '',
              'role': userDoc.data()?['role'] ?? 'member',
              'isLeader': id == leaderId,
            });
          }
        }
        setState(() => _projectMembers = members);
      } else {
        final memberIds = List<String>.from(project['members']);
        final members = <Map<String, dynamic>>[];
        for (String id in memberIds) {
          final userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(id)
              .get();
          if (userDoc.exists) {
            members.add({
              'id': id,
              'name': userDoc.data()?['name'] ?? 'Unknown',
              'email': userDoc.data()?['email'] ?? '',
              'role': userDoc.data()?['role'] ?? 'member',
              'isLeader': false,
            });
          }
        }
        setState(() => _projectMembers = members);
      }
    } catch (e) {
      print('Error loading members: $e');
    }
  }

  Future<void> _loadProjectTasks(String projectId) async {
    try {
      final tasksSnapshot = await FirebaseFirestore.instance
          .collection('tasks')
          .where('projectId', isEqualTo: projectId)
          .get();
      
      final allTasks = tasksSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? '',
          'description': data['description'] ?? '',
          'assignedTo': data['assignedTo'] ?? '',
          'deadline': (data['deadline'] as Timestamp?)?.toDate(),
          'difficulty': data['difficultyLevel'] ?? 1,
          'progress': data['progress'] ?? 0,
          'status': data['status'] ?? 'pending',
        };
      }).toList();
      
      final assigned = allTasks.where((t) => t['assignedTo'].toString().isNotEmpty).toList();
      final unassigned = allTasks.where((t) => t['assignedTo'].toString().isEmpty).toList();
      
      setState(() {
        _projectTasks = assigned;
        _unassignedTasks = unassigned;
      });
      
      await _updateProjectProgress(projectId);
    } catch (e) {
      print('Error loading tasks: $e');
    }
  }

  Future<void> _updateProjectProgress(String projectId) async {
    if (_projectTasks.isEmpty) return;
    
    int totalProgress = 0;
    for (var task in _projectTasks) {
      totalProgress += task['progress'] as int;
    }
    final averageProgress = (totalProgress / _projectTasks.length).toInt();
    
    await FirebaseFirestore.instance
        .collection('projects')
        .doc(projectId)
        .update({'progress': averageProgress});
    
    final projectIndex = _myProjects.indexWhere((p) => p['id'] == projectId);
    if (projectIndex != -1) {
      setState(() => _myProjects[projectIndex]['progress'] = averageProgress);
    }
  }

  String _normalizeStatus(String status) {
    if (status == null) return 'Pending';
    final lowerStatus = status.toLowerCase();
    if (lowerStatus == 'active') return 'Active';
    if (lowerStatus == 'pending') return 'Pending';
    if (lowerStatus == 'completed') return 'Completed';
    return status;
  }

  Future<void> _updateProjectStatus(String projectId, String newStatus) async {
    setState(() => _isUpdating = true);
    
    try {
      await FirebaseFirestore.instance
          .collection('projects')
          .doc(projectId)
          .update({'status': newStatus});
      
      final projectIndex = _myProjects.indexWhere((p) => p['id'] == projectId);
      if (projectIndex != -1) {
        setState(() => _myProjects[projectIndex]['status'] = newStatus);
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Project status updated to $newStatus'), backgroundColor: Colors.green),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _isUpdating = false);
    }
  }

  void _navigateToAssignTasks() {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project first')),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AssignTasksScreen(projectId: _selectedProjectId),
      ),
    );
  }

  void _navigateToManageTeam() {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project first')),
      );
      return;
    }
    final project = _myProjects.firstWhere((p) => p['id'] == _selectedProjectId);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ManageTeamScreen(
          projectId: _selectedProjectId!,
          projectTitle: project['title'],
        ),
      ),
    );
  }

  void _navigateToTeamFeed() {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project first')),
      );
      return;
    }
    final project = _myProjects.firstWhere((p) => p['id'] == _selectedProjectId);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TeamFeedScreen(
          projectId: _selectedProjectId!,
          projectTitle: project['title'],
        ),
      ),
    );
  }

  void _navigateToWeeklyUpdate() {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project first')),
      );
      return;
    }
    final project = _myProjects.firstWhere((p) => p['id'] == _selectedProjectId);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WeeklyUpdateScreen(
          projectId: _selectedProjectId!,
          projectTitle: project['title'],
        ),
      ),
    );
  }

  Future<void> _refreshData() async {
    if (_selectedProjectId != null) {
      await _loadProjectData(_selectedProjectId!);
    }
    await _loadMyProjects();
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    final project = _selectedProjectId != null
        ? _myProjects.firstWhere((p) => p['id'] == _selectedProjectId)
        : null;
    final allTasksCompleted = _projectTasks.isNotEmpty && 
        _projectTasks.every((task) => task['progress'] == 100);
    final projectCompleted = project != null && project['status'] == 'Completed';
    final hasUnassignedTasks = _unassignedTasks.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Team Leader Dashboard'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshData,
            tooltip: 'Refresh',
          ),
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const CalendarScreen()));
            },
            tooltip: 'Task Calendar',
          ),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection("notifications")
                .where("userId", isEqualTo: currentUser?.uid)
                .where("isRead", isEqualTo: false)
                .snapshots(),
            builder: (context, snapshot) {
              int count = snapshot.data?.docs.length ?? 0;
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen()));
                    },
                  ),
                  if (count > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                        constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                        child: Text(
                          count > 9 ? '9+' : count.toString(),
                          style: const TextStyle(color: Colors.white, fontSize: 10),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle),
            onSelected: (value) async {
              if (value == 'profile') {
                _showProfileDialog();
              } else if (value == 'logout') {
                await _showLogoutDialog();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'profile', child: Text('Profile')),
              const PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(child: Text(_errorMessage!))
              : _myProjects.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.assignment_late, size: 64, color: Colors.grey),
                          const SizedBox(height: 16),
                          const Text('No projects assigned to you'),
                          const SizedBox(height: 8),
                          Text('When a project is assigned, it will appear here'),
                        ],
                      ),
                    )
                  : Column(
                      children: [
                        // Project Selector
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.green.shade50,
                            border: Border(bottom: BorderSide(color: Colors.green.shade200)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Select Project', style: TextStyle(fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              DropdownButtonFormField<String>(
                                value: _selectedProjectId,
                                isExpanded: true,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                                  filled: true,
                                  fillColor: Colors.white,
                                ),
                                items: _myProjects.map((p) {
                                  return DropdownMenuItem<String>(
                                    value: p['id'],
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(p['title'], style: const TextStyle(fontSize: 14)),
                                        Text(
                                          '${p['progress']}% • ${p['members'].length} members',
                                          style: const TextStyle(fontSize: 10, color: Colors.grey),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                                onChanged: (value) {
                                  setState(() => _selectedProjectId = value);
                                  if (value != null) _loadProjectData(value);
                                },
                              ),
                            ],
                          ),
                        ),
                        
                        // Project Content
                        Expanded(
                          child: _selectedProjectId == null
                              ? const Center(child: Text('Select a project to manage'))
                              : RefreshIndicator(
                                  onRefresh: _refreshData,
                                  child: SingleChildScrollView(
                                    padding: const EdgeInsets.all(16),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        // Project Header Card
                                        _buildProjectHeader(project!),
                                        const SizedBox(height: 16),
                                        
                                        // Action Buttons Row
                                        if (!projectCompleted)
                                          Wrap(
                                            spacing: 12,
                                            runSpacing: 12,
                                            children: [
                                              _buildActionButton(
                                                icon: Icons.assignment_add,
                                                label: 'Assign Tasks',
                                                color: Colors.orange,
                                                onPressed: _navigateToAssignTasks,
                                              ),
                                              _buildActionButton(
                                                icon: Icons.group,
                                                label: 'Manage Team',
                                                color: Colors.purple,
                                                onPressed: _navigateToManageTeam,
                                              ),
                                              _buildActionButton(
                                                icon: Icons.rss_feed,
                                                label: 'Team Feed',
                                                color: Colors.teal,
                                                onPressed: _navigateToTeamFeed,
                                              ),
                                              _buildActionButton(
                                                icon: Icons.calendar_month,
                                                label: 'Weekly Update',
                                                color: Colors.blue,
                                                onPressed: _navigateToWeeklyUpdate,
                                              ),
                                            ],
                                          ),
                                        
                                        const SizedBox(height: 16),
                                        
                                        // Unassigned Tasks Section
                                        if (!projectCompleted && hasUnassignedTasks)
                                          _buildUnassignedTasksSection(),
                                        
                                        const SizedBox(height: 16),
                                        
                                        // Assigned Tasks Section
                                        _buildAssignedTasksSection(projectCompleted, allTasksCompleted),
                                        
                                        // Complete Project Button
                                        if (!projectCompleted && allTasksCompleted && _projectTasks.isNotEmpty)
                                          Padding(
                                            padding: const EdgeInsets.only(top: 16),
                                            child: SizedBox(
                                              width: double.infinity,
                                              child: ElevatedButton.icon(
                                                onPressed: () => _updateProjectStatus(_selectedProjectId!, 'Completed'),
                                                icon: const Icon(Icons.check_circle),
                                                label: const Text('Complete Project'),
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor: Colors.green,
                                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                                ),
                                              ),
                                            ),
                                          ),
                                        
                                        // Project Completed Banner
                                        if (projectCompleted)
                                          Container(
                                            padding: const EdgeInsets.all(16),
                                            decoration: BoxDecoration(
                                              color: Colors.green.shade50,
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: const Row(
                                              children: [
                                                Icon(Icons.celebration, color: Colors.green),
                                                SizedBox(width: 12),
                                                Expanded(child: Text('Project Completed! 🎉')),
                                              ],
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                        ),
                      ],
                    ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        child: const Icon(Icons.chat, color: Colors.white),
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const AIChatbotScreen()));
        },
        tooltip: 'Ask AI Assistant',
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return Expanded(
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 18),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildProjectHeader(Map<String, dynamic> project) {
    String displayStatus = _normalizeStatus(project['status']);
    Color statusColor = displayStatus == 'Active' ? Colors.green 
        : (displayStatus == 'Completed' ? Colors.blue : Colors.orange);
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(project['title'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            if (project['description'] != null && project['description'].toString().isNotEmpty)
              Text(project['description'], style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.flag, size: 12, color: statusColor),
                      const SizedBox(width: 4),
                      Text(displayStatus, style: TextStyle(fontSize: 11, color: statusColor)),
                    ],
                  ),
                ),
                _buildInfoChip(Icons.trending_up, '${project['progress']}%'),
                _buildInfoChip(Icons.people, '${_projectMembers.length} members'),
                _buildInfoChip(Icons.task, '${_projectTasks.length + _unassignedTasks.length} tasks'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: Colors.grey.shade600),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
        ],
      ),
    );
  }

  Widget _buildUnassignedTasksSection() {
    return Card(
      elevation: 2,
      color: Colors.orange.shade50,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.pending_actions, color: Colors.orange),
                const SizedBox(width: 8),
                const Text('Unassigned Tasks', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(12)),
                  child: Text('${_unassignedTasks.length} tasks', style: TextStyle(color: Colors.orange.shade800)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ..._unassignedTasks.map((task) => _buildUnassignedTaskCard(task)),
          ],
        ),
      ),
    );
  }

  Widget _buildUnassignedTaskCard(Map<String, dynamic> task) {
    final difficultyColor = AIDifficultyService.getDifficultyColor(task['difficulty']);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(color: difficultyColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                  child: Icon(Icons.task, size: 18, color: difficultyColor),
                ),
                const SizedBox(width: 8),
                Expanded(child: Text(task['title'], style: const TextStyle(fontWeight: FontWeight.bold))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: difficultyColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                  child: Text('Lvl ${task['difficulty']}', style: TextStyle(fontSize: 10, color: difficultyColor)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 12, color: Colors.grey),
                const SizedBox(width: 4),
                Text(
                  task['deadline'] != null ? 'Due: ${DateFormat('dd MMM yyyy').format(task['deadline'])}' : 'No deadline',
                  style: const TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text('Assign to:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _projectMembers.map((member) {
                return ActionChip(
                  label: Text(member['name']),
                  onPressed: () => _assignTask(task['id'], member['id']),
                  backgroundColor: Colors.green.shade50,
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _assignTask(String taskId, String memberId) async {
    setState(() => _isUpdating = true);
    try {
      await FirebaseFirestore.instance.collection('tasks').doc(taskId).update({
        'assignedTo': memberId,
        'status': 'in_progress',
      });
      await _loadProjectTasks(_selectedProjectId!);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Task assigned!'), backgroundColor: Colors.green),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _isUpdating = false);
    }
  }

  Widget _buildAssignedTasksSection(bool projectCompleted, bool allTasksCompleted) {
    if (_projectTasks.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: Column(
              children: [
                const Icon(Icons.task_alt, size: 48, color: Colors.grey),
                const SizedBox(height: 8),
                const Text('No tasks assigned yet'),
                Text('Assign tasks from the "Assign Tasks" button', style: TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
        ),
      );
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.assignment_turned_in, color: Colors.green),
                const SizedBox(width: 8),
                const Text('Assigned Tasks', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const Spacer(),
                if (allTasksCompleted && !projectCompleted)
                  const Icon(Icons.check_circle, color: Colors.green),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(12)),
                  child: Text('${_projectTasks.length} tasks', style: const TextStyle(fontSize: 11)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ..._projectTasks.map((task) => _buildTaskCard(task, projectCompleted)),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskCard(Map<String, dynamic> task, bool projectCompleted) {
    final difficultyColor = AIDifficultyService.getDifficultyColor(task['difficulty']);
    final isCompleted = task['progress'] == 100;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: difficultyColor.withOpacity(0.1),
          child: Icon(isCompleted ? Icons.check_circle : Icons.task, color: difficultyColor),
        ),
        title: Text(task['title'], style: TextStyle(decoration: isCompleted ? TextDecoration.lineThrough : null)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Difficulty: ${task['difficulty']}/10', style: TextStyle(fontSize: 10, color: difficultyColor)),
            LinearProgressIndicator(value: task['progress'] / 100, backgroundColor: Colors.grey.shade200),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            FutureBuilder(
              future: FirebaseFirestore.instance.collection('users').doc(task['assignedTo']).get(),
              builder: (context, snapshot) {
                final name = snapshot.hasData ? snapshot.data!['name'] ?? 'Unknown' : 'Loading...';
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: Colors.green.shade100, borderRadius: BorderRadius.circular(10)),
                  child: Text(name.length > 10 ? '${name.substring(0, 8)}...' : name, style: const TextStyle(fontSize: 9)),
                );
              },
            ),
            const SizedBox(width: 6),
            Text('${task['progress']}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (task['description'].toString().isNotEmpty)
                  Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(task['description'])),
                Row(
                  children: [
                    const Icon(Icons.calendar_today, size: 14, color: Colors.grey),
                    const SizedBox(width: 4),
                    Text('Deadline: ${DateFormat('dd MMM yyyy').format(task['deadline'])}'),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.person, size: 14, color: Colors.grey),
                    const SizedBox(width: 4),
                    Expanded(
                      child: FutureBuilder(
                        future: FirebaseFirestore.instance.collection('users').doc(task['assignedTo']).get(),
                        builder: (context, snapshot) {
                          final name = snapshot.hasData ? snapshot.data!['name'] ?? 'Unknown' : 'Loading...';
                          return Text('Assigned to: $name');
                        },
                      ),
                    ),
                  ],
                ),
                if (projectCompleted && !isCompleted)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('Project completed - task locked', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  ),
                if (isCompleted)
                  Container(
                    margin: const EdgeInsets.only(top: 8),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(8)),
                    child: const Row(
                      children: [
                        Icon(Icons.check_circle, color: Colors.green, size: 16),
                        SizedBox(width: 8),
                        Text('Task Completed!', style: TextStyle(color: Colors.green)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showLogoutDialog() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Logout')),
        ],
      ),
    );
    if (shouldLogout == true) {
      await FirebaseAuth.instance.signOut();
      if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }

  void _showProfileDialog() {
    final currentUser = FirebaseAuth.instance.currentUser;
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(currentUser?.uid).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final data = snapshot.data!.data() as Map<String, dynamic>;
          return AlertDialog(
            title: const Text('My Profile'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(leading: const Icon(Icons.person), title: Text(data['name'] ?? 'Unknown'), subtitle: const Text('Name')),
                ListTile(leading: const Icon(Icons.email), title: Text(data['email'] ?? 'No email'), subtitle: const Text('Email')),
                ListTile(leading: const Icon(Icons.assignment_ind), title: Text(data['role'] ?? 'Team Leader'), subtitle: const Text('Role')),
              ],
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
          );
        },
      ),
    );
  }
}