// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:excel/excel.dart' as excel;
import 'package:file_picker/file_picker.dart';
import '../models/project.dart';
import '../providers/project_provider.dart';


class ExcelUploadScreen extends ConsumerStatefulWidget {
  const ExcelUploadScreen({super.key});

  @override
  ConsumerState<ExcelUploadScreen> createState() => _ExcelUploadScreenState();
}

class _ExcelUploadScreenState extends ConsumerState<ExcelUploadScreen> {
  bool isLoading = false;
  String? fileName;

  Future<void> pickAndUploadExcel() async {
    try {
      setState(() {
        isLoading = true;
        fileName = null;
      });
      
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx', 'xls'],
      );

      if (result != null) {
        fileName = result.files.first.name;
        final bytes = result.files.first.bytes;
        final excelData = excel.Excel.decodeBytes(bytes!); 
        
        final sheet = excelData.tables[excelData.tables.keys.first];
        final List<Map<String, dynamic>> projects = [];
        
        if (sheet != null && sheet.rows.isNotEmpty) {
          // Skip header row (row 0)
          for (var i = 1; i < sheet.rows.length; i++) {
            final row = sheet.rows[i];
            if (row.isNotEmpty && row[0] != null && row[0]!.value.toString().isNotEmpty) {
              projects.add({
                'title': row[0]?.value.toString() ?? 'Untitled',
                'description': row.length > 1 ? row[1]?.value.toString() ?? '' : '',
                'projectTypeId': row.length > 2 ? row[2]?.value.toString() ?? '1' : '1',
                'status': 'pending',
                'progress': 0,
                'createdAt': DateTime.now(),
              });
            }
          }
        }
        
        if (projects.isEmpty) {
          throw Exception('No valid projects found in Excel file');
        }
        
        final service = ref.read(firebaseServiceProvider);
        int successCount = 0;
        
        for (final projectData in projects) {
          try {
            final project = Project(
              id: '',
              title: projectData['title'],
              status: projectData['status'],
              progress: projectData['progress'],
              projectTypeId: projectData['projectTypeId'],

              // 🔥 Add these to satisfy the required parameters in your model:
  scores: {}, // Initialize with an empty Map
  sustainabilityScore: 0.0, // Initialize with 0.0
  
  // Optional: these are already handled by your model defaults/nullability
  members: [],
            );
            await service.addProject(project);
            successCount++;
          } catch (e) {
            debugPrint('Error uploading project: $e');
          }
        }
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Successfully uploaded $successCount out of ${projects.length} projects'),
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 3),
            ),
          );
          
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted) Navigator.pop(context);
          });
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('No file selected'),
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Upload Excel File'),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: isLoading
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 20),
                  Text(
                    'Uploading ${fileName ?? "file"}...',
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.upload_file,
                      size: 100,
                      color: Colors.green[300],
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Upload Multiple Projects',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Upload an Excel file (.xlsx or .xls) with your projects',
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 32),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[300]!),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Excel Format Instructions:',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 12),
                          _buildInstructionRow('Column A', 'Project Title', 'Required'),
                          _buildInstructionRow('Column B', 'Description', 'Optional'),
                          _buildInstructionRow('Column C', 'Project Type ID', 'Default: 1'),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.blue[50],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.info, color: Colors.blue, size: 20),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    'First row will be skipped as header. Each row after creates a new project.',
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    ElevatedButton.icon(
                      onPressed: pickAndUploadExcel,
                      icon: const Icon(Icons.cloud_upload),
                      label: const Text(
                        'Select Excel File',
                        style: TextStyle(fontSize: 16),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 32,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextButton.icon(
                      onPressed: () {
                        _showHelpDialog(context);
                      },
                      icon: const Icon(Icons.help_outline),
                      label: const Text('Need help with Excel format?'),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildInstructionRow(String column, String description, String requirement) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 80,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.green[100],
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              column,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              description,
              style: const TextStyle(fontSize: 14),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: requirement == 'Required' ? Colors.red[100] : Colors.grey[200],
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              requirement,
              style: TextStyle(
                fontSize: 11,
                color: requirement == 'Required' ? Colors.red[700] : Colors.grey[700],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Excel Format Help'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Create an Excel file with the following columns:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Row 1 (Header):', style: TextStyle(fontWeight: FontWeight.bold)),
                      Text('A1: "Title"'),
                      Text('B1: "Description"'),
                      Text('C1: "Project Type ID"'),
                      SizedBox(height: 8),
                      Text('Row 2+ (Data):', style: TextStyle(fontWeight: FontWeight.bold)),
                      Text('A2: "Green Campus Initiative"'),
                      Text('B2: "Reduce carbon footprint"'),
                      Text('C2: "1"'),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Note: The first row will be skipped automatically.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }
}