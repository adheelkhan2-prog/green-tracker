// ignore_for_file: deprecated_member_use, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../providers/project_provider.dart';
import '../projects/projects_list_screen.dart';
import '../dashboards/notifications_screen.dart';
import '../../models/project.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  String? _userRole;
  String? _userName;
  bool _isLoading = true;
  int _totalProjects = 0;
  int _activeProjects = 0;
  int _completedProjects = 0;
  double _avgProgress = 0;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadStats();
  }

  Future<void> _loadUserData() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUser.uid)
        .get();

    setState(() {
      _userRole = userDoc.data()?['role'] ?? 'staff';
      _userName = userDoc.data()?['name'] ?? 'User';
      _isLoading = false;
    });
  }

  Future<void> _loadStats() async {
    final snapshot = await FirebaseFirestore.instance.collection('projects').get();
    final projects = snapshot.docs;
    
    int total = projects.length;
    int active = 0;
    int completed = 0;
    double totalProgress = 0;
    
    for (var doc in projects) {
      final status = doc.data()['status'] ?? 'pending';
      final progress = (doc.data()['progress'] ?? 0).toDouble();
      
      if (status == 'Active' || status == 'active' || status == 'in_progress') {
        active++;
      }
      if (status == 'Completed' || status == 'completed') {
        completed++;
      }
      totalProgress += progress;
    }
    
    setState(() {
      _totalProjects = total;
      _activeProjects = active;
      _completedProjects = completed;
      _avgProgress = total > 0 ? totalProgress / total : 0;
    });
  }

  Future<void> _showLogoutDialog() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (shouldLogout == true) {
      await FirebaseAuth.instance.signOut();
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.eco, color: Colors.white),
            const SizedBox(width: 8),
            const Text("DUT GreenTrack"),
            const Spacer(),
            if (_userRole != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _userRole!.toUpperCase(),
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
          ],
        ),
        backgroundColor: Colors.green,
        actions: [
          // Notifications
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection("notifications")
                .where("userId", isEqualTo: currentUser?.uid)
                .where("isRead", isEqualTo: false)
                .snapshots(),
            builder: (context, snapshot) {
              int count = snapshot.data?.docs.length ?? 0;
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const NotificationsScreen(),
                        ),
                      );
                    },
                  ),
                  if (count > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        child: Text(
                          count > 9 ? '9+' : count.toString(),
                          style: const TextStyle(color: Colors.white, fontSize: 10),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          // Profile & Logout
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle),
            onSelected: (value) async {
              if (value == 'profile') {
                _showProfileDialog();
              } else if (value == 'logout') {
                await _showLogoutDialog();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person, size: 20),
                    SizedBox(width: 12),
                    Text('My Profile'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, size: 20, color: Colors.red),
                    SizedBox(width: 12),
                    Text('Logout', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStats,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Welcome Section
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.green.shade400, Colors.green.shade700],
                        ),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 30,
                            backgroundColor: Colors.white,
                            child: Text(
                              _userName?.substring(0, 1).toUpperCase() ?? 'U',
                              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Welcome back,',
                                  style: TextStyle(color: Colors.white70, fontSize: 14),
                                ),
                                Text(
                                  _userName ?? 'User',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Stats Section
                    const Text(
                      "Overview",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    
                    Row(
                      children: [
                        _buildStatCard("Total Projects", _totalProjects.toString(), Icons.folder, Colors.blue),
                        const SizedBox(width: 12),
                        _buildStatCard("Active", _activeProjects.toString(), Icons.play_circle, Colors.orange),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _buildStatCard("Completed", _completedProjects.toString(), Icons.check_circle, Colors.green),
                        const SizedBox(width: 12),
                        _buildStatCard("Avg Progress", "${_avgProgress.toInt()}%", Icons.trending_up, Colors.purple),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Role-specific Quick Actions
                    const Text(
                      "Quick Actions",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    _buildQuickActions(),
                    const SizedBox(height: 24),

                    // Recent Projects
                    const Text(
                      "Recent Projects",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 300,
                      child: Consumer(
                        builder: (context, ref, _) {
                          final projectsAsync = ref.watch(projectStreamProvider);
                          return projectsAsync.when(
                            data: (projects) {
                              final recentProjects = projects.take(5).toList();
                              if (recentProjects.isEmpty) {
                                return Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.folder_open, size: 48, color: Colors.grey.shade400),
                                      const SizedBox(height: 8),
                                      Text('No projects yet', style: TextStyle(color: Colors.grey.shade600)),
                                    ],
                                  ),
                                );
                              }
                              return ListView.builder(
                                itemCount: recentProjects.length,
                                itemBuilder: (context, index) {
                                  final project = recentProjects[index];
                                  return _buildProjectCard(project);
                                },
                              );
                            },
                            loading: () => const Center(child: CircularProgressIndicator()),
                            error: (e, _) => Center(child: Text('Error: $e')),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
                  ),
                  Text(
                    title,
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    final role = _userRole;
    
    if (role == 'admin') {
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          _buildActionChip(Icons.group_add, 'Create Team', Colors.green, () {
            Navigator.pushNamed(context, '/admin');
          }),
          _buildActionChip(Icons.person_add, 'Add User', Colors.blue, () {
            Navigator.pushNamed(context, '/admin');
          }),
          _buildActionChip(Icons.analytics, 'Analytics', Colors.purple, () {
            Navigator.pushNamed(context, '/admin');
          }),
        ],
      );
    } else if (role == 'lecturer' || role == 'staff') {
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          _buildActionChip(Icons.assignment, 'View Projects', Colors.orange, () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ProjectListScreen()),
            );
          }),
          _buildActionChip(Icons.people, 'My Team', Colors.green, () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Team management coming soon')),
            );
          }),
        ],
      );
    } else {
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          _buildActionChip(Icons.assignment, 'View Projects', Colors.blue, () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ProjectListScreen()),
            );
          }),
          _buildActionChip(Icons.leaderboard, 'Leaderboard', Colors.orange, () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Leaderboard coming soon')),
            );
          }),
        ],
      );
    }
  }

  Widget _buildActionChip(IconData icon, String label, Color color, VoidCallback onTap) {
    return ActionChip(
      avatar: Icon(icon, size: 16, color: color),
      label: Text(label),
      onPressed: onTap,
      backgroundColor: color.withOpacity(0.1),
      side: BorderSide(color: color.withOpacity(0.5)),
    );
  }

  Widget _buildProjectCard(Project project) {
    Color statusColor;
    if (project.status == "Active" || project.status == "active") {
      statusColor = Colors.orange;
    } else if (project.status == "Completed" || project.status == "completed") {
      statusColor = Colors.green;
    } else {
      statusColor = Colors.grey;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(Icons.eco, color: statusColor),
        title: Text(project.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('Status: ${project.status}'),
        trailing: Text("${project.progress}%", style: TextStyle(color: statusColor, fontWeight: FontWeight.bold)),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const ProjectListScreen(),
            ),
          );
        },
      ),
    );
  }

 Widget? _buildFloatingActionButton() {
  final role = _userRole;
  
  // Only admins and lecturers can add projects
  if (role == 'admin' || role == 'lecturer' || role == 'staff') {
    return FloatingActionButton(
      backgroundColor: Colors.green,
      child: const Icon(Icons.add),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const ProjectListScreen(),
          ),
        );
      },
    );
  }
  return const SizedBox.shrink(); // Return empty widget instead of null
}

  void _showProfileDialog() {
    final currentUser = FirebaseAuth.instance.currentUser;
    
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser?.uid)
            .get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!.data() as Map<String, dynamic>;
          return AlertDialog(
            title: const Text('My Profile'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(data['name'] ?? 'Unknown'),
                  subtitle: const Text('Name'),
                ),
                ListTile(
                  leading: const Icon(Icons.email),
                  title: Text(data['email'] ?? 'No email'),
                  subtitle: const Text('Email'),
                ),
                ListTile(
                  leading: const Icon(Icons.assignment_ind),
                  title: Text(data['role'] ?? 'Staff'),
                  subtitle: const Text('Role'),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
  }
}

