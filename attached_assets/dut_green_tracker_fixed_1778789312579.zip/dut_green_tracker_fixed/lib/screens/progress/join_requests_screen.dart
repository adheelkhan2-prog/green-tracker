import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class JoinRequestsScreen extends StatelessWidget {
  final String projectId;

  const JoinRequestsScreen({super.key, required this.projectId});

  Future<void> updateRequest(String id, String status) async {
  final doc = FirebaseFirestore.instance
      .collection("join_requests")
      .doc(id);

  final snapshot = await doc.get();
  final data = snapshot.data();

  if (data == null) return;

  final projectId = data['projectId'];
  final userId = data['userId'];

  // ============================
  // ✅ APPROVE LOGIC
  // ============================
  if (status == "approved") {
    // 1. Update request
    await doc.update({"status": "approved"});

    // 2. Add user to project
    await FirebaseFirestore.instance
        .collection("projects")
        .doc(projectId)
        .update({
      "members": FieldValue.arrayUnion([userId])
    });

    // 3. 🔔 SEND NOTIFICATION
    await FirebaseFirestore.instance.collection("notifications").add({
      "userId": userId,
      "title": "Join Request Approved",
      "message": "You have been added to the project 🎉",
      "type": "approval",
      "read": false,
      "createdAt": Timestamp.now(),
    });
  }

  // ============================
  // ❌ REJECT LOGIC
  // ============================
  else if (status == "rejected") {
    await doc.update({"status": "rejected"});

    // 🔔 Optional: notify rejection
    await FirebaseFirestore.instance.collection("notifications").add({
      "userId": userId,
      "title": "Join Request Rejected",
      "message": "Your request was not approved",
      "type": "rejection",
      "read": false,
      "createdAt": Timestamp.now(),
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Join Requests")),

      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("join_requests")
            .where("projectId", isEqualTo: projectId)
            .where("status", isEqualTo: "pending")
            .snapshots(),
        builder: (context, snapshot) {

          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final requests = snapshot.data!.docs;

          if (requests.isEmpty) {
            return const Center(child: Text("No requests"));
          }

          return ListView.builder(
            itemCount: requests.length,
            itemBuilder: (context, index) {
              final request = requests[index];
              final data = request.data() as Map<String, dynamic>;

              return StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc(data['userId'])
                    .snapshots(),
                builder: (context, userSnap) {

                  String name = "Loading...";
                  if (userSnap.hasData &&
                      userSnap.data!.data() != null) {
                    final userData =
                        userSnap.data!.data() as Map<String, dynamic>;
                    name = userData['name'] ?? "Unknown";
                  }

                  return Card(
                    child: ListTile(
                      title: Text(name),

                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          // ✅ APPROVE
                          IconButton(
                            icon: const Icon(Icons.check, color: Colors.green),
                            onPressed: () =>
                                updateRequest(request.id, "approved"),
                          ),

                          // ❌ REJECT
                          IconButton(
                            icon: const Icon(Icons.close, color: Colors.red),
                            onPressed: () =>
                                updateRequest(request.id, "rejected"),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}