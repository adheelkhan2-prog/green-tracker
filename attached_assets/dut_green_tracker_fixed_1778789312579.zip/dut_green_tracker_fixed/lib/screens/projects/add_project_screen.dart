// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, unused_field, avoid_print, unused_element, use_build_context_synchronously, deprecated_member_use, prefer_final_fields

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:file_picker/file_picker.dart';
import 'package:excel/excel.dart' as excel;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../../models/task.dart';
import '../../providers/project_provider.dart';
import '../../services/ai_difficulty_service.dart';
import '../../services/email_service.dart';
import 'package:intl/intl.dart';

class AddProjectScreen extends ConsumerStatefulWidget {
  const AddProjectScreen({super.key});

  @override
  ConsumerState<AddProjectScreen> createState() => _AddProjectScreenState();
}

class _AddProjectScreenState extends ConsumerState<AddProjectScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  String status = "Pending";
  int progress = 0;

  String? projectTypeId;
  String? campusId;
  String? leaderId;
  
  Map<String, dynamic>? _selectedProjectTypeData;

  double environment = 50;
  double energy = 50;
  double waste = 50;
  double community = 50;
  double innovation = 50;

  List<String> members = [];
  
  // Task section
  List<Map<String, dynamic>> _tasks = [];
  bool _showTaskSection = true;

  bool isSaving = false;

  // Visibility fields
  String _visibility = 'open';
  String? _selectedDepartment;
  String? _selectedFaculty;
  
  // Date fields
  DateTime? _startDate;
  DateTime? _endDate;
  
  // Excel upload
  bool _isUploadingExcel = false;
  String? _excelErrorMessage;
  
  // Dropdown options
  final List<String> _departments = [
    "Computer Science",
    "Information Technology",
    "Community Health Studies",
    "Biotechnology & Food Science",
    "Horticulture",
    "Mechanical Engineering",
    "Electrical Engineering",
    "Civil Engineering",
    "Business Management",
    "Accounting",
    "Marketing",
    "Communications",
    "Other",
  ];
  
  final List<String> _faculties = [
    "Faculty of Applied Sciences",
    "Faculty of Accounting & Informatics",
    "Faculty of Engineering & the Built Environment",
    "Faculty of Health Sciences",
    "Faculty of Management Sciences",
    "Faculty of Arts & Design",
    "Other",
  ];

  // Template headers for Excel validation
  final List<String> _requiredHeaders = [
    'Project Title',
    'Description',
    'Project Type ID',
    'Campus ID',
    'Team Leader ID',
    'Visibility',
    'Department',
    'Faculty',
    'Start Date',
    'End Date',
    'Environment Score',
    'Energy Score',
    'Waste Score',
    'Community Score',
    'Innovation Score',
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  // ==================== EXCEL UPLOAD METHODS ====================
  
  Future<void> _downloadExcelTemplate() async {
    try {
      var excelFile = excel.Excel.createExcel();
      excel.Sheet sheet = excelFile['Projects'];
      
      sheet.appendRow(_requiredHeaders.map((h) => excel.TextCellValue(h)).toList());
      
      sheet.appendRow([
        excel.TextCellValue('Example Project'),
        excel.TextCellValue('This is an example project description'),
        excel.TextCellValue('project_type_id_here'),
        excel.TextCellValue('campus_id_here'),
        excel.TextCellValue('user_id_here'),
        excel.TextCellValue('open'),
        excel.TextCellValue('Computer Science'),
        excel.TextCellValue('Faculty of IT'),
        excel.TextCellValue('2024-01-15'),
        excel.TextCellValue('2024-03-30'),
        excel.TextCellValue('80'),
        excel.TextCellValue('75'),
        excel.TextCellValue('70'),
        excel.TextCellValue('85'),
        excel.TextCellValue('90'),
      ]);
      
      sheet.appendRow([]);
      sheet.appendRow([excel.TextCellValue('Instructions:')]);
      sheet.appendRow([excel.TextCellValue('1. First row must contain headers exactly as shown')]);
      sheet.appendRow([excel.TextCellValue('2. Visibility: open, department, or restricted')]);
      sheet.appendRow([excel.TextCellValue('3. Leave Department blank if Visibility is open or restricted')]);
      sheet.appendRow([excel.TextCellValue('4. Dates format: YYYY-MM-DD')]);
      sheet.appendRow([excel.TextCellValue('5. Scores must be between 0 and 100')]);
      sheet.appendRow([excel.TextCellValue('6. Get Campus ID and Project Type ID from Firestore collections')]);
      
      final bytes = excelFile.save();
      if (bytes != null) {
        final String path = await _saveExcelFile(bytes, 'project_template.xlsx');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Template saved to: $path'), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      _showError('Error creating template: $e');
    }
  }
  
  Future<String> _saveExcelFile(List<int> bytes, String fileName) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/$fileName');
      await file.writeAsBytes(bytes);
      return file.path;
    } catch (e) {
      print('Error saving file: $e');
      return 'Failed to save file: $e';
    }
  }
  
  Future<void> _uploadMultipleProjects() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'xls'],
    );
    
    if (result == null) return;
    
    setState(() {
      _isUploadingExcel = true;
      _excelErrorMessage = null;
    });
    
    try {
      final bytes = result.files.first.bytes;
      if (bytes == null) throw Exception('Failed to read file');
      
      var excelFile = excel.Excel.decodeBytes(bytes);
      var sheet = excelFile.tables[excelFile.tables.keys.first];
      
      if (sheet == null) throw Exception('No sheet found in Excel file');
      
      final headerRow = sheet.rows.first;
      final headers = headerRow.map((cell) => cell?.value?.toString().trim() ?? '').toList();
      
      final validationResult = _validateHeaders(headers);
      if (validationResult != null) {
        throw Exception(validationResult);
      }
      
      int successCount = 0;
      int errorCount = 0;
      List<String> errors = [];
      
      for (int i = 1; i < sheet.rows.length; i++) {
        final row = sheet.rows[i];
        if (row.isEmpty || row.every((cell) => cell?.value == null || cell!.value.toString().trim().isEmpty)) {
          continue;
        }
        
        try {
          final projectData = _validateAndParseRow(row, i + 1);
          if (projectData != null) {
            await _createProjectFromExcel(projectData);
            successCount++;
          }
        } catch (e) {
          errorCount++;
          errors.add('Row ${i + 1}: $e');
        }
      }
      
      if (mounted) {
        String message = '✅ $successCount projects created';
        if (errorCount > 0) {
          message += ' | ❌ $errorCount failed';
          _showError('$message\n\n${errors.take(3).join('\n')}');
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message), backgroundColor: Colors.green),
          );
        }
      }
    } catch (e) {
      _showError('Excel upload failed: $e');
    } finally {
      if (mounted) setState(() => _isUploadingExcel = false);
    }
  }
  
  String? _validateHeaders(List<String> headers) {
    final missingHeaders = _requiredHeaders.where((required) => 
      !headers.any((h) => h.toLowerCase() == required.toLowerCase())
    ).toList();
    
    if (missingHeaders.isNotEmpty) {
      return 'Missing required headers: ${missingHeaders.join(', ')}';
    }
    return null;
  }
  
  Map<String, dynamic>? _validateAndParseRow(List<excel.Data?> row, int rowNumber) {
    String getCellValue(int index) {
      if (index >= row.length) return '';
      final cell = row[index];
      if (cell == null) return '';
      final value = cell.value;
      if (value == null) return '';
      return value.toString().trim();
    }
    
    final title = getCellValue(0);
    final description = getCellValue(1);
    final projectTypeId = getCellValue(2);
    final campusId = getCellValue(3);
    final leaderId = getCellValue(4);
    final visibility = getCellValue(5).toLowerCase();
    final department = getCellValue(6);
    final faculty = getCellValue(7);
    
    DateTime? startDate;
    DateTime? endDate;
    try {
      final startDateStr = getCellValue(8);
      if (startDateStr.isNotEmpty) startDate = DateTime.parse(startDateStr);
      final endDateStr = getCellValue(9);
      if (endDateStr.isNotEmpty) endDate = DateTime.parse(endDateStr);
    } catch (e) {
      throw Exception('Invalid date format. Use YYYY-MM-DD');
    }
    
    final environment = double.tryParse(getCellValue(10)) ?? 50;
    final energy = double.tryParse(getCellValue(11)) ?? 50;
    final waste = double.tryParse(getCellValue(12)) ?? 50;
    final community = double.tryParse(getCellValue(13)) ?? 50;
    final innovation = double.tryParse(getCellValue(14)) ?? 50;
    
    if (title.isEmpty) throw Exception('Project Title is required');
    if (projectTypeId.isEmpty) throw Exception('Project Type ID is required');
    if (campusId.isEmpty) throw Exception('Campus ID is required');
    if (leaderId.isEmpty) throw Exception('Team Leader ID is required');
    if (!['open', 'department', 'restricted'].contains(visibility)) {
      throw Exception('Visibility must be open, department, or restricted');
    }
    
    if (visibility == 'department' && department.isEmpty) {
      throw Exception('Department is required when visibility is department');
    }
    
    if (startDate != null && endDate != null && startDate.isAfter(endDate)) {
      throw Exception('End date must be after start date');
    }
    
    final scores = [environment, energy, waste, community, innovation];
    for (var score in scores) {
      if (score < 0 || score > 100) throw Exception('Scores must be between 0 and 100');
    }
    
    return {
      'title': title,
      'description': description,
      'projectTypeId': projectTypeId,
      'campusId': campusId,
      'leaderId': leaderId,
      'visibility': visibility,
      'department': visibility == 'department' ? department : null,
      'faculty': faculty.isNotEmpty ? faculty : null,
      'startDate': startDate,
      'endDate': endDate,
      'environment': environment,
      'energy': energy,
      'waste': waste,
      'community': community,
      'innovation': innovation,
      'status': 'pending',
      'progress': 0,
    };
  }
  
  Future<void> _createProjectFromExcel(Map<String, dynamic> projectData) async {
    final sustainabilityScore = (0.3 * projectData['environment']) +
        (0.2 * projectData['energy']) +
        (0.2 * projectData['waste']) +
        (0.2 * projectData['community']) +
        (0.1 * projectData['innovation']);
    
    final scores = {
      "environment": projectData['environment'],
      "energy": projectData['energy'],
      "waste": projectData['waste'],
      "community": projectData['community'],
      "innovation": projectData['innovation'],
    };
    
    await FirebaseFirestore.instance.collection('projects').add({
      'title': projectData['title'],
      'description': projectData['description'],
      'status': projectData['status'],
      'progress': projectData['progress'],
      'projectTypeId': projectData['projectTypeId'],
      'campusId': projectData['campusId'],
      'leaderId': projectData['leaderId'],
      'members': [],
      'teamId': null,
      'visibility': projectData['visibility'],
      'department': projectData['department'],
      'faculty': projectData['faculty'],
      'startDate': projectData['startDate'] != null ? Timestamp.fromDate(projectData['startDate']) : null,
      'endDate': projectData['endDate'] != null ? Timestamp.fromDate(projectData['endDate']) : null,
      'scores': scores,
      'sustainabilityScore': sustainabilityScore,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // ==================== UI BUILD METHODS ====================

  void _addTask() {
    setState(() {
      _tasks.add({
        'title': '',
        'description': '',
        'deadline': null,
        'difficulty': 1,
        'isEditing': true,
      });
      _showTaskSection = true;
    });
  }

  void _removeTask(int index) {
    setState(() {
      _tasks.removeAt(index);
    });
  }

  void _updateTask(int index, String field, dynamic value) {
    setState(() {
      _tasks[index][field] = value;
      if (field == 'title' || field == 'description') {
        _calculateTaskDifficulty(index);
      }
    });
  }

  Future<void> _calculateTaskDifficulty(int index) async {
    final task = _tasks[index];
    final title = task['title']?.toString() ?? '';
    final description = task['description']?.toString() ?? '';
    
    if (title.isEmpty) return;
    
    final difficulty = await AIDifficultyService.calculateDifficulty(
      title: title,
      description: description,
      deadline: task['deadline'] ?? DateTime.now().add(const Duration(days: 7)),
      projectId: 'temp',
    );
    
    setState(() {
      _tasks[index]['difficulty'] = difficulty;
    });
  }

  void _showTaskDialog(int index) {
    final task = _tasks[index];
    
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          DateTime? selectedDeadline = task['deadline'];
          
          return DraggableScrollableSheet(
            initialChildSize: 0.9,
            minChildSize: 0.5,
            maxChildSize: 0.95,
            expand: false,
            builder: (context, scrollController) => SingleChildScrollView(
              controller: scrollController,
              child: Padding(
                padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom,
                  left: 16,
                  right: 16,
                  top: 16,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Task Details', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 20),
                    
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Task Title *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.title),
                      ),
                      onChanged: (value) {
                        setModalState(() { task['title'] = value; });
                        _updateTask(index, 'title', value);
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Description',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.description),
                      ),
                      maxLines: 3,
                      onChanged: (value) {
                        setModalState(() { task['description'] = value; });
                        _updateTask(index, 'description', value);
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    ListTile(
                      leading: const Icon(Icons.calendar_today),
                      title: Text(
                        selectedDeadline == null
                            ? 'Select Deadline *'
                            : 'Deadline: ${DateFormat('dd MMM yyyy').format(selectedDeadline!)}',
                      ),
                      onTap: () async {
                        final date = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (date != null) {
                          setModalState(() {
                            selectedDeadline = date;
                            task['deadline'] = date;
                          });
                          _updateTask(index, 'deadline', date);
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    Card(
                      color: AIDifficultyService.getDifficultyColor(task['difficulty'] ?? 1).withOpacity(0.1),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            const Icon(Icons.auto_awesome, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                children: [
                                  const Text('AI Difficulty Analysis', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                  Text(
                                    '${AIDifficultyService.getDifficultyLabel(task['difficulty'] ?? 1)} (Level ${task['difficulty']}/10)',
                                    style: TextStyle(fontSize: 11, color: AIDifficultyService.getDifficultyColor(task['difficulty'] ?? 1)),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 12)),
                            child: const Text('Cancel'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              if (task['title']?.toString().isEmpty ?? true) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Please enter task title')),
                                );
                                return;
                              }
                              if (task['deadline'] == null) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Please select a deadline')),
                                );
                                return;
                              }
                              setModalState(() { task['isEditing'] = false; });
                              Navigator.pop(context);
                            },
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(vertical: 12)),
                            child: const Text('Save Task'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _saveTasks(String projectId) async {
    print('=== SAVING TASKS ===');
    print('Number of tasks to save: ${_tasks.length}');
    
    if (_tasks.isEmpty) {
      print('No tasks to save');
      return;
    }
    
    int savedCount = 0;
    
    for (var task in _tasks) {
      final taskTitle = task['title']?.toString().trim() ?? '';
      
      if (taskTitle.isNotEmpty) {
        print('Saving task: "$taskTitle"');
        
        try {
          final newTask = Task(
            id: '',
            title: taskTitle,
            description: task['description']?.toString() ?? '',
            projectId: projectId,
            assignedTo: '',
            assignedBy: FirebaseAuth.instance.currentUser?.uid ?? '',
            deadline: task['deadline'] ?? DateTime.now().add(const Duration(days: 7)),
            difficultyLevel: task['difficulty'] ?? 1,
            difficultyReason: 'AI Analysis Complete',
            status: 'pending',
            progress: 0,
          );
          
          final docRef = await FirebaseFirestore.instance.collection('tasks').add(newTask.toMap());
          print('✅ Task saved with ID: ${docRef.id} (unassigned)');
          savedCount++;
        } catch (e) {
          print('❌ Error saving task "$taskTitle": $e');
        }
      } else {
        print('⚠️ Skipping task with empty title');
      }
    }
    
    print('=== TASKS SAVED: $savedCount/${_tasks.length} ===');
  }

  Widget _buildVisibilitySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Project Visibility", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                RadioListTile(
                  title: const Text("🌍 Open Project"),
                  subtitle: const Text("Visible to all faculty users"),
                  value: "open",
                  groupValue: _visibility,
                  onChanged: (value) => setState(() => _visibility = value!),
                  activeColor: Colors.green,
                  contentPadding: EdgeInsets.zero,
                ),
                RadioListTile(
                  title: const Text("🏢 Department Only"),
                  subtitle: const Text("Only visible to users in same department"),
                  value: "department",
                  groupValue: _visibility,
                  onChanged: (value) => setState(() => _visibility = value!),
                  activeColor: Colors.green,
                  contentPadding: EdgeInsets.zero,
                ),
                RadioListTile(
                  title: const Text("🔒 Restricted"),
                  subtitle: const Text("Only visible to assigned members/leaders"),
                  value: "restricted",
                  groupValue: _visibility,
                  onChanged: (value) => setState(() => _visibility = value!),
                  activeColor: Colors.green,
                  contentPadding: EdgeInsets.zero,
                ),
              ],
            ),
          ),
        ),
        
        if (_visibility == 'department') ...[
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _selectedDepartment,
            hint: const Text("Select Department *"),
            items: _departments.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
            onChanged: (value) => setState(() => _selectedDepartment = value),
            decoration: const InputDecoration(
              labelText: "Department",
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.business),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _selectedFaculty,
            hint: const Text("Select Faculty (Optional)"),
            items: _faculties.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
            onChanged: (value) => setState(() => _selectedFaculty = value),
            decoration: const InputDecoration(
              labelText: "Faculty (Optional)",
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.school),
              helperText: "Filter users by faculty when assigning team leader",
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildDateSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Project Timeline", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                InkWell(
                  onTap: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: _startDate ?? DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null) setState(() => _startDate = date);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade300))),
                    child: Row(
                      children: [
                        Icon(Icons.play_circle, color: Colors.green),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Start Date', style: TextStyle(fontSize: 12, color: Colors.grey)),
                              Text(
                                _startDate != null ? DateFormat('dd MMM yyyy').format(_startDate!) : 'Select start date',
                                style: TextStyle(fontSize: 14, fontWeight: _startDate != null ? FontWeight.bold : FontWeight.normal),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: _endDate ?? (_startDate ?? DateTime.now()),
                      firstDate: _startDate ?? DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 730)),
                    );
                    if (date != null) setState(() => _endDate = date);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                      children: [
                        Icon(Icons.stop_circle, color: Colors.red),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('End Date', style: TextStyle(fontSize: 12, color: Colors.grey)),
                              Text(
                                _endDate != null ? DateFormat('dd MMM yyyy').format(_endDate!) : 'Select end date',
                                style: TextStyle(fontSize: 14, fontWeight: _endDate != null ? FontWeight.bold : FontWeight.normal),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_startDate != null && _endDate != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(8)),
              child: Row(
                children: [
                  Icon(Icons.timer, size: 16, color: Colors.blue),
                  const SizedBox(width: 8),
                  Text('Duration: ${_endDate!.difference(_startDate!).inDays} days', style: TextStyle(fontSize: 12, color: Colors.blue.shade700)),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildProjectTypeInfoCard() {
    final estimatedWeeks = _selectedProjectTypeData?['estimatedWeeks'] ?? 4;
    final difficultyLevel = _selectedProjectTypeData?['difficultyLevel'] ?? 'Intermediate';
    final metrics = _selectedProjectTypeData?['metrics'] as Map<String, dynamic>? ?? {};
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        children: [
          const Text("📋 Project Type Details", style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.timer, size: 14, color: Colors.blue),
              const SizedBox(width: 4),
              Text("Duration: $estimatedWeeks weeks"),
              const SizedBox(width: 16),
              const Icon(Icons.trending_up, size: 14, color: Colors.blue),
              const SizedBox(width: 4),
              Text("Difficulty: $difficultyLevel"),
            ],
          ),
          if (metrics.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(
                spacing: 8,
                children: metrics.entries.map((entry) {
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                    child: Text('${entry.key}: ${entry.value}%', style: const TextStyle(fontSize: 10)),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatusDropdown() {
    return DropdownButtonFormField<String>(
      value: status,
      items: ["Pending", "Active", "Completed"].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
      onChanged: (value) => setState(() => status = value!),
      decoration: const InputDecoration(labelText: "Status", border: OutlineInputBorder(), prefixIcon: Icon(Icons.flag)),
    );
  }

  Widget _buildProgressSlider() {
    return Column(
      children: [
        Text("Progress: $progress%"),
        Slider(
          value: progress.toDouble(),
          min: 0,
          max: 100,
          divisions: 10,
          label: "$progress%",
          onChanged: (value) => setState(() => progress = value.toInt()),
        ),
      ],
    );
  }

  Widget _buildSustainabilitySection() {
    return Column(
      children: [
        const Text("Sustainability Metrics", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text("Rate each aspect from 0-100", style: TextStyle(color: Colors.grey, fontSize: 12)),
        const SizedBox(height: 16),
        _buildSlider("🌍 Environment", environment, (v) => setState(() => environment = v)),
        _buildSlider("⚡ Energy", energy, (v) => setState(() => energy = v)),
        _buildSlider("🗑️ Waste", waste, (v) => setState(() => waste = v)),
        _buildSlider("👥 Community", community, (v) => setState(() => community = v)),
        _buildSlider("💡 Innovation", innovation, (v) => setState(() => innovation = v)),
      ],
    );
  }

  Widget _buildAIScorePreview() {
    return Card(
      color: Colors.green.shade50,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const Icon(Icons.auto_awesome, color: Colors.green),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                children: [
                  const Text("AI Sustainability Score", style: TextStyle(fontWeight: FontWeight.bold)),
                  Text("Will be calculated automatically", style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(20)),
              child: Text(_calculatePreviewScore().toStringAsFixed(0), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTasksSection() {
    return Column(
      children: [
        Row(
          children: [
            const Icon(Icons.task, color: Colors.orange),
            const SizedBox(width: 8),
            const Text("Project Tasks", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Spacer(),
            TextButton.icon(
              onPressed: _addTask,
              icon: const Icon(Icons.add, size: 18),
              label: const Text('Add Task'),
              style: TextButton.styleFrom(foregroundColor: Colors.green),
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Text("Tasks will be assigned to team members by the Team Leader after project creation.", style: TextStyle(fontSize: 12, color: Colors.grey)),
        const SizedBox(height: 12),
        
        if (_tasks.isEmpty)
          Center(
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300, style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  const Icon(Icons.task_alt, size: 48, color: Colors.grey),
                  const SizedBox(height: 8),
                  Text('No tasks added yet', style: TextStyle(color: Colors.grey.shade600)),
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    onPressed: _addTask,
                    icon: const Icon(Icons.add),
                    label: const Text('Add First Task'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                  ),
                ],
              ),
            ),
          )
        else
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _tasks.length,
            itemBuilder: (context, index) {
              final task = _tasks[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AIDifficultyService.getDifficultyColor(task['difficulty'] ?? 1).withOpacity(0.1),
                    child: Icon(Icons.task, size: 20, color: AIDifficultyService.getDifficultyColor(task['difficulty'] ?? 1)),
                  ),
                  title: Text(task['title']?.isEmpty ?? true ? 'New Task' : task['title'], style: const TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (task['deadline'] != null) Text('Due: ${DateFormat('dd MMM yyyy').format(task['deadline'])}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(12)),
                        child: const Text('Not assigned yet', style: TextStyle(fontSize: 10, color: Colors.orange)),
                      ),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: AIDifficultyService.getDifficultyColor(task['difficulty'] ?? 1).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                        child: Text('Lvl ${task['difficulty']}', style: TextStyle(fontSize: 10, color: AIDifficultyService.getDifficultyColor(task['difficulty'] ?? 1), fontWeight: FontWeight.bold)),
                      ),
                      IconButton(icon: const Icon(Icons.edit, size: 18), onPressed: () => _showTaskDialog(index)),
                      IconButton(icon: const Icon(Icons.delete, size: 18, color: Colors.red), onPressed: () => _removeTask(index)),
                    ],
                  ),
                  onTap: () => _showTaskDialog(index),
                ),
              );
            },
          ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildSlider(String title, double value, Function(double) onChanged) {
    return Column(
      children: [
        Text("$title: ${value.toInt()}"),
        Slider(value: value, min: 0, max: 100, divisions: 10, onChanged: onChanged),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget _buildProjectTypeDropdown() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('project_types').where('isActive', isEqualTo: true).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();
        final types = snapshot.data!.docs;
        return DropdownButtonFormField<String>(
          value: projectTypeId,
          hint: const Text("Select Project Type *"),
          decoration: const InputDecoration(border: OutlineInputBorder(), prefixIcon: Icon(Icons.category)),
          items: types.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return DropdownMenuItem(
              value: doc.id,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data['name']),
                  if (data['description'] != null && data['description'].isNotEmpty)
                    Text(data['description'], style: const TextStyle(fontSize: 10, color: Colors.grey)),
                ],
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              projectTypeId = value;
              _selectedProjectTypeData = types.firstWhere((doc) => doc.id == value).data() as Map<String, dynamic>;
            });
          },
        );
      },
    );
  }

  Widget _buildCampusDropdown() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('campuses').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();
        return DropdownButtonFormField<String>(
          value: campusId,
          hint: const Text("Select Campus *"),
          decoration: const InputDecoration(border: OutlineInputBorder(), prefixIcon: Icon(Icons.school)),
          items: snapshot.data!.docs.map((doc) => DropdownMenuItem(value: doc.id, child: Text(doc['name']))).toList(),
          onChanged: (value) => setState(() => campusId = value),
        );
      },
    );
  }

  Widget _buildTeamLeaderDropdown() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').where('role', whereIn: ['lecturer', 'staff', 'admin']).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();
        var users = snapshot.data!.docs;
        
        if (_visibility == 'department' && _selectedDepartment != null && _selectedDepartment!.isNotEmpty) {
          users = users.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return data['department'] == _selectedDepartment;
          }).toList();
        }
        
        if (_selectedFaculty != null && _selectedFaculty!.isNotEmpty && _selectedFaculty != 'none') {
          users = users.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return data['faculty'] == _selectedFaculty;
          }).toList();
        }

        if (users.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(8)),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(Icons.warning, color: Colors.orange),
                    SizedBox(width: 8),
                    Expanded(child: Text('No users available in the selected department/faculty.', style: TextStyle(fontSize: 12))),
                  ],
                ),
                const SizedBox(height: 8),
                Text('Add users to this department/faculty first in User Management.', style: TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          );
        }

        return DropdownButtonFormField<String>(
          value: leaderId,
          hint: const Text("Select Team Leader *"),
          decoration: const InputDecoration(border: OutlineInputBorder(), prefixIcon: Icon(Icons.leaderboard), helperText: "This person will lead the project and assign tasks to members"),
          items: users.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return DropdownMenuItem<String>(
              value: doc.id,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data['name'] ?? 'Unknown', style: const TextStyle(fontWeight: FontWeight.w500)),
                  Text('${data['role'] ?? 'No role'} • ${data['department'] ?? 'No department'}', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                  if (_selectedFaculty != null && _selectedFaculty!.isNotEmpty)
                    Text('Faculty: ${data['faculty'] ?? 'No faculty'}', style: const TextStyle(fontSize: 9, color: Colors.blue)),
                ],
              ),
            );
          }).toList(),
          onChanged: (value) => setState(() => leaderId = value),
        );
      },
    );
  }

  Future<void> _saveProject(BuildContext context, dynamic service) async {
    print('=== STARTING SAVE PROJECT ===');
    print('Tasks count: ${_tasks.length}');
    
    if (_titleController.text.isEmpty) {
      _showError("Please enter project title");
      return;
    }
    if (projectTypeId == null) {
      _showError("Please select a project type");
      return;
    }
    if (campusId == null) {
      _showError("Please select a campus");
      return;
    }
    if (leaderId == null) {
      _showError("Please select a team leader");
      return;
    }
    
    if (_visibility == 'department' && _selectedDepartment == null) {
      _showError("Please select a department for department-restricted project");
      return;
    }

    setState(() => isSaving = true);

    double sustainabilityScore = _calculatePreviewScore();

    final scores = {
      "environment": environment,
      "energy": energy,
      "waste": waste,
      "community": community,
      "innovation": innovation,
    };

    try {
      final projectRef = await FirebaseFirestore.instance.collection('projects').add({
        'title': _titleController.text,
        'description': _descriptionController.text,
        'status': status,
        'progress': progress,
        'projectTypeId': projectTypeId,
        'campusId': campusId,
        'leaderId': leaderId,
        'members': [],
        'teamId': null,
        'visibility': _visibility,
        'department': _selectedDepartment,
        'faculty': _selectedFaculty,
        'startDate': _startDate != null ? Timestamp.fromDate(_startDate!) : null,
        'endDate': _endDate != null ? Timestamp.fromDate(_endDate!) : null,
        'scores': scores,
        'sustainabilityScore': sustainabilityScore,
        'createdAt': FieldValue.serverTimestamp(),
      });

      print('Project created with ID: ${projectRef.id}');

      final userDoc = await FirebaseFirestore.instance.collection('users').doc(leaderId).get();
      final leaderName = userDoc.data()?['name'] ?? 'Team Leader';

      await FirebaseFirestore.instance.collection('notifications').add({
        'userId': leaderId,
        'title': '🎯 Project Assigned to You',
        'message': 'You have been assigned as Team Leader for: ${_titleController.text}. An admin will assign a team to this project soon.',
        'type': 'success',
        'notificationType': 'project_assigned',
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'relatedId': projectRef.id,
      });

      final teamLeaderDoc = await FirebaseFirestore.instance.collection('users').doc(leaderId).get();

      if (teamLeaderDoc.exists) {
        final leaderData = teamLeaderDoc.data()!;
        await EmailService.sendProjectAssignmentEmail(
          toEmail: leaderData['email'] ?? '',
          toName: leaderData['name'] ?? 'Team Leader',
          projectTitle: _titleController.text,
          description: _descriptionController.text,
        );
      }

      if (_tasks.isNotEmpty) {
        print('Saving ${_tasks.length} tasks...');
        await _saveTasks(projectRef.id);
      } else {
        print('No tasks to save');
      }

      if (!mounted) return;

      String visibilityText = '';
      switch (_visibility) {
        case 'open': visibilityText = 'visible to all faculty users'; break;
        case 'department': visibilityText = 'only visible to $_selectedDepartment department users'; break;
        case 'restricted': visibilityText = 'restricted to assigned members only'; break;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ Project created successfully with ${_tasks.length} tasks! ($visibilityText)'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 3),
        ),
      );
      Navigator.pop(context);
    } catch (e) {
      print('Error saving project: $e');
      _showError('Error saving project: $e');
    } finally {
      if (mounted) setState(() => isSaving = false);
    }
  }

  double _calculatePreviewScore() {
    return (0.3 * environment) + (0.2 * energy) + (0.2 * waste) + (0.2 * community) + (0.1 * innovation);
  }

  String _formatDate(dynamic dateData) {
    if (dateData == null) return 'Not set';
    if (dateData is Timestamp) return DateFormat('dd MMM yyyy').format(dateData.toDate());
    return 'Invalid date';
  }

  @override
  Widget build(BuildContext context) {
    final service = ref.read(firebaseServiceProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Add New Project"),
        backgroundColor: Colors.green,
        actions: [
          IconButton(icon: const Icon(Icons.download), onPressed: _downloadExcelTemplate, tooltip: 'Download Excel Template'),
          IconButton(
            icon: _isUploadingExcel ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.upload_file),
            onPressed: _isUploadingExcel ? null : _uploadMultipleProjects,
            tooltip: 'Upload Multiple Projects (Excel)',
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(12),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: isSaving ? null : () => _saveProject(context, service),
          child: isSaving ? const CircularProgressIndicator(color: Colors.white) : const Text("Save Project", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              color: Colors.blue.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    const Row(children: [Icon(Icons.info_outline, color: Colors.blue), SizedBox(width: 8), Text('Bulk Upload', style: TextStyle(fontWeight: FontWeight.bold))]),
                    const SizedBox(height: 8),
                    const Text('Download the Excel template, fill in your project details, then upload to create multiple projects at once.', style: TextStyle(fontSize: 12)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        IconButton(icon: const Icon(Icons.download, size: 18), onPressed: _downloadExcelTemplate, tooltip: 'Download Template'),
                        const Text('Download Template'),
                        const Spacer(),
                        IconButton(
                          icon: _isUploadingExcel ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.upload_file, size: 18),
                          onPressed: _isUploadingExcel ? null : _uploadMultipleProjects,
                          tooltip: 'Upload Excel',
                        ),
                        const Text('Upload Excel'),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text("Project Information", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(controller: _titleController, decoration: const InputDecoration(labelText: "Project Title *", border: OutlineInputBorder(), prefixIcon: Icon(Icons.title))),
            const SizedBox(height: 16),
            TextField(controller: _descriptionController, decoration: const InputDecoration(labelText: "Description", border: OutlineInputBorder(), prefixIcon: Icon(Icons.description), hintText: "Describe the project goals and objectives..."), maxLines: 3),
            const SizedBox(height: 16),
            _buildProjectTypeDropdown(),
            const SizedBox(height: 16),
            if (_selectedProjectTypeData != null) _buildProjectTypeInfoCard(),
            const SizedBox(height: 16),
            _buildCampusDropdown(),
            const SizedBox(height: 16),
            _buildVisibilitySection(),
            const SizedBox(height: 16),
            _buildTeamLeaderDropdown(),
            const SizedBox(height: 16),
            _buildDateSection(),
            const SizedBox(height: 16),
            _buildStatusDropdown(),
            const SizedBox(height: 16),
            _buildProgressSlider(),
            const SizedBox(height: 16),
            _buildSustainabilitySection(),
            const SizedBox(height: 20),
            _buildAIScorePreview(),
            const SizedBox(height: 24),
            _buildTasksSection(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}