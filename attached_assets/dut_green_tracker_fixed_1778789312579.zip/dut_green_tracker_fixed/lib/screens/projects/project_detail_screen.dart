// ignore_for_file: prefer_const_constructors, unnecessary_null_comparison, unnecessary_to_list_in_spreads, curly_braces_in_flow_control_structures, deprecated_member_use, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/project.dart';
import '../../models/task.dart';
import '../../providers/project_provider.dart';
import '../progress/join_requests_screen.dart';
import '../tasks/task_evidence_screen.dart';
import '../../services/ai_difficulty_service.dart';
import '../dashboards/team_leader_dashboard.dart';
import '../../services/export_service.dart';
import '../chat/project_chat_screen.dart';
import '../team/manage_team_screen.dart';
import '../team/team_feed_screen.dart';
import 'package:intl/intl.dart';

class ProjectDetailScreen extends ConsumerStatefulWidget {
  final Project project;

  const ProjectDetailScreen({super.key, required this.project});

  @override
  ConsumerState<ProjectDetailScreen> createState() =>
      _ProjectDetailScreenState();
}

class _ProjectDetailScreenState extends ConsumerState<ProjectDetailScreen> {
  late TextEditingController _titleController;
  late String status;
  late int progress;
  bool _showTasks = true;
  
  String? _userDepartment;
  String? _userRole;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.project.title);
    status = widget.project.status;
    progress = widget.project.progress;
    _loadCurrentUser();
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  Future<void> _loadCurrentUser() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      if (userDoc.exists) {
        setState(() {
          _userDepartment = userDoc.data()?['department'];
          _userRole = userDoc.data()?['role'];
        });
      }
    }
  }

  String _normalizeStatus(String status) {
    if (status.isEmpty) return 'Pending';
    final lowerStatus = status.toLowerCase();
    if (lowerStatus == 'active') return 'Active';
    if (lowerStatus == 'pending') return 'Pending';
    if (lowerStatus == 'completed') return 'Completed';
    return status;
  }

  bool _isProjectCompleted() {
    return widget.project.status.toLowerCase() == 'completed';
  }
  
  // Helper methods for visibility
  String _getVisibilityLabel() {
    final visibility = widget.project.visibility;
    if (visibility == null || visibility.isEmpty) return 'Open';
    switch (visibility) {
      case 'open': return 'Open';
      case 'department': return 'Department';
      case 'restricted': return 'Restricted';
      default: return 'Open';
    }
  }
  
  IconData _getVisibilityIcon() {
    final visibility = widget.project.visibility;
    if (visibility == null || visibility.isEmpty) return Icons.public;
    switch (visibility) {
      case 'open': return Icons.public;
      case 'department': return Icons.business;
      case 'restricted': return Icons.lock;
      default: return Icons.visibility;
    }
  }
  
  Color _getVisibilityColor() {
    final visibility = widget.project.visibility;
    if (visibility == null || visibility.isEmpty) return Colors.green;
    switch (visibility) {
      case 'open': return Colors.green;
      case 'department': return Colors.orange;
      case 'restricted': return Colors.red;
      default: return Colors.grey;
    }
  }
  
// Add these helper methods to your _ProjectDetailScreenState class

String _formatDateValue(dynamic dateValue) {
  if (dateValue == null) return 'Not set';
  if (dateValue is Timestamp) {
    return DateFormat('dd MMM yyyy').format(dateValue.toDate());
  }
  return 'Invalid date';
}

int? _calculateDuration() {
  final startDate = widget.project.startDate;
  final endDate = widget.project.endDate;
  if (startDate != null && endDate != null) {
    final start = startDate is Timestamp ? startDate.toDate() : null;
    final end = endDate is Timestamp ? endDate.toDate() : null;
    if (start != null && end != null) {
      return end.difference(start).inDays;
    }
  }
  return null;
}
  
  bool _canUserSeeProject() {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid ?? '';
    final isLeader = widget.project.leaderId == currentUserId;
    final isMember = widget.project.members.contains(currentUserId);
    
    if (_userRole == 'admin') return true;
    if (isLeader || isMember) return true;
    
    final visibility = widget.project.visibility;
    if (visibility == null || visibility.isEmpty || visibility == 'open') return true;
    
    if (visibility == 'department') {
      return widget.project.department != null && 
             widget.project.department!.isNotEmpty &&
             widget.project.department == _userDepartment;
    }
    
    return false;
  }

  Future<void> sendJoinRequest() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    
    final visibility = widget.project.visibility;
    if (visibility == 'department') {
      if (widget.project.department != null && 
          widget.project.department!.isNotEmpty &&
          widget.project.department != _userDepartment) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('This project is restricted to specific department only'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
    }

    final existing = await FirebaseFirestore.instance
        .collection("join_requests")
        .where("projectId", isEqualTo: widget.project.id)
        .where("userId", isEqualTo: user.uid)
        .get();

    if (existing.docs.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Already requested")),
      );
      return;
    }

    await FirebaseFirestore.instance.collection("join_requests").add({
      "projectId": widget.project.id,
      "userId": user.uid,
      "status": "pending",
      "createdAt": Timestamp.now(),
    });

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Join request sent")),
    );
  }

  Future<void> _updateTaskProgress(String taskId, int newProgress) async {
    await FirebaseFirestore.instance.collection('tasks').doc(taskId).update({
      'progress': newProgress,
      'status': newProgress == 100 ? 'completed' : 'in_progress',
      if (newProgress == 100) 'completedAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(newProgress == 100 
              ? '✅ Task completed!' 
              : 'Progress updated to $newProgress%'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Future<void> _exportReport() async {
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(child: CircularProgressIndicator()),
      );
      
      final tasksSnapshot = await FirebaseFirestore.instance
          .collection('tasks')
          .where('projectId', isEqualTo: widget.project.id)
          .get();
      
      final tasks = tasksSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? '',
          'description': data['description'] ?? '',
          'difficulty': data['difficultyLevel'] ?? 1,
          'progress': data['progress'] ?? 0,
          'status': data['status'] ?? 'pending',
          'deadline': (data['deadline'] as Timestamp?)?.toDate(),
        };
      }).toList();
      
      final projectData = {
        'id': widget.project.id,
        'title': widget.project.title,
        'status': widget.project.status,
        'progress': widget.project.progress,
        'description': '',
        'scores': widget.project.scores,
        'sustainabilityScore': widget.project.sustainabilityScore,
        'startDate': widget.project.startDate,
        'endDate': widget.project.endDate,
        'createdAt': Timestamp.fromDate(DateTime.now()),
      };
      
      Navigator.pop(context);
      
      showModalBottomSheet(
        context: context,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (context) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Text('Export Report', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('Choose export format'),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
                title: const Text('Export as PDF'),
                onTap: () async {
                  Navigator.pop(context);
                  await ExportService.exportProjectToPDF(projectData, tasks);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('PDF report generated and shared!'), backgroundColor: Colors.green),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.table_chart, color: Colors.green),
                title: const Text('Export as Excel'),
                onTap: () async {
                  Navigator.pop(context);
                  await ExportService.exportProjectToExcel(projectData, tasks);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Excel report generated and shared!'), backgroundColor: Colors.green),
                  );
                },
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Export failed: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final service = ref.read(firebaseServiceProvider);
    final currentUserId = FirebaseAuth.instance.currentUser?.uid ?? '';
    final isLeader = widget.project.leaderId == currentUserId;
    final isMember = widget.project.members.contains(currentUserId);
    final isCompleted = _isProjectCompleted();
    final canSeeProject = _canUserSeeProject();
    
    if (!canSeeProject) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("Access Denied"),
          backgroundColor: Colors.red,
        ),
        body: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock, size: 64, color: Colors.red),
              SizedBox(height: 16),
              Text('You do not have permission to view this project.'),
              SizedBox(height: 8),
              Text('This project is restricted to specific department members.'),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Project Details"),
        backgroundColor: Colors.green,
        actions: [
          if (isLeader || isMember)
            IconButton(
              icon: const Icon(Icons.download),
              onPressed: _exportReport,
              tooltip: 'Export Report',
            ),
          if ((isLeader || isMember) && !isCompleted)
            IconButton(
              icon: const Icon(Icons.chat_bubble_outline),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProjectChatScreen(
                      projectId: widget.project.id,
                      projectTitle: widget.project.title,
                    ),
                  ),
                );
              },
              tooltip: 'Project Chat',
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Project Info Card
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _titleController,
                            decoration: const InputDecoration(
                              labelText: "Project Title",
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                            ),
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            enabled: isLeader && !isCompleted,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _getVisibilityColor().withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _getVisibilityColor()),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(_getVisibilityIcon(), size: 14, color: _getVisibilityColor()),
                              const SizedBox(width: 4),
                              Text(
                                _getVisibilityLabel(),
                                style: TextStyle(fontSize: 10, color: _getVisibilityColor()),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Divider(),
                    
                    DropdownButtonFormField<String>(
                      value: _normalizeStatus(status),
                      items: ["Pending", "Active", "Completed"]
                          .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                          .toList(),
                      onChanged: (isLeader && !isCompleted) 
                          ? (value) => setState(() {
                              if (value != null) {
                                status = value.toLowerCase();
                              }
                            }) 
                          : null,
                      decoration: const InputDecoration(labelText: "Status"),
                    ),
                    const SizedBox(height: 16),
                    
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Progress: $progress%"),
                        Slider(
                          value: progress.toDouble(),
                          min: 0,
                          max: 100,
                          divisions: 10,
                          label: "$progress%",
                          onChanged: (isLeader && !isCompleted)
                              ? (value) => setState(() => progress = value.toInt())
                              : null,
                        ),
                      ],
                    ),
                    
                    // Timeline Section (NEW - Fixed)
                    if (widget.project.startDate != null || widget.project.endDate != null)
                      Container(
                        margin: const EdgeInsets.only(top: 12),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              '📅 Project Timeline',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                            ),
                            const SizedBox(height: 8),
                            if (widget.project.startDate != null)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Row(
                                  children: [
                                    Icon(Icons.play_circle, size: 14, color: Colors.blue.shade700),
                                    const SizedBox(width: 8),
                                    Text(
                                      'Start: ${_formatDateValue(widget.project.startDate)}',
                                      style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                                    ),
                                  ],
                                ),
                              ),
                            if (widget.project.endDate != null)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Row(
                                  children: [
                                    Icon(Icons.stop_circle, size: 14, color: Colors.blue.shade700),
                                    const SizedBox(width: 8),
                                    Text(
                                      'End: ${_formatDateValue(widget.project.endDate)}',
                                      style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                                    ),
                                  ],
                                ),
                              ),
                            if (widget.project.startDate != null && widget.project.endDate != null)
                              Container(
                                margin: const EdgeInsets.only(top: 4),
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.timer, size: 12, color: Colors.green),
                                    const SizedBox(width: 6),
                                    Text(
                                      'Duration: ${_calculateDuration() ?? 0} days',
                                      style: TextStyle(fontSize: 11, color: Colors.green),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                    
                    // Department info for department projects
                    if (widget.project.visibility == 'department' && 
                        widget.project.department != null &&
                        widget.project.department!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.blue.shade50,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.business, size: 14, color: Colors.blue.shade700),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Department: ${widget.project.department}',
                                  style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Team Information Card (unchanged)
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Team Information",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    
                    const Text("Team Leader", style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Builder(
                      builder: (context) {
                        final leaderId = widget.project.leaderId;
                        if (leaderId == null || leaderId.isEmpty) {
                          return const Text("No leader assigned");
                        }
                        return StreamBuilder<DocumentSnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('users')
                              .doc(leaderId)
                              .snapshots(),
                          builder: (context, snapshot) {
                            if (!snapshot.hasData || snapshot.data!.data() == null) {
                              return const Text("Loading...");
                            }
                            final data = snapshot.data!.data() as Map<String, dynamic>;
                            return Row(
                              children: [
                                const Icon(Icons.person, size: 16, color: Colors.green),
                                const SizedBox(width: 8),
                                Text(data['name']?.toString() ?? "Unknown"),
                              ],
                            );
                          },
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    
                    const Text("Members", style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    ...widget.project.members
                        .where((id) => id.isNotEmpty && id != widget.project.leaderId)
                        .map((memberId) {
                      return StreamBuilder<DocumentSnapshot>(
                        stream: FirebaseFirestore.instance
                            .collection('users')
                            .doc(memberId)
                            .snapshots(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData || snapshot.data!.data() == null) {
                            return const ListTile(title: Text("Loading..."), dense: true);
                          }
                          final data = snapshot.data!.data() as Map<String, dynamic>;
                          return ListTile(
                            leading: const Icon(Icons.person, size: 16),
                            title: Text(data['name']?.toString() ?? "Unknown"),
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                          );
                        },
                      );
                    }).toList(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Tasks Card
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.task, color: Colors.orange),
                        const SizedBox(width: 8),
                        const Text(
                          "Project Tasks",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const Spacer(),
                        if (_showTasks)
                          IconButton(
                            icon: const Icon(Icons.expand_less),
                            onPressed: () => setState(() => _showTasks = false),
                          )
                        else
                          IconButton(
                            icon: const Icon(Icons.expand_more),
                            onPressed: () => setState(() => _showTasks = true),
                          ),
                      ],
                    ),
                    if (_showTasks)
                      _buildTasksList(currentUserId, isLeader, isMember, isCompleted),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            if (isCompleted)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
              color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.celebration, color: Colors.green, size: 28),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Project Completed! 🎉'),
                          Text('This project has been completed and is now read-only.'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            if (!isMember && !isLeader && !isCompleted)
              _buildJoinRequestSection(),
            
            if (isLeader && !isCompleted)
              _buildLeaderActions(service),
          ],
        ),
      ),
    );
  }

  Widget _buildTasksList(String currentUserId, bool isLeader, bool isMember, bool isProjectCompleted) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('tasks')
          .where('projectId', isEqualTo: widget.project.id)
          .orderBy('difficultyLevel', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              children: [
                const Icon(Icons.error_outline, size: 48, color: Colors.red),
                const SizedBox(height: 8),
                Text('Error: ${snapshot.error}'),
              ],
            ),
          );
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(20),
            child: const Center(
              child: Column(
                children: [
                  Icon(Icons.task_alt, size: 48, color: Colors.grey),
                  SizedBox(height: 8),
                  Text('No tasks created yet'),
                  SizedBox(height: 4),
                  Text(
                    'Tasks will appear here once added',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          );
        }

        final tasks = snapshot.data!.docs;
        
        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: tasks.length,
          itemBuilder: (context, index) {
            final taskDoc = tasks[index];
            final data = taskDoc.data() as Map<String, dynamic>;
            final task = Task.fromMap(data, taskDoc.id);
            final isAssignedToMe = task.assignedTo == currentUserId;
            final isUnassigned = task.assignedTo.isEmpty;
            final canEdit = (isLeader && !isProjectCompleted) || 
                            (isAssignedToMe && !isProjectCompleted);
            
            return _buildTaskCard(task, canEdit, isAssignedToMe, isUnassigned, isProjectCompleted);
          },
        );
      },
    );
  }

  Widget _buildTaskCard(Task task, bool canEdit, bool isAssignedToMe, bool isUnassigned, bool isProjectCompleted) {
    final difficultyColor = AIDifficultyService.getDifficultyColor(task.difficultyLevel);
    final isCompleted = task.progress == 100;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: isCompleted ? Colors.green : difficultyColor,
          width: 1,
        ),
      ),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: difficultyColor.withOpacity(0.1),
          child: Icon(
            isCompleted ? Icons.check_circle : Icons.task,
            color: isCompleted ? Colors.green : difficultyColor,
            size: 20,
          ),
        ),
        title: Text(
          task.title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            decoration: isCompleted ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Difficulty: ${task.difficultyLevel}/10',
              style: TextStyle(
                fontSize: 11,
                color: difficultyColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            LinearProgressIndicator(
              value: task.progress / 100,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation(difficultyColor),
              minHeight: 4,
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '${task.progress}%',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: difficultyColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'Lvl ${task.difficultyLevel}',
                style: TextStyle(
                  fontSize: 10,
                  color: difficultyColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (task.description.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(
                      task.description,
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                
                if (isUnassigned && !isCompleted)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.person_off, size: 14, color: Colors.orange),
                        SizedBox(width: 4),
                        Text('Not Assigned Yet', style: TextStyle(fontSize: 12, color: Colors.orange)),
                      ],
                    ),
                  )
                else if (!isCompleted)
                  FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance
                        .collection('users')
                        .doc(task.assignedTo)
                        .get(),
                    builder: (context, snapshot) {
                      final assignedName = snapshot.hasData && snapshot.data!.exists
                          ? (snapshot.data!.data() as Map)['name'] ?? 'Unknown'
                          : 'Loading...';
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            const Icon(Icons.person, size: 14, color: Colors.grey),
                            const SizedBox(width: 4),
                            Text(
                              'Assigned to: $assignedName',
                              style: const TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                
                Row(
                  children: [
                    const Icon(Icons.calendar_today, size: 14, color: Colors.grey),
                    const SizedBox(width: 4),
                    Text(
                      'Deadline: ${DateFormat('dd MMM yyyy').format(task.deadline)}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    if (task.deadline.isBefore(DateTime.now()) && !isCompleted)
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.red.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            'Overdue',
                            style: TextStyle(fontSize: 10, color: Colors.red),
                          ),
                        ),
                      ),
                  ],
                ),
                
                if (task.evidenceImages.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Evidence:',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          height: 80,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: task.evidenceImages.length,
                            itemBuilder: (context, idx) {
                              return GestureDetector(
                                onTap: () => _showImagePreview(task.evidenceImages[idx]),
                                child: Container(
                                  margin: const EdgeInsets.only(right: 8),
                                  width: 80,
                                  height: 80,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    image: DecorationImage(
                                      image: NetworkImage(task.evidenceImages[idx]),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        if (task.evidenceNotes != null && task.evidenceNotes!.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade50,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                '📝 ${task.evidenceNotes}',
                                style: const TextStyle(fontSize: 12),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                
                const SizedBox(height: 16),
                
                if (canEdit && !isCompleted)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Update Progress:',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: Slider(
                              value: task.progress.toDouble(),
                              min: 0,
                              max: 100,
                              divisions: 10,
                              label: '${task.progress}%',
                              onChanged: (value) => _updateTaskProgress(task.id, value.toInt()),
                            ),
                          ),
                          Text('${task.progress}%'),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (isAssignedToMe && !isProjectCompleted)
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TaskEvidenceScreen(task: task),
                                ),
                              );
                            },
                            icon: const Icon(Icons.upload_file),
                            label: const Text('Upload Evidence'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                            ),
                          ),
                        ),
                    ],
                  ),
                
                if (isProjectCompleted && !isCompleted)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'Project completed - task locked',
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                
                if (isCompleted)
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.check_circle, color: Colors.green, size: 16),
                        SizedBox(width: 8),
                        Text('Task Completed!', style: TextStyle(color: Colors.green)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildJoinRequestSection() {
    final visibility = widget.project.visibility;
    
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection("join_requests")
          .where("projectId", isEqualTo: widget.project.id)
          .where("userId", isEqualTo: FirebaseAuth.instance.currentUser?.uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const SizedBox();
        }

        final requests = snapshot.data!.docs;

        if (requests.isNotEmpty) {
          final data = requests.first.data() as Map<String, dynamic>;
          final requestStatus = data['status'];

          if (requestStatus == "pending") {
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.pending, color: Colors.orange),
                  SizedBox(width: 8),
                  Text("Request Pending...", style: TextStyle(color: Colors.orange)),
                ],
              ),
            );
          }
          if (requestStatus == "rejected") {
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.cancel, color: Colors.red),
                  SizedBox(width: 8),
                  Text("Request Rejected", style: TextStyle(color: Colors.red)),
                ],
              ),
            );
          }
          if (requestStatus == "approved") {
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.green),
                  SizedBox(width: 8),
                  Text("You are now a member ✅", style: TextStyle(color: Colors.green)),
                ],
              ),
            );
          }
        }

        if (visibility == 'department' && widget.project.department != null && widget.project.department!.isNotEmpty) {
          return Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              children: [
                const Icon(Icons.business, size: 24, color: Colors.blue),
                const SizedBox(height: 8),
                Text(
                  'This project is restricted to ${widget.project.department} department.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  icon: const Icon(Icons.group_add),
                  label: const Text("Request to Join"),
                  onPressed: sendJoinRequest,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          );
        }

        return ElevatedButton.icon(
          icon: const Icon(Icons.group_add),
          label: const Text("Request to Join"),
          onPressed: sendJoinRequest,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
          ),
        );
      },
    );
  }

  Widget _buildLeaderActions(dynamic service) {
    return Column(
      children: [
        ElevatedButton.icon(
          icon: const Icon(Icons.group),
          label: const Text("Manage Team"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageTeamScreen(
                  projectId: widget.project.id,
                  projectTitle: widget.project.title,
                ),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.purple,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
        const SizedBox(height: 10),
        
        ElevatedButton.icon(
          icon: const Icon(Icons.rss_feed),
          label: const Text("Team Feed"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TeamFeedScreen(
                  projectId: widget.project.id,
                  projectTitle: widget.project.title,
                ),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
        const SizedBox(height: 10),
        
        ElevatedButton.icon(
          icon: const Icon(Icons.assignment_add),
          label: const Text("Assign Tasks"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const TeamLeaderDashboard(),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
        const SizedBox(height: 10),
        
        ElevatedButton.icon(
          icon: const Icon(Icons.people),
          label: const Text("View Join Requests"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => JoinRequestsScreen(
                  projectId: widget.project.id,
                ),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
        const SizedBox(height: 10),
        
        ElevatedButton.icon(
          icon: const Icon(Icons.save),
          label: const Text("Update Project"),
          onPressed: () async {
            await service.updateProject(
              Project(
                id: widget.project.id,
                title: _titleController.text,
                status: status,
                progress: progress,
                projectTypeId: widget.project.projectTypeId,
                campusId: widget.project.campusId,
                leaderId: widget.project.leaderId,
                members: widget.project.members,
                scores: widget.project.scores,
                sustainabilityScore: widget.project.sustainabilityScore,
              ),
            );
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Project updated successfully!')),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
        const SizedBox(height: 10),
        
        ElevatedButton.icon(
          icon: const Icon(Icons.delete),
          label: const Text("Delete Project"),
          onPressed: () async {
            final confirm = await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Delete Project'),
                content: const Text('Are you sure you want to delete this project? This will also delete all tasks and evidence.'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: TextButton.styleFrom(foregroundColor: Colors.red),
                    child: const Text('Delete'),
                  ),
                ],
              ),
            );
            if (confirm == true) {
              final tasks = await FirebaseFirestore.instance
                  .collection('tasks')
                  .where('projectId', isEqualTo: widget.project.id)
                  .get();
              
              for (var task in tasks.docs) {
                await task.reference.delete();
              }
              
              await service.deleteProject(widget.project.id);
              if (!mounted) return;
              Navigator.pop(context);
            }
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ],
    );
  }

  void _showImagePreview(String imageUrl) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.network(imageUrl),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }
}