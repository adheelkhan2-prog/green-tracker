// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../providers/project_provider.dart';
import 'project_detail_screen.dart';
import 'add_project_screen.dart';
import '../progress/project_chat_screen.dart'; // Create this file

class ProjectListScreen extends ConsumerWidget {
  const ProjectListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final projectsAsync = ref.watch(projectStreamProvider);
    final currentUser = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Projects"),
        backgroundColor: Colors.green,
        actions: [
          // Filter button
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(context),
            tooltip: 'Filter Projects',
          ),
          // Refresh button
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              ref.invalidate(projectStreamProvider);
            },
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: projectsAsync.when(
        data: (projects) {
          if (projects.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.folder_open, size: 64, color: Colors.grey.shade400),
                  const SizedBox(height: 16),
                  Text(
                    'No projects yet',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap + to create your first project',
                    style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: projects.length,
            itemBuilder: (context, index) {
              final project = projects[index];

              // Status Color
              Color statusColor;
              String statusIcon;
              if (project.status == "Active") {
                statusColor = Colors.orange;
                statusIcon = "🟠";
              } else if (project.status == "Completed") {
                statusColor = Colors.green;
                statusIcon = "✅";
              } else {
                statusColor = Colors.grey;
                statusIcon = "⏳";
              }

              return StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('project_types')
                    .doc(project.projectTypeId)
                    .snapshots(),
                builder: (context, snapshot) {
                  String typeName = "Loading...";
                  Color typeColor = Colors.green;
                  
                  if (snapshot.hasData && snapshot.data!.exists) {
                    final typeData = snapshot.data!.data() as Map<String, dynamic>;
                    typeName = typeData['name'] ?? 'Unknown';
                    if (typeData['color'] != null) {
                      typeColor = Color(typeData['color']);
                    }
                  }

                  // Check if user is a member of this project
                  final isMember = project.members.contains(currentUser?.uid) || 
                                   project.leaderId == currentUser?.uid;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProjectDetailScreen(project: project),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Header row with title and status
                            Row(
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: typeColor.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Center(
                                    child: Text(
                                      project.title.isNotEmpty 
                                          ? project.title[0].toUpperCase() 
                                          : '📋',
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: typeColor,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        project.title,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Text(
                                            '$statusIcon ${project.status}',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: statusColor,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 6,
                                              vertical: 2,
                                            ),
                                            decoration: BoxDecoration(
                                              color: typeColor.withOpacity(0.1),
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Text(
                                              typeName,
                                              style: TextStyle(
                                                fontSize: 10,
                                                color: typeColor,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            
                            // Progress section
                            Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text(
                                            'Progress',
                                            style: TextStyle(fontSize: 12, color: Colors.grey),
                                          ),
                                          Text(
                                            '${project.progress}%',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(4),
                                        child: LinearProgressIndicator(
                                          value: project.progress / 100,
                                          backgroundColor: Colors.grey.shade200,
                                          valueColor: AlwaysStoppedAnimation(statusColor),
                                          minHeight: 6,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            
                            // Action buttons row
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                // Chat button (only for members)
                                if (isMember)
                                  _buildActionButton(
                                    icon: Icons.chat_bubble_outline,
                                    label: 'Chat',
                                    color: Colors.green,
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => ProjectChatScreen(
                                            projectId: project.id,
                                            projectTitle: project.title,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                
                                // View Details button
                                _buildActionButton(
                                  icon: Icons.visibility,
                                  label: 'Details',
                                  color: Colors.blue,
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => ProjectDetailScreen(project: project),
                                      ),
                                    );
                                  },
                                ),
                                
                                // Team button (shows team members)
                                _buildActionButton(
                                  icon: Icons.people,
                                  label: 'Team',
                                  color: Colors.purple,
                                  onTap: () => _showTeamMembers(context, project),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
        loading: () => const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Loading projects...'),
            ],
          ),
        ),
        error: (e, _) => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 64, color: Colors.red.shade400),
              const SizedBox(height: 16),
              Text('Error loading projects: $e'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => ref.invalidate(projectStreamProvider),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF00A86B),
        icon: const Icon(Icons.add),
        label: const Text("Add Project"),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AddProjectScreen(),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(fontSize: 12, color: color),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showTeamMembers(BuildContext context, dynamic project) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.5,
        minChildSize: 0.3,
        maxChildSize: 0.8,
        expand: false,
        builder: (context, scrollController) => FutureBuilder<List<Map<String, dynamic>>>(
          future: _getTeamMembers(project.members, project.leaderId),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            
            final members = snapshot.data!;
            final leaderId = project.leaderId;
            
            return Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'Team Members',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${members.length} member${members.length > 1 ? 's' : ''}',
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    controller: scrollController,
                    itemCount: members.length,
                    itemBuilder: (context, index) {
                      final member = members[index];
                      final isLeader = member['id'] == leaderId;
                      
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.green.shade100,
                          child: Text(
                            (member['name']?.substring(0, 1) ?? 'U').toUpperCase(),
                            style: const TextStyle(color: Colors.green),
                          ),
                        ),
                        title: Text(member['name'] ?? 'Unknown'),
                        subtitle: Text(member['role'] ?? 'Member'),
                        trailing: isLeader
                            ? const Chip(
                                label: Text('Leader'),
                                backgroundColor: Colors.green,
                                labelStyle: TextStyle(color: Colors.white, fontSize: 11),
                              )
                            : null,
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _getTeamMembers(List<String> memberIds, String? leaderId) async {
    final members = <Map<String, dynamic>>[];
    
    for (String id in memberIds) {
      final doc = await FirebaseFirestore.instance.collection('users').doc(id).get();
      if (doc.exists) {
        members.add({
          'id': id,
          'name': doc.data()?['name'] ?? 'Unknown',
          'role': doc.data()?['role'] ?? 'Member',
        });
      }
    }
    
    // Sort: leader first, then alphabetically
    members.sort((a, b) {
      if (a['id'] == leaderId) return -1;
      if (b['id'] == leaderId) return 1;
      return (a['name'] ?? '').compareTo(b['name'] ?? '');
    });
    
    return members;
  }

  void _showFilterDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Filter Projects'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              leading: Icon(Icons.all_inclusive),
              title: Text('All Projects'),
            ),
            const ListTile(
              leading: Icon(Icons.play_circle),
              title: Text('Active Only'),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle),
              title: Text('Completed Only'),
            ),
            const Divider(),
            const ListTile(
              leading: Icon(Icons.person),
              title: Text('My Projects'),
              subtitle: Text('Projects you are part of'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text('Apply'),
          ),
        ],
      ),
    );
  }
}