// ignore_for_file: deprecated_member_use, unnecessary_brace_in_string_interps, use_build_context_synchronously, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/ai_difficulty_service.dart';
import '../../models/task.dart';
import '../../services/unified_notification_service.dart';
import '../../services/ai_team_matching.dart';
import 'package:intl/intl.dart';

class AssignTasksScreen extends StatefulWidget {
  final String? projectId;
  const AssignTasksScreen({super.key, this.projectId});

  @override
  State<AssignTasksScreen> createState() => _AssignTasksScreenState();
}

class _AssignTasksScreenState extends State<AssignTasksScreen> {
  String? _selectedProjectId;
  String? _selectedMemberId;
  List<Map<String, dynamic>> _myProjects = [];
  List<Map<String, dynamic>> _projectMembers = [];
  List<Map<String, dynamic>> _availableTasks = [];
  bool _isLoading = true;
  bool _isCalculating = false;
  bool _isAssigning = false;
  int _calculatedDifficulty = 1;
  String _difficultyReason = '';
  String? _teamLeaderName;
  String? _errorMessage;
  
  // Smart matching
  TeamMatchResult? _smartMatchResult;
  bool _isMatching = false;

  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  DateTime? _selectedDeadline;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) {
      setState(() {
        _errorMessage = 'Please login first';
        _isLoading = false;
      });
      return;
    }

    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      _teamLeaderName = userDoc.data()?['name'] ?? 'Team Leader';

      // Get projects where user is team leader
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .where('leaderId', isEqualTo: currentUser.uid)
          .get();

      print('Projects found: ${projectsSnapshot.docs.length}');

      if (projectsSnapshot.docs.isEmpty) {
        setState(() {
          _errorMessage = 'You are not assigned as a Team Leader for any project.';
          _isLoading = false;
        });
        return;
      }

      final projects = projectsSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Untitled',
          'progress': data['progress'] ?? 0,
          'status': data['status'] ?? 'active',
          'members': List<String>.from(data['members'] ?? []),
        };
      }).toList();
      
      setState(() {
        _myProjects = projects;
      });
      
      if (widget.projectId != null && _myProjects.any((p) => p['id'] == widget.projectId)) {
        _selectedProjectId = widget.projectId;
        await _loadProjectMembers(_selectedProjectId!);
        await _loadUnassignedTasks(_selectedProjectId!);
      } else if (_myProjects.isNotEmpty) {
        _selectedProjectId = _myProjects.first['id'];
        await _loadProjectMembers(_selectedProjectId!);
        await _loadUnassignedTasks(_selectedProjectId!);
      }
      
      setState(() => _isLoading = false);
    } catch (e) {
      print('Error loading data: $e');
      setState(() {
        _errorMessage = 'Error loading data: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadProjectMembers(String projectId) async {
    final project = _myProjects.firstWhere((p) => p['id'] == projectId);
    final memberIds = List<String>.from(project['members']);
    
    final members = <Map<String, dynamic>>[];
    
    for (String memberId in memberIds) {
      try {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(memberId)
            .get();
        
        if (doc.exists) {
          members.add({
            'id': memberId,
            'name': doc.data()?['name'] ?? 'Unknown',
            'email': doc.data()?['email'] ?? '',
            'role': doc.data()?['role'] ?? 'member',
          });
        }
      } catch (e) {
        print('Error loading member $memberId: $e');
      }
    }
    
    members.sort((a, b) => (a['name'] ?? '').compareTo(b['name'] ?? ''));
    
    setState(() {
      _projectMembers = members;
    });
  }

  Future<void> _loadUnassignedTasks(String projectId) async {
    try {
      final tasksSnapshot = await FirebaseFirestore.instance
          .collection('tasks')
          .where('projectId', isEqualTo: projectId)
          .get();
      
      final unassignedTasks = tasksSnapshot.docs.where((doc) {
        final data = doc.data();
        final assignedTo = data['assignedTo'] ?? '';
        return assignedTo.isEmpty;
      }).toList();
      
      setState(() {
        _availableTasks = unassignedTasks.map((doc) {
          final data = doc.data();
          return {
            'id': doc.id,
            'title': data['title'] ?? '',
            'description': data['description'] ?? '',
            'deadline': (data['deadline'] as Timestamp?)?.toDate(),
            'difficulty': data['difficultyLevel'] ?? 1,
          };
        }).toList();
      });
      
      print('Unassigned tasks found: ${_availableTasks.length}');
    } catch (e) {
      print('Error loading tasks: $e');
      setState(() {
        _availableTasks = [];
      });
    }
  }

  // Get smart matching recommendations
  Future<void> _getSmartMatchRecommendation() async {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project first'), backgroundColor: Colors.orange),
      );
      return;
    }
    
    if (_titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter task title first'), backgroundColor: Colors.orange),
      );
      return;
    }
    
    setState(() {
      _isMatching = true;
      _smartMatchResult = null;
    });
    
    try {
      final result = await smartTeamMatching.getSmartTeamMatch(
        projectId: _selectedProjectId!,
        taskTitle: _titleController.text,
        taskDescription: _descriptionController.text,
        difficultyLevel: _calculatedDifficulty,
      );
      
      setState(() {
        _smartMatchResult = result;
        _isMatching = false;
      });
      
      // Auto-select the best match if confidence is high
      if (result.topMatches.isNotEmpty && result.topMatches.first.score >= 85) {
        _selectedMemberId = result.topMatches.first.userId;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🤖 AI recommended: ${result.topMatches.first.userName} (${result.topMatches.first.score.toInt()}% match)'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error getting recommendations: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _isMatching = false);
    }
  }

  Future<void> _createAndAssignTask() async {
    if (_selectedProjectId == null) {
      _showError('Please select a project');
      return;
    }
    if (_selectedMemberId == null) {
      _showError('Please select a team member (or use AI recommendation)');
      return;
    }
    if (_titleController.text.trim().isEmpty) {
      _showError('Please enter task title');
      return;
    }
    if (_selectedDeadline == null) {
      _showError('Please select a deadline');
      return;
    }

    setState(() => _isAssigning = true);

    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      final selectedMember = _projectMembers.firstWhere((m) => m['id'] == _selectedMemberId);
      final projectTitle = _myProjects.firstWhere((p) => p['id'] == _selectedProjectId)['title'];
      
      final task = Task(
        id: '',
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        projectId: _selectedProjectId!,
        assignedTo: _selectedMemberId!,
        assignedBy: currentUser!.uid,
        deadline: _selectedDeadline!,
        difficultyLevel: _calculatedDifficulty,
        difficultyReason: _difficultyReason,
      );

      final taskDoc = await FirebaseFirestore.instance.collection('tasks').add(task.toMap());
      print('Task created with ID: ${taskDoc.id}');
      
      // Use Unified Notification Service - sends both in-app and email
      await UnifiedNotificationService.sendNotification(
        userId: _selectedMemberId!,
        title: 'New Task Assigned 📋',
        message: '${_teamLeaderName} assigned you: ${task.title} (Difficulty: ${_calculatedDifficulty}/10)',
        type: 'info',
        notificationType: 'task_assigned',
        relatedId: taskDoc.id,
        sendEmail: true,
        emailData: {
          'taskTitle': task.title,
          'projectTitle': projectTitle,
          'deadline': DateFormat('dd MMM yyyy').format(_selectedDeadline!),
          'difficulty': _calculatedDifficulty.toString(),
        },
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Task created and assigned successfully! Email notification sent.'), backgroundColor: Colors.green),
        );
        
        _titleController.clear();
        _descriptionController.clear();
        setState(() {
          _selectedMemberId = null;
          _selectedDeadline = null;
          _calculatedDifficulty = 1;
          _smartMatchResult = null;
        });
        
        await _loadUnassignedTasks(_selectedProjectId!);
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      if (mounted) setState(() => _isAssigning = false);
    }
  }

  Future<void> _assignExistingTask(String taskId, String memberId) async {
    setState(() => _isAssigning = true);

    try {
      final selectedMember = _projectMembers.firstWhere((m) => m['id'] == memberId);
      final task = _availableTasks.firstWhere((t) => t['id'] == taskId);
      final projectTitle = _myProjects.firstWhere((p) => p['id'] == _selectedProjectId)['title'];
      
      await FirebaseFirestore.instance
          .collection('tasks')
          .doc(taskId)
          .update({
        'assignedTo': memberId,
        'status': 'pending',
      });
      
      // Use Unified Notification Service - sends both in-app and email
      await UnifiedNotificationService.sendNotification(
        userId: memberId,
        title: 'New Task Assigned 📋',
        message: '${_teamLeaderName} assigned you: ${task['title']} (Difficulty: ${task['difficulty']}/10)',
        type: 'info',
        notificationType: 'task_assigned',
        relatedId: taskId,
        sendEmail: true,
        emailData: {
          'taskTitle': task['title'],
          'projectTitle': projectTitle,
          'deadline': task['deadline'] != null 
              ? DateFormat('dd MMM yyyy').format(task['deadline'])
              : 'Not specified',
          'difficulty': task['difficulty'].toString(),
        },
      );

      await _loadUnassignedTasks(_selectedProjectId!);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Task assigned successfully! Email notification sent.'), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      if (mounted) setState(() => _isAssigning = false);
    }
  }

  Future<void> _calculateDifficulty() async {
    if (_titleController.text.isEmpty) return;
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project first'), backgroundColor: Colors.orange),
      );
      return;
    }

    setState(() => _isCalculating = true);

    final difficulty = await AIDifficultyService.calculateDifficulty(
      title: _titleController.text,
      description: _descriptionController.text,
      deadline: _selectedDeadline ?? DateTime.now().add(const Duration(days: 7)),
      projectId: _selectedProjectId!,
    );

    setState(() {
      _calculatedDifficulty = difficulty;
      _difficultyReason = 'AI Analysis Complete';
      _isCalculating = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('AI Difficulty: ${AIDifficultyService.getDifficultyLabel(difficulty)} (Level $difficulty/10)'),
        backgroundColor: AIDifficultyService.getDifficultyColor(difficulty),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assign Tasks to Members'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, size: 64, color: Colors.red),
                      const SizedBox(height: 16),
                      Text(_errorMessage!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadData,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : _myProjects.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.assignment_late, size: 64, color: Colors.grey),
                          const SizedBox(height: 16),
                          const Text('No projects assigned to you', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          Text('You are not assigned as a Team Leader for any project.', style: TextStyle(color: Colors.grey.shade600)),
                        ],
                      ),
                    )
                  : DefaultTabController(
                      length: 2,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: DropdownButtonFormField<String>(
                              value: _selectedProjectId,
                              hint: const Text('Select Project'),
                              isExpanded: true,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.folder),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              items: _myProjects.map<DropdownMenuItem<String>>((project) {
                                return DropdownMenuItem<String>(
                                  value: project['id'].toString(),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(project['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w500)),
                                      Text('Status: ${project['status']} | Progress: ${project['progress']}%', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                                    ],
                                  ),
                                );
                              }).toList(),
                              onChanged: (value) async {
                                setState(() {
                                  _selectedProjectId = value;
                                  _selectedMemberId = null;
                                  _projectMembers = [];
                                  _availableTasks = [];
                                  _smartMatchResult = null;
                                });
                                if (value != null) {
                                  await _loadProjectMembers(value);
                                  await _loadUnassignedTasks(value);
                                }
                              },
                            ),
                          ),
                          
                          const TabBar(
                            tabs: [
                              Tab(text: 'Create New Task', icon: Icon(Icons.add_task)),
                              Tab(text: 'Assign Existing Tasks', icon: Icon(Icons.list_alt)),
                            ],
                          ),
                          
                          Expanded(
                            child: TabBarView(
                              children: [
                                _buildCreateTaskTab(),
                                _buildAssignExistingTasksTab(),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
    );
  }

  Widget _buildCreateTaskTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // AI Smart Match Button
          Card(
            color: Colors.purple.shade50,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  const Icon(Icons.auto_awesome, color: Colors.purple),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'AI Smart Team Matching',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                        ),
                        Text(
                          'Get AI-powered recommendations for best team member',
                          style: TextStyle(fontSize: 11, color: Colors.purple.shade700),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _isMatching ? null : _getSmartMatchRecommendation,
                    icon: _isMatching
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.psychology, size: 16),
                    label: Text(_isMatching ? 'Analyzing...' : 'Get Match'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Smart Match Result Card
          if (_smartMatchResult != null)
            Card(
              margin: const EdgeInsets.only(top: 12),
              color: Colors.blue.shade50,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.auto_awesome, color: Colors.blue, size: 18),
                        SizedBox(width: 8),
                        Text('AI Recommendation', style: TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(_smartMatchResult!.summary),
                    const SizedBox(height: 8),
                    if (_smartMatchResult!.topMatches.isNotEmpty) ...[
                      const Divider(),
                      const Text('Top Matches:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      const SizedBox(height: 4),
                      ..._smartMatchResult!.topMatches.map((match) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  color: _getScoreColor(match.score).withOpacity(0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: Text(
                                    '${match.score.toInt()}%',
                                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _getScoreColor(match.score)),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(match.userName, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                                    Text(
                                      '${match.completedTasks} done • ${match.currentTasks} active',
                                      style: const TextStyle(fontSize: 10, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ),
                              if (match.userId == _selectedMemberId)
                                const Icon(Icons.check_circle, color: Colors.green, size: 16),
                            ],
                          ),
                        );
                      }),
                    ],
                  ],
                ),
              ),
            ),
          
          const SizedBox(height: 16),
          
          Card(
            color: Colors.blue.shade50,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  const Icon(Icons.auto_awesome, color: Colors.blue),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text('AI will analyze task difficulty based on title, description, and deadline', style: TextStyle(color: Colors.blue.shade700, fontSize: 12)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          const Text('Assign To', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          if (_projectMembers.isEmpty && _selectedProjectId != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(8)),
              child: const Row(
                children: [
                  Icon(Icons.warning, color: Colors.orange),
                  SizedBox(width: 8),
                  Expanded(child: Text('No members added to this project yet. Add members from the Project Details page.', style: TextStyle(fontSize: 12))),
                ],
              ),
            )
          else
            DropdownButtonFormField<String>(
              value: _selectedMemberId,
              hint: const Text('Select team member'),
              isExpanded: true,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              items: [
                const DropdownMenuItem<String>(value: null, child: Text('-- Select a team member --')),
                ..._projectMembers.map<DropdownMenuItem<String>>((member) {
                  return DropdownMenuItem<String>(
                    value: member['id'].toString(),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: Colors.green.shade100,
                          child: Text((member['name']?.toString().substring(0, 1) ?? 'U'), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(member['name']?.toString() ?? 'Unknown', style: const TextStyle(fontWeight: FontWeight.w500)),
                              Text(member['role']?.toString() ?? 'Member', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ],
              onChanged: (value) => setState(() => _selectedMemberId = value),
            ),
          const SizedBox(height: 20),

          const Text('Task Details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(hintText: 'Enter task title', border: OutlineInputBorder(), prefixIcon: Icon(Icons.title)),
            onChanged: (_) => _calculateDifficulty(),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _descriptionController,
            decoration: const InputDecoration(hintText: 'Task description (optional)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.description)),
            maxLines: 3,
            onChanged: (_) => _calculateDifficulty(),
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: Text(_selectedDeadline == null ? 'Select Deadline *' : 'Deadline: ${_formatDate(_selectedDeadline!)}'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () async {
              final date = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
              );
              if (date != null) {
                setState(() => _selectedDeadline = date);
                await _calculateDifficulty();
              }
            },
          ),
          const SizedBox(height: 20),
          Card(
            elevation: 4,
            color: AIDifficultyService.getDifficultyColor(_calculatedDifficulty).withOpacity(0.1),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.auto_awesome, color: AIDifficultyService.getDifficultyColor(_calculatedDifficulty)),
                      const SizedBox(width: 8),
                      const Text('AI Difficulty Analysis', style: TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      if (_isCalculating) const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(AIDifficultyService.getDifficultyLabel(_calculatedDifficulty), style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AIDifficultyService.getDifficultyColor(_calculatedDifficulty))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: AIDifficultyService.getDifficultyColor(_calculatedDifficulty), borderRadius: BorderRadius.circular(20)),
                        child: Text('Level $_calculatedDifficulty/10', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: _calculatedDifficulty / 10,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation(AIDifficultyService.getDifficultyColor(_calculatedDifficulty)),
                    minHeight: 6,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  const SizedBox(height: 8),
                  Text('Estimated hours: ${AIDifficultyService.getEstimatedHours(_calculatedDifficulty)} hrs', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 55,
            child: ElevatedButton(
              onPressed: (_isAssigning || _selectedProjectId == null || _selectedMemberId == null || _projectMembers.isEmpty) ? null : _createAndAssignTask,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 3),
              child: _isAssigning
                  ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('Create & Assign Task', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAssignExistingTasksTab() {
    if (_availableTasks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.task_alt, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text('No unassigned tasks', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('All tasks have been assigned or no tasks created yet.\nCreate new tasks in the "Create New Task" tab.', style: TextStyle(color: Colors.grey.shade600), textAlign: TextAlign.center),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _availableTasks.length,
      itemBuilder: (context, index) {
        final task = _availableTasks[index];
        final difficultyColor = AIDifficultyService.getDifficultyColor(task['difficulty']);
        
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ExpansionTile(
            leading: CircleAvatar(backgroundColor: difficultyColor.withOpacity(0.1), child: Icon(Icons.task, color: difficultyColor)),
            title: Text(task['title'], style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Difficulty: ${task['difficulty']}/10', style: TextStyle(fontSize: 12, color: difficultyColor)),
                if (task['deadline'] != null) Text('Deadline: ${_formatDate(task['deadline'])}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (task['description'].isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(task['description'])),
                    const Text('Assign to:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    if (_projectMembers.isEmpty)
                      const Text('No members available. Add members to this project first.')
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _projectMembers.map((member) {
                          return ElevatedButton(
                            onPressed: () => _assignExistingTask(task['id'], member['id']),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade50, foregroundColor: Colors.green),
                            child: Text(member['name']),
                          );
                        }).toList(),
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 85) return Colors.green;
    if (score >= 70) return Colors.blue;
    if (score >= 50) return Colors.orange;
    return Colors.red;
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }
}