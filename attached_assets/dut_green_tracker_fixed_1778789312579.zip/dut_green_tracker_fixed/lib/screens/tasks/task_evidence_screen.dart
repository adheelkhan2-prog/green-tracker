// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_interpolation_to_compose_strings, deprecated_member_use, prefer_const_constructors, use_build_context_synchronously, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import '../../models/task.dart' as models;
import '../../services/ai_photo_analysis.dart';

class TaskEvidenceScreen extends StatefulWidget {
  final models.Task task;

  const TaskEvidenceScreen({super.key, required this.task});

  @override
  State<TaskEvidenceScreen> createState() => _TaskEvidenceScreenState();
}

class _TaskEvidenceScreenState extends State<TaskEvidenceScreen> {
  final _notesController = TextEditingController();
  final List<String> _imagePaths = [];
  final List<String> _filePaths = [];
  final List<File> _selectedImages = [];
  final List<File> _selectedFiles = [];
  bool _isUploading = false;
  int _progress = 0;
  bool _isSubmitting = false;
  String? _uploadError;
  String _uploadStatus = '';
  
  // AI Analysis
  PhotoAnalysisResult? _analysisResult;
  bool _isAnalyzing = false;
  bool _autoStatusEnabled = true;

  @override
  void initState() {
    super.initState();
    _imagePaths.addAll(widget.task.evidenceImages);
    _filePaths.addAll(widget.task.attachments);
    _notesController.text = widget.task.evidenceNotes ?? '';
    _progress = widget.task.progress;
    print('✅ Local storage ready');
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
  try {
    final picker = ImagePicker();
    final List<XFile> images = await picker.pickMultiImage();
    
    if (images.isNotEmpty) {
      // Convert XFile to File (works on both web and mobile)
      final List<File> files = [];
      
      for (var image in images) {
        final file = File(image.path);
        final size = await file.length();
        if (size > 10 * 1024 * 1024) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Image ${image.name} is too large (>10MB)'),
              backgroundColor: Colors.orange,
            ),
          );
          return;
        }
        files.add(file);
      }
      
      setState(() {
        _selectedImages.addAll(files);
        _uploadError = null;
        _uploadStatus = '';
        _analysisResult = null;
      });
      await _saveImages();
    }
  } catch (e) {
    print('Error picking images: $e');
    setState(() {
      _uploadError = 'Failed to pick images: $e';
    });
  }
}

Future<void> _pickFiles() async {
  try {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'],
    );
    
    if (result != null && result.files.isNotEmpty) {
      for (var file in result.files) {
        if (file.size > 10 * 1024 * 1024) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('File ${file.name} is too large (>10MB)'),
              backgroundColor: Colors.orange,
            ),
          );
          return;
        }
      }
      
      // For web: use bytes, for mobile: use path
      final List<File> files = [];
      
      for (var file in result.files) {
        if (file.bytes != null) {
          // Web platform - save bytes to a temporary file
          final tempDir = await getTemporaryDirectory();
          final tempFile = File('${tempDir.path}/${file.name}');
          await tempFile.writeAsBytes(file.bytes!);
          files.add(tempFile);
        } else if (file.path != null) {
          // Mobile platform
          files.add(File(file.path!));
        }
      }
      
      setState(() {
        _selectedFiles.addAll(files);
        _uploadError = null;
        _uploadStatus = '';
      });
      await _saveFiles();
    }
  } catch (e) {
    print('Error picking files: $e');
    setState(() {
      _uploadError = 'Failed to pick files: $e';
    });
  }
}

  // Save images locally instead of cloud storage
  Future<String?> _saveFileLocally(File file, String type) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final evidenceDir = Directory('${directory.path}/evidence/${widget.task.id}/$type');
      
      if (!await evidenceDir.exists()) {
        await evidenceDir.create(recursive: true);
      }
      
      final fileName = '${DateTime.now().millisecondsSinceEpoch}_${path.basename(file.path)}';
      final filePath = '${evidenceDir.path}/$fileName';
      
      await file.copy(filePath);
      print('✅ Saved locally: $filePath');
      
      return filePath;
    } catch (e) {
      print('❌ Local save error: $e');
      _uploadError = 'Failed to save file locally: $e';
      return null;
    }
  }

  Future<void> _saveImages() async {
    if (_selectedImages.isEmpty) return;
    
    setState(() {
      _isUploading = true;
      _uploadError = null;
      _uploadStatus = 'Saving images...';
    });
    
    int successCount = 0;
    final List<String> newPaths = [];
    
    for (int i = 0; i < _selectedImages.length; i++) {
      final file = _selectedImages[i];
      
      setState(() {
        _uploadStatus = 'Saving image ${i + 1}/${_selectedImages.length}...';
      });
      
      final savedPath = await _saveFileLocally(file, 'images');
      
      if (savedPath != null) {
        newPaths.add(savedPath);
        successCount++;
      }
    }
    
    setState(() {
      _imagePaths.addAll(newPaths);
      _selectedImages.clear();
      _isUploading = false;
      _uploadStatus = '';
    });
    
    if (successCount > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ $successCount/${_selectedImages.length} images saved locally!'),
          backgroundColor: Colors.green,
        ),
      );
      
      // Run AI analysis on the first saved image
      if (_imagePaths.isNotEmpty && _autoStatusEnabled) {
        await _analyzeEvidenceWithAI(_imagePaths.first);
      }
    } else if (_uploadError == null && _selectedImages.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('⚠️ Failed to save images. Check storage permission.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _saveFiles() async {
    if (_selectedFiles.isEmpty) return;
    
    setState(() {
      _isUploading = true;
      _uploadError = null;
      _uploadStatus = 'Saving files...';
    });
    
    int successCount = 0;
    final List<String> newPaths = [];
    
    for (int i = 0; i < _selectedFiles.length; i++) {
      final file = _selectedFiles[i];
      
      setState(() {
        _uploadStatus = 'Saving file ${i + 1}/${_selectedFiles.length}...';
      });
      
      final savedPath = await _saveFileLocally(file, 'files');
      
      if (savedPath != null) {
        newPaths.add(savedPath);
        successCount++;
      }
    }
    
    setState(() {
      _filePaths.addAll(newPaths);
      _selectedFiles.clear();
      _isUploading = false;
      _uploadStatus = '';
    });
    
    if (successCount > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ $successCount/${_selectedFiles.length} files saved locally!'),
          backgroundColor: Colors.green,
        ),
      );
    } else if (_uploadError == null && _selectedFiles.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('⚠️ Failed to save files. Check storage permission.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _analyzeEvidenceWithAI(String imagePath) async {
    setState(() {
      _isAnalyzing = true;
      _analysisResult = null;
    });
    
    try {
      // For local files, we pass the file path or a placeholder
      final result = await AIPhotoAnalysis.analyzePhoto(
        imageUrl: imagePath,
        taskTitle: widget.task.title,
        taskDescription: widget.task.description,
      );
      
      setState(() {
        _analysisResult = result;
        _isAnalyzing = false;
      });
      
      if (_autoStatusEnabled && result.suggestedStatus == 'completed') {
        _showAISuggestionDialog(result);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🤖 AI Analysis: ${result.message}'),
            backgroundColor: result.statusColor,
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print('AI Analysis error: $e');
      setState(() {
        _isAnalyzing = false;
      });
    }
  }

  void _showAISuggestionDialog(PhotoAnalysisResult result) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.auto_awesome, color: result.statusColor),
            SizedBox(width: 8),
            Text('AI Suggestion'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              result.message,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            Text('Detected: ${result.detectedObject}'),
            Text('Confidence: ${(result.confidence * 100).toInt()}%'),
            SizedBox(height: 12),
            Text(
              'Would you like to mark this task as complete?',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('No, Keep as is'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _autoCompleteTask(result);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: Text('Yes, Mark Complete'),
          ),
        ],
      ),
    );
  }

  Future<void> _autoCompleteTask(PhotoAnalysisResult result) async {
    setState(() => _isSubmitting = true);
    
    try {
      final suggestedProgress = AIPhotoAnalysis.getSuggestedProgress(
        result.suggestedStatus,
        _progress,
      );
      
      await FirebaseFirestore.instance
          .collection('tasks')
          .doc(widget.task.id)
          .update({
        'evidenceImages': _imagePaths,
        'attachments': _filePaths,
        'evidenceNotes': _notesController.text + '\n\n🤖 AI Auto-analysis: ${result.message}',
        'evidenceSubmittedAt': FieldValue.serverTimestamp(),
        'status': result.suggestedStatus == 'completed' ? 'completed' : 'pending_review',
        'progress': suggestedProgress,
        if (suggestedProgress == 100) 'completedAt': FieldValue.serverTimestamp(),
      });
      
      final currentUser = FirebaseAuth.instance.currentUser;
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser?.uid)
          .get();
      final userName = userDoc.data()?['name'] ?? 'A team member';
      
      await FirebaseFirestore.instance.collection('notifications').add({
        'userId': widget.task.assignedBy,
        'title': 'Task ${suggestedProgress == 100 ? 'Completed' : 'Updated'} with AI Analysis',
        'message': '$userName submitted evidence for: ${widget.task.title}\n🤖 AI: ${result.message}',
        'type': 'success',
        'notificationType': suggestedProgress == 100 ? 'task_completed' : 'evidence_submitted',
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'relatedId': widget.task.id,
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(suggestedProgress == 100 
                ? '✅ Task marked as complete! AI verified your evidence.' 
                : '✅ Evidence submitted with AI suggestions!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      print('Auto-complete error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _openFile(String filePath, String fileName) async {
    try {
      await OpenFile.open(filePath);
    } catch (e) {
      print('Error opening file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open file: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _submitEvidence() async {
    if (_imagePaths.isEmpty && _filePaths.isEmpty && _notesController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add images, files, or notes as evidence')),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final finalStatus = _analysisResult != null && _analysisResult!.suggestedStatus == 'completed'
          ? 'completed'
          : 'pending_review';
      
      final finalProgress = _analysisResult != null && _analysisResult!.suggestedStatus == 'completed'
          ? 100
          : _progress;
      
      await FirebaseFirestore.instance
          .collection('tasks')
          .doc(widget.task.id)
          .update({
        'evidenceImages': _imagePaths,
        'attachments': _filePaths,
        'evidenceNotes': _notesController.text + 
            (_analysisResult != null ? '\n\n🤖 AI Analysis: ${_analysisResult!.message}' : ''),
        'evidenceSubmittedAt': FieldValue.serverTimestamp(),
        'status': finalStatus,
        'progress': finalProgress,
        if (finalProgress == 100) 'completedAt': FieldValue.serverTimestamp(),
      });

      final currentUser = FirebaseAuth.instance.currentUser;
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser?.uid)
          .get();
      final userName = userDoc.data()?['name'] ?? 'A team member';
      
      await FirebaseFirestore.instance.collection('notifications').add({
        'userId': widget.task.assignedBy,
        'title': finalProgress == 100 ? 'Task Completed with Evidence ✅' : 'Evidence Submitted',
        'message': '$userName has ${finalProgress == 100 ? 'completed' : 'submitted evidence for'}: ${widget.task.title}',
        'type': 'success',
        'notificationType': finalProgress == 100 ? 'task_completed' : 'evidence_submitted',
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'relatedId': widget.task.id,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Evidence submitted successfully!')),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      print('Submit error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _updateProgress(int newProgress) async {
    setState(() => _progress = newProgress);
    
    await FirebaseFirestore.instance
        .collection('tasks')
        .doc(widget.task.id)
        .update({
      'progress': newProgress,
      'status': newProgress == 100 ? 'completed' : 'in_progress',
    });
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Progress updated to $newProgress%'), backgroundColor: Colors.green),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isCompleted = _progress == 100;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Task: ${widget.task.title}'),
        backgroundColor: Colors.green,
        actions: [
          if (!isCompleted)
            Switch(
              value: _autoStatusEnabled,
              onChanged: (value) {
                setState(() {
                  _autoStatusEnabled = value;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(value 
                        ? '🤖 AI Auto-status enabled' 
                        : 'AI Auto-status disabled'),
                    duration: Duration(seconds: 1),
                  ),
                );
              },
              activeColor: Colors.white,
            ),
          if (!isCompleted)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Text('AI', style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          if (isCompleted)
            const Icon(Icons.check_circle, color: Colors.white),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Task Info Card
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.task.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    if (widget.task.description.isNotEmpty)
                      Text(widget.task.description, style: const TextStyle(fontSize: 14)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                        const SizedBox(width: 4),
                        Text(
                          'Deadline: ${DateFormat('dd MMM yyyy').format(widget.task.deadline)}',
                          style: TextStyle(
                            color: widget.task.deadline.isBefore(DateTime.now()) && !isCompleted 
                                ? Colors.red : Colors.grey,
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _getDifficultyColor().withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            'Difficulty: ${widget.task.difficultyLevel}/10',
                            style: TextStyle(color: _getDifficultyColor()),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // AI Analysis Result Card
            if (_analysisResult != null && !isCompleted)
              Container(
                margin: const EdgeInsets.only(bottom: 16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_analysisResult!.statusColor.withOpacity(0.1), _analysisResult!.statusColor.withOpacity(0.05)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _analysisResult!.statusColor.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.auto_awesome, color: _analysisResult!.statusColor, size: 28),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('🤖 AI Analysis',
                            style: TextStyle(fontWeight: FontWeight.bold, color: _analysisResult!.statusColor),
                          ),
                          const SizedBox(height: 4),
                          Text(_analysisResult!.message, style: TextStyle(fontSize: 13)),
                          const SizedBox(height: 4),
                          Text(
                            'Detected: ${_analysisResult!.detectedObject} • ${(_analysisResult!.confidence * 100).toInt()}% confidence',
                            style: TextStyle(fontSize: 11, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            // Progress Section
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Progress', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Slider(
                            value: _progress.toDouble(),
                            min: 0,
                            max: 100,
                            divisions: 10,
                            label: '$_progress%',
                            onChanged: isCompleted ? null : (value) => _updateProgress(value.toInt()),
                          ),
                        ),
                        Text('$_progress%', style: TextStyle(fontWeight: FontWeight.bold, color: _getProgressColor())),
                      ],
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: _progress / 100,
                      backgroundColor: Colors.grey.shade200,
                      valueColor: AlwaysStoppedAnimation(_getProgressColor()),
                      minHeight: 6,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Upload Status
            if (_uploadStatus.isNotEmpty && _isUploading)
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(8)),
                child: Row(
                  children: [
                    const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                    const SizedBox(width: 12),
                    Expanded(child: Text(_uploadStatus)),
                  ],
                ),
              ),
              
            // AI Analyzing indicator
            if (_isAnalyzing)
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: Colors.purple.shade50, borderRadius: BorderRadius.circular(8)),
                child: Row(
                  children: [
                    const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                    const SizedBox(width: 12),
                    Expanded(child: Text('🤖 AI is analyzing your evidence...', style: TextStyle(color: Colors.purple.shade700))),
                  ],
                ),
              ),

            // Error Display
            if (_uploadError != null)
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_uploadError!, style: const TextStyle(color: Colors.red, fontSize: 12))),
                  ],
                ),
              ),

            // Evidence Images Section
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('Evidence Images', style: TextStyle(fontWeight: FontWeight.bold)),
                        const Spacer(),
                        if (!isCompleted)
                          IconButton(
                            icon: const Icon(Icons.add_photo_alternate),
                            onPressed: _pickImages,
                            color: Colors.green,
                            tooltip: 'Add Images',
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (_imagePaths.isNotEmpty)
                      SizedBox(
                        height: 120,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _imagePaths.length,
                          itemBuilder: (context, index) {
                            final imagePath = _imagePaths[index];
                            return Padding(
                              padding: const EdgeInsets.all(4),
                              child: Stack(
                                children: [
                                  GestureDetector(
                                    onTap: () => _showImage(imagePath),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: Image.file(
                                        File(imagePath),
                                        width: 100,
                                        height: 100,
                                        fit: BoxFit.cover,
                                        errorBuilder: (context, error, stackTrace) {
                                          return Container(
                                            color: Colors.grey.shade200,
                                            child: const Icon(Icons.broken_image, color: Colors.grey),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                  if (!isCompleted)
                                    Positioned(
                                      top: 4,
                                      right: 4,
                                      child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            _imagePaths.removeAt(index);
                                          });
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Colors.black54,
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                          child: const Icon(Icons.close, size: 20, color: Colors.white),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: const Center(
                          child: Column(
                            children: [
                              Icon(Icons.image, size: 48, color: Colors.grey),
                              SizedBox(height: 8),
                              Text('No evidence images yet'),
                              SizedBox(height: 4),
                              Text('Tap the + button to add images'),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Documents/Files Section
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('Documents & Files', style: TextStyle(fontWeight: FontWeight.bold)),
                        const Spacer(),
                        if (!isCompleted)
                          IconButton(
                            icon: const Icon(Icons.attach_file),
                            onPressed: _pickFiles,
                            color: Colors.blue,
                            tooltip: 'Add Documents',
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (_filePaths.isNotEmpty)
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filePaths.length,
                        itemBuilder: (context, index) {
                          final filePath = _filePaths[index];
                          final fileName = path.basename(filePath);
                          final fileExtension = path.extension(fileName).toUpperCase().replaceAll('.', '');
                          
                          return Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade50,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            child: ListTile(
                              leading: _getFileIcon(fileExtension),
                              title: Text(
                                fileName.length > 30 ? '${fileName.substring(0, 27)}...' : fileName,
                                style: const TextStyle(fontSize: 13),
                              ),
                              subtitle: Text(fileExtension.isNotEmpty ? fileExtension : 'File',
                                style: const TextStyle(fontSize: 10, color: Colors.grey),
                              ),
                              trailing: !isCompleted
                                  ? IconButton(
                                      icon: const Icon(Icons.close, size: 18, color: Colors.red),
                                      onPressed: () {
                                        setState(() {
                                          _filePaths.removeAt(index);
                                        });
                                      },
                                    )
                                  : null,
                              onTap: () => _openFile(filePath, fileName),
                            ),
                          );
                        },
                      )
                    else
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: const Center(
                          child: Column(
                            children: [
                              Icon(Icons.insert_drive_file, size: 48, color: Colors.grey),
                              SizedBox(height: 8),
                              Text('No documents uploaded yet'),
                              SizedBox(height: 4),
                              Text('Tap the + button to add PDF, DOC, XLS, or TXT files'),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Evidence Notes Section
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Completion Notes', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _notesController,
                      decoration: const InputDecoration(
                        hintText: 'Describe how you completed this task...',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                      readOnly: isCompleted,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Submit Button
            if (!isCompleted)
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: (_isUploading || _isSubmitting) ? null : _submitEvidence,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: _isSubmitting
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Submit Evidence & Mark Complete', style: TextStyle(fontSize: 16)),
                ),
              )
            else
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green),
                    SizedBox(width: 12),
                    Expanded(child: Text('Task Completed! Evidence has been submitted.')),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _getFileIcon(String extension) {
    switch (extension.toLowerCase()) {
      case 'pdf':
        return const Icon(Icons.picture_as_pdf, color: Colors.red, size: 30);
      case 'doc':
      case 'docx':
        return const Icon(Icons.description, color: Colors.blue, size: 30);
      case 'xls':
      case 'xlsx':
        return const Icon(Icons.table_chart, color: Colors.green, size: 30);
      case 'jpg':
      case 'jpeg':
      case 'png':
        return const Icon(Icons.image, color: Colors.purple, size: 30);
      default:
        return const Icon(Icons.insert_drive_file, color: Colors.grey, size: 30);
    }
  }

  void _showImage(String imagePath) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.file(File(imagePath), errorBuilder: (context, error, stackTrace) {
              return Container(height: 200, color: Colors.grey.shade200,
                child: const Center(child: Icon(Icons.broken_image, size: 50)));
            }),
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
          ],
        ),
      ),
    );
  }

  Color _getDifficultyColor() {
    if (widget.task.difficultyLevel <= 3) return Colors.green;
    if (widget.task.difficultyLevel <= 6) return Colors.orange;
    if (widget.task.difficultyLevel <= 8) return Colors.deepOrange;
    return Colors.red;
  }

  Color _getProgressColor() {
    if (_progress >= 70) return Colors.green;
    if (_progress >= 40) return Colors.orange;
    return Colors.red;
  }
}