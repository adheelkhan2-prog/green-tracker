// lib/screens/team/assign_team_screen.dart
// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, deprecated_member_use, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AssignTeamScreen extends StatefulWidget {
  const AssignTeamScreen({super.key});

  @override
  State<AssignTeamScreen> createState() => _AssignTeamScreenState();
}

class _AssignTeamScreenState extends State<AssignTeamScreen> {
  String? _selectedProjectId;
  String? _selectedTeamId;
  List<Map<String, dynamic>> _projects = [];
  List<Map<String, dynamic>> _teams = [];
  bool _isLoading = true;
  bool _isAssigning = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    try {
      // Get projects WITHOUT an assigned team
      final projectsSnapshot = await FirebaseFirestore.instance
          .collection('projects')
          .where('teamId', isEqualTo: null)
          .get();
      
      print('=== DEBUG: Projects without team ===');
      print('Projects found: ${projectsSnapshot.docs.length}');
      
      final projects = projectsSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Untitled',
          'status': data['status'] ?? 'pending',
          'progress': data['progress'] ?? 0,
          'leaderId': data['leaderId'],
        };
      }).toList();
      
      // Get AVAILABLE teams (not assigned to any project)
      final teamsSnapshot = await FirebaseFirestore.instance
          .collection('teams')
          .where('isAvailable', isEqualTo: true)
          .get();
      
      print('=== DEBUG: Available teams ===');
      print('Teams found: ${teamsSnapshot.docs.length}');
      
      final teams = teamsSnapshot.docs.map((doc) {
        final data = doc.data();
        final memberCount = (data['memberIds'] as List?)?.length ?? 0;
        final maxMembers = data['maxMembers'] ?? 5;
        return {
          'id': doc.id,
          'name': data['name'] ?? 'Unnamed',
          'isAvailable': data['isAvailable'] ?? true,
          'memberCount': memberCount,
          'maxMembers': maxMembers,
          'leaderId': data['leaderId'],
          'leaderName': '',
        };
      }).toList();
      
      // Fetch leader names for teams
      for (var team in teams) {
        if (team['leaderId'] != null && team['leaderId'].toString().isNotEmpty) {
          final userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(team['leaderId'])
              .get();
          team['leaderName'] = userDoc.data()?['name'] ?? 'Unknown';
        } else {
          team['leaderName'] = 'No leader assigned';
        }
      }
      
      if (mounted) {
        setState(() {
          _projects = projects;
          _teams = teams;
          _isLoading = false;
          
          if (_projects.isEmpty && _teams.isEmpty) {
            _errorMessage = 'No projects or teams available. Create a project and a team first.';
          } else if (_projects.isEmpty) {
            _errorMessage = 'No unassigned projects available. Create a new project or reset existing ones.';
          } else if (_teams.isEmpty) {
            _errorMessage = 'No available teams. Create a new team or reset existing ones.';
          }
        });
      }
    } catch (e) {
      print('Error loading data: $e');
      if (mounted) {
        setState(() {
          _errorMessage = 'Error loading data: $e';
          _isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _assignTeam() async {
    if (_selectedProjectId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project')),
      );
      return;
    }
    
    if (_selectedTeamId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a team')),
      );
      return;
    }

    setState(() => _isAssigning = true);

    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      final selectedTeam = _teams.firstWhere((t) => t['id'] == _selectedTeamId);
      final selectedProject = _projects.firstWhere((p) => p['id'] == _selectedProjectId);
      
      print('=== DEBUG: Assigning Team ===');
      print('Project: ${selectedProject['title']} (${selectedProject['id']})');
      print('Team: ${selectedTeam['name']} (${selectedTeam['id']})');
      
      // Get full team details
      final teamDoc = await FirebaseFirestore.instance
          .collection('teams')
          .doc(_selectedTeamId)
          .get();
      
      if (!teamDoc.exists) {
        throw Exception('Team not found');
      }
      
      final teamData = teamDoc.data()!;
      final teamMemberIds = List<String>.from(teamData['memberIds'] ?? []);
      final teamLeaderId = teamData['leaderId'];
      
      print('Team Leader ID: $teamLeaderId');
      print('Team Members: $teamMemberIds');
      
      if (teamLeaderId == null || teamLeaderId.isEmpty) {
        throw Exception('Team has no leader assigned. Please edit the team and add a leader.');
      }
      
      // Get team leader name for notification
      final leaderDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(teamLeaderId)
          .get();
      final teamLeaderName = leaderDoc.data()?['name'] ?? 'Team Leader';
      
      // 1. UPDATE PROJECT
      await FirebaseFirestore.instance
          .collection('projects')
          .doc(_selectedProjectId)
          .update({
        'teamId': _selectedTeamId,
        'members': teamMemberIds,
        'leaderId': teamLeaderId,
        'status': 'active',
        'assignedAt': FieldValue.serverTimestamp(),
        'assignedBy': currentUser?.uid,
      });
      
      print('✅ Project updated with team');
      
      // 2. UPDATE TEAM
      await FirebaseFirestore.instance
          .collection('teams')
          .doc(_selectedTeamId)
          .update({
        'isAvailable': false,
        'currentProjectId': _selectedProjectId,
        'assignedAt': FieldValue.serverTimestamp(),
      });
      
      print('✅ Team updated as not available');
      
      // 3. Send notification to Team Leader
      await FirebaseFirestore.instance.collection('notifications').add({
        'userId': teamLeaderId,
        'title': '🎯 New Project Assigned to Your Team',
        'message': 'Your team "${selectedTeam['name']}" has been assigned to project: ${selectedProject['title']}. You are the Team Leader.',
        'type': 'success',
        'notificationType': 'project_assigned',
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'relatedId': _selectedProjectId,
      });
      
      // 4. Send notifications to all team members
      for (String memberId in teamMemberIds) {
        if (memberId != teamLeaderId) {
          await FirebaseFirestore.instance.collection('notifications').add({
            'userId': memberId,
            'title': 'New Project Assigned',
            'message': 'Your team has been assigned to project: ${selectedProject['title']}. Your Team Leader is $teamLeaderName.',
            'type': 'info',
            'notificationType': 'project_assigned',
            'isRead': false,
            'createdAt': FieldValue.serverTimestamp(),
            'relatedId': _selectedProjectId,
          });
        }
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ Team "${selectedTeam['name']}" assigned! Team Leader is now $teamLeaderName.'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      print('Assignment error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isAssigning = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assign Team to Project'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.orange),
                      const SizedBox(height: 16),
                      Text(_errorMessage!, textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadData,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Refresh'),
                      ),
                    ],
                  ),
                )
              : _projects.isEmpty || _teams.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (_projects.isEmpty)
                            const Padding(
                              padding: EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  Icon(Icons.folder_open, size: 64, color: Colors.grey),
                                  SizedBox(height: 16),
                                  Text('No unassigned projects available'),
                                  SizedBox(height: 8),
                                  Text('Create a project first, or reset existing ones'),
                                ],
                              ),
                            ),
                          if (_teams.isEmpty)
                            const Padding(
                              padding: EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  Icon(Icons.group_off, size: 64, color: Colors.grey),
                                  SizedBox(height: 16),
                                  Text('No available teams'),
                                  SizedBox(height: 8),
                                  Text('Create a team first, or reset existing ones'),
                                ],
                              ),
                            ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadData,
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                            child: const Text('Refresh'),
                          ),
                        ],
                      ),
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Card(
                            color: Colors.blue.shade50,
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                children: [
                                  Icon(Icons.info_outline, color: Colors.blue.shade700),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      'Assign an available team to a project. The team\'s leader will become the project leader.',
                                      style: TextStyle(color: Colors.blue.shade700, fontSize: 12),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                          
                          // Project Dropdown
                          const Text(
                            'Select Project',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 8),
                          DropdownButtonFormField<String>(
                            value: _selectedProjectId,
                            hint: const Text('Choose a project'),
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              prefixIcon: const Icon(Icons.folder),
                            ),
                            items: _projects.map((project) {
                              return DropdownMenuItem<String>(
                                value: project['id'] as String,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(project['title'] as String),
                                    Text(
                                      'Progress: ${project['progress']}%',
                                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedProjectId = value;
                              });
                            },
                          ),
                          const SizedBox(height: 24),
                          
                          // Team Dropdown
                          const Text(
                            'Select Team',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 8),
                          DropdownButtonFormField<String>(
                            value: _selectedTeamId,
                            hint: const Text('Choose a team'),
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              prefixIcon: const Icon(Icons.group),
                            ),
                            items: _teams.map((team) {
                              return DropdownMenuItem<String>(
                                value: team['id'] as String,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(team['name'] as String),
                                    Text(
                                      '${team['memberCount']} members • Leader: ${team['leaderName']}',
                                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedTeamId = value;
                              });
                            },
                          ),
                          const SizedBox(height: 32),
                          
                          // Assign Button
                          SizedBox(
                            width: double.infinity,
                            height: 55,
                            child: ElevatedButton(
                              onPressed: (_isAssigning || _selectedProjectId == null || _selectedTeamId == null) ? null : _assignTeam,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 3,
                              ),
                              child: _isAssigning
                                  ? const SizedBox(
                                      width: 24,
                                      height: 24,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Text(
                                      'Assign Team to Project',
                                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),
    );
  }
}