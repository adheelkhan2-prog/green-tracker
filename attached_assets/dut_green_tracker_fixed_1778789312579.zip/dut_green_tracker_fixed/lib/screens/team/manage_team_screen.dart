// lib/screens/team/manage_team_screen.dart
// ignore_for_file: prefer_const_constructors, use_build_context_synchronously, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ManageTeamScreen extends StatefulWidget {
  final String projectId;
  final String projectTitle;

  const ManageTeamScreen({
    super.key,
    required this.projectId,
    required this.projectTitle,
  });

  @override
  State<ManageTeamScreen> createState() => _ManageTeamScreenState();
}

class _ManageTeamScreenState extends State<ManageTeamScreen> {
  List<Map<String, dynamic>> _teamMembers = [];
  String? _teamId;
  String? _teamName;
  int? _maxMembers;
  bool _isLoading = true;
  bool _isLeader = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadTeamData();
  }

  Future<void> _loadTeamData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      
      // First, get the project to find its teamId
      final projectDoc = await FirebaseFirestore.instance
          .collection('projects')
          .doc(widget.projectId)
          .get();
      
      if (!projectDoc.exists) {
        setState(() {
          _errorMessage = 'Project not found';
          _isLoading = false;
        });
        return;
      }
      
      final teamId = projectDoc.data()?['teamId'];
      
      if (teamId == null || teamId.isEmpty) {
        setState(() {
          _errorMessage = 'No team assigned to this project yet. Admin needs to assign a team.';
          _isLoading = false;
        });
        return;
      }
      
      _teamId = teamId;
      
      // Load team details
      final teamDoc = await FirebaseFirestore.instance
          .collection('teams')
          .doc(teamId)
          .get();
      
      if (!teamDoc.exists) {
        setState(() {
          _errorMessage = 'Team not found';
          _isLoading = false;
        });
        return;
      }
      
      final teamData = teamDoc.data()!;
      _teamName = teamData['name'];
      _maxMembers = teamData['maxMembers'] ?? 5;
      final memberIds = List<String>.from(teamData['memberIds'] ?? []);
      final leaderId = teamData['leaderId'];
      
      // Check if current user is the team leader
      _isLeader = leaderId == currentUser?.uid;
      
      // Load member details
      final members = <Map<String, dynamic>>[];
      for (String memberId in memberIds) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(memberId)
            .get();
        
        if (userDoc.exists) {
          members.add({
            'id': memberId,
            'name': userDoc.data()?['name'] ?? 'Unknown',
            'email': userDoc.data()?['email'] ?? '',
            'role': userDoc.data()?['role'] ?? 'member',
            'isLeader': memberId == leaderId,
          });
        }
      }
      
      // Sort: leader first, then alphabetically
      members.sort((a, b) {
        if (a['isLeader']) return -1;
        if (b['isLeader']) return 1;
        return (a['name'] ?? '').compareTo(b['name'] ?? '');
      });
      
      setState(() {
        _teamMembers = members;
        _isLoading = false;
      });
      
      print('Loaded ${members.length} members from team: $_teamName');
    } catch (e) {
      print('Error loading team: $e');
      setState(() {
        _errorMessage = 'Error loading team: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _addMember() async {
    if (!_isLeader) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Only team leader can add members'), backgroundColor: Colors.red),
      );
      return;
    }
    
    final currentMembers = _teamMembers.map((m) => m['id']).toList();
    final availableSlots = (_maxMembers ?? 5) - currentMembers.length;
    
    if (availableSlots <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Team is full (max ${_maxMembers ?? 5} members)'), backgroundColor: Colors.orange),
      );
      return;
    }
    
    final selectedUsers = await showDialog<List<String>>(
      context: context,
      builder: (context) => _buildAddMemberDialog(
  currentMembers.cast<String>(),
  availableSlots,
),
    );
    
    if (selectedUsers != null && selectedUsers.isNotEmpty && _teamId != null) {
      setState(() => _isLoading = true);
      
      try {
        // Add members to team
        await FirebaseFirestore.instance
            .collection('teams')
            .doc(_teamId)
            .update({
          'memberIds': FieldValue.arrayUnion(selectedUsers),
        });
        
        // Also add members to project
        await FirebaseFirestore.instance
            .collection('projects')
            .doc(widget.projectId)
            .update({
          'members': FieldValue.arrayUnion(selectedUsers),
        });
        
        // Send notifications to new members
        for (String userId in selectedUsers) {
          final userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .get();
          final userName = userDoc.data()?['name'] ?? 'Member';
          
          await FirebaseFirestore.instance.collection('notifications').add({
            'userId': userId,
            'title': 'Added to Team 🎉',
            'message': 'You have been added to team "$_teamName" for project ${widget.projectTitle}',
            'type': 'success',
            'notificationType': 'member_added',
            'isRead': false,
            'createdAt': FieldValue.serverTimestamp(),
            'relatedId': _teamId,
          });
        }
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Added ${selectedUsers.length} member(s)'), backgroundColor: Colors.green),
        );
        
        await _loadTeamData(); // Refresh
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error adding members: $e'), backgroundColor: Colors.red),
        );
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _removeMember(String memberId, String memberName) async {
    if (!_isLeader) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Only team leader can remove members'), backgroundColor: Colors.red),
      );
      return;
    }
    
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Remove Member'),
        content: Text('Remove $memberName from the team?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    
    if (confirm == true && _teamId != null) {
      setState(() => _isLoading = true);
      
      try {
        // Remove from team
        await FirebaseFirestore.instance
            .collection('teams')
            .doc(_teamId)
            .update({
          'memberIds': FieldValue.arrayRemove([memberId]),
        });
        
        // Remove from project
        await FirebaseFirestore.instance
            .collection('projects')
            .doc(widget.projectId)
            .update({
          'members': FieldValue.arrayRemove([memberId]),
        });
        
        // Also unassign any tasks assigned to this member in this project
        final tasksSnapshot = await FirebaseFirestore.instance
            .collection('tasks')
            .where('projectId', isEqualTo: widget.projectId)
            .where('assignedTo', isEqualTo: memberId)
            .get();
        
        for (var doc in tasksSnapshot.docs) {
          await doc.reference.update({
            'assignedTo': '',
            'status': 'pending',
          });
        }
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Removed $memberName from team'), backgroundColor: Colors.green),
        );
        
        await _loadTeamData(); // Refresh
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error removing member: $e'), backgroundColor: Colors.red),
        );
        setState(() => _isLoading = false);
      }
    }
  }

  Widget _buildAddMemberDialog(List<String> currentMembers, int availableSlots) {
    List<String> selectedMembers = [];
    
    return StatefulBuilder(
      builder: (context, setState) {
        return AlertDialog(
          title: Row(
            children: [
              const Icon(Icons.person_add, color: Colors.green),
              const SizedBox(width: 8),
              Text('Add Team Members ($availableSlots slots available)'),
            ],
          ),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: Column(
              children: [
                if (availableSlots <= 3)
                  Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.warning, color: Colors.orange, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Only $availableSlots slot(s) available',
                            style: TextStyle(fontSize: 12, color: Colors.orange.shade700),
                          ),
                        ),
                      ],
                    ),
                  ),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('users')
                        .where('role', whereIn: ['student', 'staff'])
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      
                      final availableUsers = snapshot.data!.docs.where((doc) {
                        return !currentMembers.contains(doc.id);
                      }).toList();
                      
                      if (availableUsers.isEmpty) {
                        return const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.people_outline, size: 48, color: Colors.grey),
                              SizedBox(height: 8),
                              Text('No available users to add'),
                            ],
                          ),
                        );
                      }
                      
                      return ListView.builder(
                        itemCount: availableUsers.length,
                        itemBuilder: (context, index) {
                          final user = availableUsers[index];
                          final data = user.data() as Map<String, dynamic>;
                          final isSelected = selectedMembers.contains(user.id);
                          
                          return CheckboxListTile(
                            value: isSelected,
                            onChanged: (checked) {
                              setState(() {
                                if (checked == true) {
                                  if (selectedMembers.length < availableSlots) {
                                    selectedMembers.add(user.id);
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Maximum $availableSlots members can be added'),
                                        backgroundColor: Colors.orange,
                                      ),
                                    );
                                  }
                                } else {
                                  selectedMembers.remove(user.id);
                                }
                              });
                            },
                            title: Text(data['name'] ?? 'Unknown'),
                            subtitle: Text(data['email'] ?? ''),
                            secondary: CircleAvatar(
                              backgroundColor: Colors.green.shade100,
                              child: Text(
                                (data['name']?.substring(0, 1) ?? 'U').toUpperCase(),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, selectedMembers),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: Text('Add ${selectedMembers.length} Member(s)'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_teamName != null ? 'Team: $_teamName' : 'Manage Team'),
        backgroundColor: Colors.green,
        actions: [
          if (_isLeader)
            IconButton(
              icon: const Icon(Icons.person_add),
              onPressed: _addMember,
              tooltip: 'Add Member',
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadTeamData,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red.shade400),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(
                          _errorMessage!,
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.red.shade700),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadTeamData,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : _teamMembers.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.group_off, size: 64, color: Colors.grey.shade400),
                          const SizedBox(height: 16),
                          const Text(
                            'No team members yet',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Maximum ${_maxMembers ?? 5} members allowed',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                          const SizedBox(height: 16),
                          if (_isLeader)
                            ElevatedButton.icon(
                              onPressed: _addMember,
                              icon: const Icon(Icons.person_add),
                              label: const Text('Add Team Members'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                              ),
                            ),
                        ],
                      ),
                    )
                  : Column(
                      children: [
                        // Team Info Card
                        Container(
                          margin: const EdgeInsets.all(16),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.green.shade50, Colors.green.shade100],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.green.shade200),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.group, color: Colors.green, size: 28),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _teamName ?? 'Team',
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '${_teamMembers.length}/${_maxMembers ?? 5} members • ${_isLeader ? "You are Team Leader" : "Member"}',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.green.shade700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (_isLeader)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: const Text(
                                    'Leader',
                                    style: TextStyle(color: Colors.white, fontSize: 10),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        
                        // Members List
                        Expanded(
                          child: ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _teamMembers.length,
                            itemBuilder: (context, index) {
                              final member = _teamMembers[index];
                              return Card(
                                margin: const EdgeInsets.only(bottom: 12),
                                elevation: 2,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: ListTile(
                                  leading: CircleAvatar(
                                    backgroundColor: member['isLeader'] 
                                        ? Colors.green 
                                        : Colors.grey.shade200,
                                    child: Text(
                                      member['name'].substring(0, 1).toUpperCase(),
                                      style: TextStyle(
                                        color: member['isLeader'] ? Colors.white : Colors.black87,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  title: Text(
                                    member['name'],
                                    style: const TextStyle(fontWeight: FontWeight.w500),
                                  ),
                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(member['role']),
                                      if (member['email'] != null && member['email'].isNotEmpty)
                                        Text(
                                          member['email'],
                                          style: const TextStyle(fontSize: 11, color: Colors.grey),
                                        ),
                                    ],
                                  ),
                                  trailing: member['isLeader']
                                      ? const Chip(
                                          label: Text('Leader'),
                                          backgroundColor: Colors.green,
                                          labelStyle: TextStyle(color: Colors.white, fontSize: 11),
                                        )
                                      : (_isLeader && member['id'] != FirebaseAuth.instance.currentUser?.uid)
                                          ? IconButton(
                                              icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                                              onPressed: () => _removeMember(member['id'], member['name']),
                                              tooltip: 'Remove Member',
                                            )
                                          : null,
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
    );
  }
}