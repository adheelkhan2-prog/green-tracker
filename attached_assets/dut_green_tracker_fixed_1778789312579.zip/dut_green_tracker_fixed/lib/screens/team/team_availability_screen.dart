// ignore_for_file: unnecessary_null_comparison, unnecessary_brace_in_string_interps

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TeamAvailabilityScreen extends StatelessWidget {
  const TeamAvailabilityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Team Availability'),
        backgroundColor: Colors.green,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('teams')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          
          final teams = snapshot.data!.docs;
          
          if (teams.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.group_off, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No teams found'),
                  SizedBox(height: 8),
                  Text('Create teams in Admin panel first'),
                ],
              ),
            );
          }
          
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: teams.length,
            itemBuilder: (context, index) {
              final team = teams[index];
              final data = team.data() as Map<String, dynamic>;
              final isAvailable = data['isAvailable'] ?? true;
              final currentProjectId = data['currentProjectId'];
              final teamName = data['name'] ?? 'Unnamed Team';
              final memberCount = (data['memberIds'] as List?)?.length ?? 0;
              final maxMembers = data['maxMembers'] ?? 5;
              
              return FutureBuilder<DocumentSnapshot>(
                future: currentProjectId != null && currentProjectId.isNotEmpty
                    ? FirebaseFirestore.instance.collection('projects').doc(currentProjectId).get()
                    : null,
                builder: (context, projectSnapshot) {
                  String projectName = '';
                  if (projectSnapshot != null && projectSnapshot.hasData && projectSnapshot.data!.exists) {
                    projectName = projectSnapshot.data!['title'] ?? 'Unknown Project';
                  }
                  
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ExpansionTile(
                      leading: CircleAvatar(
                        backgroundColor: isAvailable ? Colors.green : Colors.orange,
                        child: Icon(
                          isAvailable ? Icons.check : Icons.business,
                          color: Colors.white,
                        ),
                      ),
                      title: Text(
                        teamName,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${memberCount}/$maxMembers members',
                            style: const TextStyle(fontSize: 11),
                          ),
                          if (!isAvailable && projectName.isNotEmpty)
                            Text(
                              'Assigned to: $projectName',
                              style: TextStyle(fontSize: 11, color: Colors.orange.shade700),
                            ),
                        ],
                      ),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: isAvailable ? Colors.green.shade100 : Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          isAvailable ? 'AVAILABLE' : 'ASSIGNED',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: isAvailable ? Colors.green : Colors.orange,
                          ),
                        ),
                      ),
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Team Leader
                              _buildInfoRow(
                                'Team Leader',
                                data['leaderId'],
                                Icons.leaderboard,
                              ),
                              const SizedBox(height: 8),
                              
                              // Project info if assigned
                              if (!isAvailable && projectName.isNotEmpty)
                                _buildInfoRow(
                                  'Current Project',
                                  projectName,
                                  Icons.folder,
                                ),
                              if (!isAvailable && currentProjectId != null && currentProjectId.isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: ElevatedButton.icon(
                                    onPressed: () {
                                      // Navigate to project details
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text('View project: $projectName'),
                                          backgroundColor: Colors.blue,
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.visibility, size: 16),
                                    label: const Text('View Project'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue.shade100,
                                      foregroundColor: Colors.blue.shade700,
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      minimumSize: Size.zero,
                                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    ),
                                  ),
                                ),
                              
                              const Divider(height: 24),
                              
                              // Members List
                              const Text(
                                'Team Members',
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                              ),
                              const SizedBox(height: 8),
                              ..._buildMembersList(data['memberIds'] ?? []),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
  
  Widget _buildInfoRow(String label, dynamic value, IconData icon) {
    if (value == null || (value is String && value.isEmpty)) {
      return const SizedBox.shrink();
    }
    
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(value).get(),
      builder: (context, snapshot) {
        final name = snapshot.hasData && snapshot.data!.exists
            ? snapshot.data!['name'] ?? 'Unknown'
            : 'Loading...';
        
        return Row(
          children: [
            Icon(icon, size: 14, color: Colors.grey),
            const SizedBox(width: 8),
            Text(
              '$label: ',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
            ),
            Text(
              name,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        );
      },
    );
  }
  
  List<Widget> _buildMembersList(List<dynamic> memberIds) {
    if (memberIds.isEmpty) {
      return [
        const Padding(
          padding: EdgeInsets.all(8),
          child: Text('No members in this team', style: TextStyle(fontSize: 12, color: Colors.grey)),
        ),
      ];
    }
    
    return memberIds.map((memberId) {
      return FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(memberId).get(),
        builder: (context, snapshot) {
          final name = snapshot.hasData && snapshot.data!.exists
              ? snapshot.data!['name'] ?? 'Unknown'
              : 'Loading...';
          final role = snapshot.hasData && snapshot.data!.exists
              ? snapshot.data!['role'] ?? 'member'
              : '';
          
          return Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 12,
                  backgroundColor: Colors.green.shade100,
                  child: Text(
                    name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: const TextStyle(fontSize: 12)),
                      if (role.isNotEmpty)
                        Text(role, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      );
    }).toList();
  }
}