// lib/screens/team/team_feed_screen.dart
// ignore_for_file: use_build_context_synchronously, prefer_final_fields

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:intl/intl.dart';
import '../../services/team_feed_service.dart';

class TeamFeedScreen extends StatefulWidget {
  final String projectId;
  final String projectTitle;

  const TeamFeedScreen({
    super.key,
    required this.projectId,
    required this.projectTitle,
  });

  @override
  State<TeamFeedScreen> createState() => _TeamFeedScreenState();
}

class _TeamFeedScreenState extends State<TeamFeedScreen> {
  final TeamFeedService _feedService = TeamFeedService();
  final TextEditingController _postController = TextEditingController();
  final TextEditingController _commentController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  List<File> _selectedImages = [];
  bool _isUploading = false;
  String? _expandedFeedId;

  @override
  void dispose() {
    _postController.dispose();
    _commentController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    final picker = ImagePicker();
    final images = await picker.pickMultiImage();
    
    if (images.isNotEmpty) {
      setState(() {
        _selectedImages.addAll(images.map((x) => File(x.path)));
      });
    }
  }

  Future<List<String>> _uploadImages(String feedId) async {
    List<String> imageUrls = [];
    final storage = FirebaseStorage.instance;
    
    for (int i = 0; i < _selectedImages.length; i++) {
      final file = _selectedImages[i];
      final fileName = 'feed_${DateTime.now().millisecondsSinceEpoch}_$i.jpg';
      final ref = storage.ref().child('team_feeds/$feedId/$fileName');
      
      await ref.putFile(file);
      final url = await ref.getDownloadURL();
      imageUrls.add(url);
    }
    
    return imageUrls;
  }

  Future<void> _createPost() async {
    if (_postController.text.trim().isEmpty && _selectedImages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a message or add images')),
      );
      return;
    }

    setState(() {
      _isUploading = true;
    });

    try {
      // First create the post without images to get ID
      final user = FirebaseAuth.instance.currentUser;
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user?.uid)
          .get();
      final userName = userDoc.data()?['name'] ?? 'Team Member';
      
      final postRef = await FirebaseFirestore.instance.collection('team_feeds').add({
        'projectId': widget.projectId,
        'userId': user?.uid,
        'userName': userName,
        'userPhotoUrl': '',
        'type': 'update',
        'title': 'Team Update',
        'content': _postController.text.trim(),
        'images': [],
        'attachments': [],
        'createdAt': FieldValue.serverTimestamp(),
        'readBy': [user?.uid],
        'commentCount': 0,
        'isPinned': false,
      });
      
      // Upload images if any
      if (_selectedImages.isNotEmpty) {
        final imageUrls = await _uploadImages(postRef.id);
        await postRef.update({'images': imageUrls});
      }
      
      _postController.clear();
      setState(() {
        _selectedImages.clear();
        _isUploading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Post created successfully!'), backgroundColor: Colors.green),
      );
      
    } catch (e) {
      setState(() => _isUploading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  void _showCreatePostDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          return DraggableScrollableSheet(
            initialChildSize: 0.7,
            minChildSize: 0.5,
            maxChildSize: 0.9,
            expand: false,
            builder: (context, scrollController) => Container(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    child: const Text(
                      'Create Team Update',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      controller: scrollController,
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          TextField(
                            controller: _postController,
                            decoration: const InputDecoration(
                              hintText: 'What\'s happening with the project?',
                              border: OutlineInputBorder(),
                              contentPadding: EdgeInsets.all(16),
                            ),
                            maxLines: 5,
                            autofocus: true,
                          ),
                          const SizedBox(height: 16),
                          
                          // Selected images preview
                          if (_selectedImages.isNotEmpty)
                            SizedBox(
                              height: 100,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: _selectedImages.length,
                                itemBuilder: (context, index) {
                                  return Stack(
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.only(right: 8),
                                        width: 100,
                                        height: 100,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(8),
                                          image: DecorationImage(
                                            image: FileImage(_selectedImages[index]),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        top: 4,
                                        right: 4,
                                        child: GestureDetector(
                                          onTap: () {
                                            setModalState(() {
                                              _selectedImages.removeAt(index);
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Colors.black54,
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: const Icon(
                                              Icons.close,
                                              size: 20,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ),
                          
                          const SizedBox(height: 16),
                          
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.image, color: Colors.green),
                                onPressed: () async {
                                  await _pickImages();
                                  setModalState(() {});
                                },
                                tooltip: 'Add Images',
                              ),
                              const Spacer(),
                              ElevatedButton(
                                onPressed: _isUploading ? null : () async {
                                  Navigator.pop(context);
                                  await _createPost();
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  foregroundColor: Colors.white,
                                ),
                                child: _isUploading
                                    ? const SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(strokeWidth: 2),
                                      )
                                    : const Text('Post'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.projectTitle} Feed'),
        backgroundColor: Colors.green,
        actions: [
          // Filter button
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            onSelected: (value) {},
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'all', child: Text('All Updates')),
              const PopupMenuItem(value: 'photos', child: Text('Photos')),
              const PopupMenuItem(value: 'tasks', child: Text('Task Updates')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Create post button
          Padding(
            padding: const EdgeInsets.all(12),
            child: GestureDetector(
              onTap: _showCreatePostDialog,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: Colors.green.shade100,
                      child: const Icon(Icons.person, size: 18, color: Colors.green),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Share a team update...',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const Spacer(),
                    Icon(Icons.image, color: Colors.green.shade400),
                    const SizedBox(width: 8),
                    Icon(Icons.send, color: Colors.green.shade400),
                  ],
                ),
              ),
            ),
          ),
          
          // Feed list
          Expanded(
            child: StreamBuilder<List<TeamFeedItem>>(
              stream: _feedService.getProjectFeeds(widget.projectId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.feed, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text(
                          'No feed updates yet',
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Be the first to share a team update!',
                          style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                        ),
                      ],
                    ),
                  );
                }
                
                final feeds = snapshot.data!;
                
                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(12),
                  itemCount: feeds.length,
                  itemBuilder: (context, index) {
                    final feed = feeds[index];
                    final isUnread = !feed.readBy.contains(currentUserId);
                    
                    return _buildFeedCard(feed, isUnread, currentUserId);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildFeedCard(TeamFeedItem feed, bool isUnread, String? currentUserId) {
    final isExpanded = _expandedFeedId == feed.id;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: isUnread ? 3 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isUnread
            ? BorderSide(color: Colors.green.shade300, width: 1.5)
            : BorderSide.none,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: _getTypeColor(feed.type),
                  child: Icon(_getTypeIcon(feed.type), color: Colors.white, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        feed.userName,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        _formatTimeAgo(feed.createdAt),
                        style: const TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                if (feed.isPinned)
                  const Icon(Icons.push_pin, color: Colors.orange, size: 18),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert, size: 18),
                  onSelected: (value) async {
                    if (value == 'pin') {
                      await _feedService.togglePin(feed.id, !feed.isPinned);
                    } else if (value == 'delete') {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Delete Post'),
                          content: const Text('Are you sure?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, false),
                              child: const Text('Cancel'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(context, true),
                              style: TextButton.styleFrom(foregroundColor: Colors.red),
                              child: const Text('Delete'),
                            ),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await _feedService.deleteFeed(feed.id);
                      }
                    }
                  },
                  itemBuilder: (context) => [
                    if (feed.userId == currentUserId)
                      const PopupMenuItem(
                        value: 'pin',
                        child: Row(
                          children: [
                            Icon(Icons.push_pin, size: 20),
                            SizedBox(width: 8),
                            Text('Pin/Unpin'),
                          ],
                        ),
                      ),
                    if (feed.userId == currentUserId)
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, color: Colors.red, size: 20),
                            SizedBox(width: 8),
                            Text('Delete', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          
          // Content
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (feed.title.isNotEmpty)
                  Text(
                    feed.title,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                const SizedBox(height: 8),
                Text(
                  feed.content,
                  style: const TextStyle(fontSize: 14, height: 1.4),
                ),
                if (feed.images.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 150,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: feed.images.length,
                      itemBuilder: (context, imgIndex) {
                        return GestureDetector(
                          onTap: () => _showImagePreview(feed.images[imgIndex]),
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            width: 150,
                            height: 150,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              image: DecorationImage(
                                image: NetworkImage(feed.images[imgIndex]),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
          
          // Actions
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                // Read indicator
                if (isUnread && feed.readBy.length > 1)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.green.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${feed.readBy.length - 1} others read',
                      style: TextStyle(fontSize: 11, color: Colors.green.shade700),
                    ),
                  ),
                const Spacer(),
                
                // Comment button
                TextButton.icon(
                  onPressed: () async {
                    if (isExpanded) {
                      setState(() {
                        _expandedFeedId = null;
                      });
                    } else {
                      await _feedService.markAsRead(feed.id);
                      setState(() {
                        _expandedFeedId = feed.id;
                      });
                    }
                  },
                  icon: Icon(Icons.comment, size: 16, color: Colors.grey.shade600),
                  label: Text(
                    '${feed.commentCount} comment${feed.commentCount != 1 ? 's' : ''}',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ),
              ],
            ),
          ),
          
          // Comments section (expanded)
          if (isExpanded)
            _buildCommentsSection(feed.id),
        ],
      ),
    );
  }
  
  Widget _buildCommentsSection(String feedId) {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          // Comments list
          StreamBuilder<List<TeamFeedComment>>(
            stream: _feedService.getFeedComments(feedId),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              
              final comments = snapshot.data!;
              
              if (comments.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('No comments yet', style: TextStyle(color: Colors.grey)),
                );
              }
              
              return ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: comments.length,
                itemBuilder: (context, index) {
                  final comment = comments[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          radius: 14,
                          backgroundColor: Colors.green.shade100,
                          child: Text(
                            comment.userName.substring(0, 1).toUpperCase(),
                            style: const TextStyle(fontSize: 12, color: Colors.green),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                comment.userName,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                              Text(
                                comment.content,
                                style: const TextStyle(fontSize: 13),
                              ),
                              Text(
                                _formatTimeAgo(comment.createdAt),
                                style: const TextStyle(fontSize: 10, color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          
          const Divider(),
          
          // Add comment input
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _commentController,
                  decoration: const InputDecoration(
                    hintText: 'Write a comment...',
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 8),
                  ),
                  onSubmitted: (value) async {
                    if (value.isNotEmpty) {
                      await _feedService.addComment(feedId, value);
                      _commentController.clear();
                    }
                  },
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send, color: Colors.green),
                onPressed: () async {
                  if (_commentController.text.isNotEmpty) {
                    await _feedService.addComment(feedId, _commentController.text);
                    _commentController.clear();
                  }
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  void _showImagePreview(String imageUrl) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.network(imageUrl),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }
  
  String _formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inDays > 7) {
      return DateFormat('dd MMM yyyy').format(dateTime);
    } else if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    } else {
      return 'Just now';
    }
  }
  
  Color _getTypeColor(String type) {
    switch (type) {
      case 'task_completed':
        return Colors.green;
      case 'photo_upload':
        return Colors.purple;
      case 'member_joined':
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }
  
  IconData _getTypeIcon(String type) {
    switch (type) {
      case 'task_completed':
        return Icons.check_circle;
      case 'photo_upload':
        return Icons.image;
      case 'member_joined':
        return Icons.person_add;
      default:
        return Icons.update;
    }
  }
}