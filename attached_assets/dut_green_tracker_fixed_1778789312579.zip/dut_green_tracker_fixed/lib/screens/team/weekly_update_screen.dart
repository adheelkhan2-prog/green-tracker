// lib/screens/team/weekly_update_screen.dart
// ignore_for_file: deprecated_member_use, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/weekly_update_service.dart';

class WeeklyUpdateScreen extends StatefulWidget {
  final String projectId;
  final String projectTitle;

  const WeeklyUpdateScreen({
    super.key,
    required this.projectId,
    required this.projectTitle,
  });

  @override
  State<WeeklyUpdateScreen> createState() => _WeeklyUpdateScreenState();
}

class _WeeklyUpdateScreenState extends State<WeeklyUpdateScreen> {
  final WeeklyUpdateService _service = WeeklyUpdateService();
  final _formKey = GlobalKey<FormState>();
  
  // Form controllers
  final _progressSummaryController = TextEditingController();
  final _achievementsController = TextEditingController();
  final _challengesController = TextEditingController();
  final _nextWeekPlanController = TextEditingController();
  
  // Task stats
  int _tasksCompleted = 0;
  int _tasksInProgress = 0;
  int _tasksBlocked = 0;
  double _currentProgress = 0;
  
  bool _isSubmitting = false;
  bool _hasSubmitted = false;
  
  @override
  void initState() {
    super.initState();
    _checkSubmissionStatus();
    _loadTaskStats();
  }
  
  @override
  void dispose() {
    _progressSummaryController.dispose();
    _achievementsController.dispose();
    _challengesController.dispose();
    _nextWeekPlanController.dispose();
    super.dispose();
  }
  
  Future<void> _checkSubmissionStatus() async {
    final submitted = await _service.hasSubmittedThisWeek(widget.projectId);
    setState(() {
      _hasSubmitted = submitted;
    });
  }
  
  Future<void> _loadTaskStats() async {
    final tasksSnapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .where('projectId', isEqualTo: widget.projectId)
        .get();
    
    int completed = 0;
    int inProgress = 0;
    int blocked = 0;
    
    for (var doc in tasksSnapshot.docs) {
      final data = doc.data();
      final status = data['status'] ?? 'pending';
      final progress = data['progress'] ?? 0;
      
      if (progress == 100 || status == 'completed') {
        completed++;
      } else if (status == 'blocked') {
        blocked++;
      } else if (progress > 0) {
        inProgress++;
      }
    }
    
    setState(() {
      _tasksCompleted = completed;
      _tasksInProgress = inProgress;
      _tasksBlocked = blocked;
    });
  }
  
  Future<void> _submitUpdate() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() => _isSubmitting = true);
    
    try {
      await _service.submitWeeklyUpdate(
        projectId: widget.projectId,
        projectTitle: widget.projectTitle,
        progressSummary: _progressSummaryController.text,
        achievements: _achievementsController.text,
        challenges: _challengesController.text,
        nextWeekPlan: _nextWeekPlanController.text,
        tasksCompleted: _tasksCompleted,
        tasksInProgress: _tasksInProgress,
        tasksBlocked: _tasksBlocked,
        currentProgress: _currentProgress,
      );
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Weekly update submitted successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    if (_hasSubmitted) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Weekly Update'),
          backgroundColor: Colors.green,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle, size: 80, color: Colors.green),
              const SizedBox(height: 16),
              const Text(
                'Weekly Update Already Submitted',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'You have already submitted the weekly update for this week.',
                style: TextStyle(color: Colors.grey.shade600),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      );
    }
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weekly Update'),
        backgroundColor: Colors.green,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.green.shade400, Colors.green.shade700],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.projectTitle,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Week ${WeeklyUpdateService.getCurrentWeek()['week']} • ${DateTime.now().year}',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              
              // Progress Summary
              const Text(
                'Progress Summary *',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _progressSummaryController,
                decoration: const InputDecoration(
                  hintText: 'Summarize what was accomplished this week...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (v) => v?.isEmpty == true ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              
              // Achievements
              const Text(
                'Key Achievements *',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _achievementsController,
                decoration: const InputDecoration(
                  hintText: 'List the main achievements for this week...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (v) => v?.isEmpty == true ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              
              // Challenges
              const Text(
                'Challenges Faced',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _challengesController,
                decoration: const InputDecoration(
                  hintText: 'Describe any challenges or blockers...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              
              // Next Week Plan
              const Text(
                'Next Week Plan *',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _nextWeekPlanController,
                decoration: const InputDecoration(
                  hintText: 'What is planned for next week?',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (v) => v?.isEmpty == true ? 'Required' : null,
              ),
              const SizedBox(height: 24),
              
              // Task Stats Card
              Card(
                elevation: 2,
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Task Statistics (Auto-loaded)',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _buildStatCard('Completed', _tasksCompleted, Colors.green),
                          const SizedBox(width: 8),
                          _buildStatCard('In Progress', _tasksInProgress, Colors.orange),
                          const SizedBox(width: 8),
                          _buildStatCard('Blocked', _tasksBlocked, Colors.red),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Text('Current Progress:'),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Slider(
                              value: _currentProgress,
                              onChanged: (v) => setState(() => _currentProgress = v),
                              min: 0,
                              max: 100,
                              divisions: 20,
                              label: '${_currentProgress.toInt()}%',
                            ),
                          ),
                          Text('${_currentProgress.toInt()}%'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Submit Button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isSubmitting ? null : _submitUpdate,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: _isSubmitting
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Submit Weekly Update', style: TextStyle(fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildStatCard(String title, int value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              value.toString(),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
            ),
            Text(title, style: TextStyle(fontSize: 11, color: color)),
          ],
        ),
      ),
    );
  }
}