double calculateScore(Map<String, dynamic> scores) {
  final e = (scores['environment'] ?? 0).toDouble();
  final en = (scores['energy'] ?? 0).toDouble();
  final w = (scores['waste'] ?? 0).toDouble();
  final c = (scores['community'] ?? 0).toDouble();
  final i = (scores['innovation'] ?? 0).toDouble();

  double baseScore =
      (0.3 * e) +
      (0.2 * en) +
      (0.2 * w) +
      (0.2 * c) +
      (0.1 * i);

  return applySmartRules(baseScore, scores);
}

// 🔥 AI-LIKE LOGIC
double applySmartRules(double score, Map<String, dynamic> scores) {

  if (scores['energy'] > 80 && scores['environment'] > 80) {
    score += 5;
  }

  if (scores['waste'] < 40) {
    score -= 5;
  }

  return score.clamp(0, 100);
}