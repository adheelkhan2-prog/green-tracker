// ignore_for_file: avoid_print, invalid_return_type_for_catch_error, unnecessary_brace_in_string_interps

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AIDifficultyService {
  
  /// Calculate task difficulty based on multiple factors
  static Future<int> calculateDifficulty({
    required String title,
    required String description,
    required DateTime deadline,
    required String projectId,
  }) async {
    int difficulty = 1;
    List<String> reasons = [];
    
    try {
      // Factor 1: Task title length and complexity
      if (title.length > 50) {
        difficulty += 1;
        reasons.add('Long task title indicates complexity');
      }
      if (title.contains(RegExp(r'develop|implement|create|build|design|configure|setup|integrate', caseSensitive: false))) {
        difficulty += 2;
        reasons.add('Development/creation task requires more effort');
      }
      if (title.contains(RegExp(r'research|analyze|evaluate|assess|review', caseSensitive: false))) {
        difficulty += 1;
        reasons.add('Research/analysis task requires critical thinking');
      }
      
      // Factor 2: Description length (more details = more complex)
      if (description.isNotEmpty) {
        if (description.length > 200) {
          difficulty += 1;
          reasons.add('Detailed description suggests multi-step task');
        }
        if (description.length > 500) {
          difficulty += 1;
          reasons.add('Very detailed, likely complex task');
        }
      }
      
      // Factor 3: Deadline urgency
      final daysUntilDeadline = deadline.difference(DateTime.now()).inDays;
      if (daysUntilDeadline < 0) {
        // Already overdue - maximum difficulty impact
        difficulty += 3;
        reasons.add('Task is already overdue');
      } else if (daysUntilDeadline < 3) {
        difficulty += 2;
        reasons.add('Urgent deadline (${daysUntilDeadline} days)');
      } else if (daysUntilDeadline < 7) {
        difficulty += 1;
        reasons.add('Short deadline (${daysUntilDeadline} days)');
      }
      
      // Factor 4: Project context (get project complexity)
      try {
        final projectDoc = await FirebaseFirestore.instance
            .collection('projects')
            .doc(projectId)
            .get();
        
        if (projectDoc.exists) {
          final projectData = projectDoc.data() as Map<String, dynamic>;
          final projectProgress = projectData['progress'] ?? 0;
          final projectTypeId = projectData['projectTypeId'];
          
          // Early stage projects have more uncertainty
          if (projectProgress < 30) {
            difficulty += 1;
            reasons.add('Project in early stage, more unknowns');
          }
          
          // Get project type difficulty multiplier (optional enhancement)
          if (projectTypeId != null && projectTypeId.isNotEmpty) {
            final projectTypeDoc = await FirebaseFirestore.instance
                .collection('project_types')
                .doc(projectTypeId)
                .get();
            if (projectTypeDoc.exists) {
              final typeData = projectTypeDoc.data() as Map<String, dynamic>;
              final typeDifficulty = typeData['difficultyLevel'];
              if (typeDifficulty == 'Advanced' || typeDifficulty == 'Expert') {
                difficulty += 1;
                reasons.add('Complex project type requires advanced skills');
              }
            }
          }
        }
      } catch (e) {
        print('Error fetching project context: $e');
        // Continue without project context - don't fail the calculation
      }
      
      // Factor 5: Keywords that indicate difficulty
      final hardKeywords = ['complex', 'difficult', 'challenging', 'critical', 'urgent', 'important'];
      final hardMatches = hardKeywords.where((k) => 
        title.toLowerCase().contains(k) || description.toLowerCase().contains(k)
      ).length;
      difficulty += hardMatches;
      if (hardMatches > 0) {
        reasons.add('Contains ${hardMatches} difficulty indicator(s)');
      }
      
      // Factor 6: Task type keywords
      final easyKeywords = ['simple', 'quick', 'easy', 'basic', 'routine'];
      final easyMatches = easyKeywords.where((k) => 
        title.toLowerCase().contains(k) || description.toLowerCase().contains(k)
      ).length;
      if (easyMatches > 0) {
        difficulty = (difficulty - easyMatches).clamp(1, 10);
        reasons.add('Contains easy task indicator(s) (-${easyMatches})');
      }
      
      // Cap at 10, minimum 1
      difficulty = difficulty.clamp(1, 10);
      
      // Store difficulty reason for transparency (fire and forget - don't await)
      FirebaseFirestore.instance.collection('ai_analysis').add({
        'title': title,
        'difficulty': difficulty,
        'reasons': reasons,
        'analyzedAt': FieldValue.serverTimestamp(),
        'projectId': projectId,
        'deadline': Timestamp.fromDate(deadline),
      }).catchError((e) => print('Failed to store analysis: $e'));
      
    } catch (e) {
      print('Error calculating difficulty: $e');
      // Return default difficulty on error
      difficulty = 5;
    }
    
    return difficulty;
  }
  
  /// Get color for difficulty level
  static Color getDifficultyColor(int difficulty) {
    if (difficulty <= 3) return Colors.green;
    if (difficulty <= 5) return Colors.lightGreen;
    if (difficulty <= 6) return Colors.orange;
    if (difficulty <= 8) return Colors.deepOrange;
    return Colors.red;
  }
  
  /// Get label for difficulty level
  static String getDifficultyLabel(int difficulty) {
    if (difficulty <= 2) return 'Very Easy';
    if (difficulty <= 3) return 'Easy';
    if (difficulty <= 5) return 'Moderate';
    if (difficulty <= 7) return 'Challenging';
    if (difficulty <= 9) return 'Difficult';
    return 'Very Difficult';
  }
  
  /// Get estimated hours based on difficulty
  static int getEstimatedHours(int difficulty) {
    switch (difficulty) {
      case 1: return 2;
      case 2: return 4;
      case 3: return 6;
      case 4: return 8;
      case 5: return 12;
      case 6: return 16;
      case 7: return 20;
      case 8: return 24;
      case 9: return 30;
      case 10: return 40;
      default: return difficulty * 2;
    }
  }
  
  /// Get difficulty icon
  static IconData getDifficultyIcon(int difficulty) {
    if (difficulty <= 3) return Icons.sentiment_satisfied;
    if (difficulty <= 6) return Icons.sentiment_neutral;
    if (difficulty <= 8) return Icons.sentiment_dissatisfied;
    return Icons.warning;
  }
  
  /// Get progress recommendation based on difficulty and days left
  static int getRecommendedProgress(int difficulty, int daysLeft) {
    if (daysLeft <= 0) return 100;
    final baseProgress = (100 / daysLeft) * (difficulty / 5);
    return baseProgress.toInt().clamp(0, 100);
  }
}