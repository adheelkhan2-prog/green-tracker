// lib/services/ai_photo_analysis.dart
// ignore_for_file: unnecessary_brace_in_string_interps

import 'package:flutter/material.dart';

class PhotoAnalysisResult {
  final String detectedObject;
  final String suggestedStatus;
  final double confidence;
  final List<String> keywords;
  final String message;
  final Color statusColor;
  
  PhotoAnalysisResult({
    required this.detectedObject,
    required this.suggestedStatus,
    required this.confidence,
    required this.keywords,
    required this.message,
    required this.statusColor,
  });
}

class AIPhotoAnalysis {
  
  /// Analyze photo and suggest task status based on what's detected
  static Future<PhotoAnalysisResult> analyzePhoto({
    required String imageUrl,
    required String taskTitle,
    required String taskDescription,
  }) async {
    // This is a smart rule-based analysis
    // For true AI, you would call an image recognition API like:
    // - Google Cloud Vision API
    // - Firebase ML Kit
    // - Custom trained model
    
    // For now, we use keyword matching from task context
    // The task title/description tells us what to look for
    
    final lowerTitle = taskTitle.toLowerCase();
    final lowerDesc = taskDescription.toLowerCase();
    
    // Detect what the task is about
    List<String> expectedKeywords = [];
    String suggestedStatus = 'pending_review';
    String detectedObject = 'documentation';
    double confidence = 0.5;
    String message = '';
    Color statusColor = Colors.orange;
    
    // TASK TYPE DETECTION based on title/description
    if (lowerTitle.contains('sign') || lowerDesc.contains('sign')) {
      expectedKeywords = ['sign', 'board', 'poster', 'installed', 'placed'];
      detectedObject = 'signage';
      suggestedStatus = 'completed';
      confidence = 0.75;
      message = '✅ Signage detected! Ready for review.';
      statusColor = Colors.green;
    }
    else if (lowerTitle.contains('install') || lowerDesc.contains('installation')) {
      expectedKeywords = ['installed', 'mounted', 'placed', 'setup', 'complete'];
      detectedObject = 'installation';
      suggestedStatus = 'completed';
      confidence = 0.70;
      message = '🔧 Installation evidence received. Pending verification.';
      statusColor = Colors.blue;
    }
    else if (lowerTitle.contains('report') || lowerDesc.contains('document')) {
      expectedKeywords = ['report', 'document', 'pdf', 'file', 'submitted'];
      detectedObject = 'documentation';
      suggestedStatus = 'completed';
      confidence = 0.80;
      message = '📄 Documentation submitted. Reviewing content.';
      statusColor = Colors.purple;
    }
    else if (lowerTitle.contains('meeting') || lowerDesc.contains('meeting')) {
      expectedKeywords = ['meeting', 'minutes', 'attendance', 'group', 'team'];
      detectedObject = 'meeting_evidence';
      suggestedStatus = 'completed';
      confidence = 0.65;
      message = '👥 Meeting evidence received.';
      statusColor = Colors.teal;
    }
    else if (lowerTitle.contains('clean') || lowerDesc.contains('cleanup')) {
      expectedKeywords = ['clean', 'cleaned', 'trash', 'garbage', 'waste', 'area'];
      detectedObject = 'cleaning_evidence';
      suggestedStatus = 'completed';
      confidence = 0.85;
      message = '🧹 Cleanup activity documented! Great work.';
      statusColor = Colors.green;
    }
    else if (lowerTitle.contains('plant') || lowerDesc.contains('tree')) {
      expectedKeywords = ['plant', 'tree', 'seedling', 'garden', 'green'];
      detectedObject = 'planting_evidence';
      suggestedStatus = 'completed';
      confidence = 0.80;
      message = '🌱 Planting evidence detected! Nature is happy.';
      statusColor = Colors.green;
    }
    else if (lowerTitle.contains('survey') || lowerDesc.contains('feedback')) {
      expectedKeywords = ['survey', 'feedback', 'response', 'form', 'completed'];
      detectedObject = 'survey_evidence';
      suggestedStatus = 'completed';
      confidence = 0.70;
      message = '📊 Survey evidence submitted.';
      statusColor = Colors.orange;
    }
    else if (lowerTitle.contains('design') || lowerDesc.contains('sketch')) {
      expectedKeywords = ['design', 'sketch', 'drawing', 'blueprint', 'plan'];
      detectedObject = 'design_document';
      suggestedStatus = 'in_progress';
      confidence = 0.60;
      message = '🎨 Design work in progress. Review and provide feedback.';
      statusColor = Colors.blue;
    }
    else {
      // Default: Generic evidence upload
      expectedKeywords = ['evidence', 'proof', 'photo', 'image', 'completed'];
      detectedObject = 'general_evidence';
      suggestedStatus = 'pending_review';
      confidence = 0.55;
      message = '📎 Evidence uploaded. Awaiting team leader review.';
      statusColor = Colors.orange;
    }
    
    return PhotoAnalysisResult(
      detectedObject: detectedObject,
      suggestedStatus: suggestedStatus,
      confidence: confidence,
      keywords: expectedKeywords,
      message: message,
      statusColor: statusColor,
    );
  }
  
  /// Get auto-suggested progress percentage based on evidence
  static int getSuggestedProgress(String suggestedStatus, int currentProgress) {
    switch (suggestedStatus) {
      case 'completed':
        return 100;
      case 'pending_review':
        return currentProgress < 80 ? 80 : currentProgress;
      case 'in_progress':
        return currentProgress < 50 ? 50 : currentProgress;
      default:
        return currentProgress;
    }
  }
  
  /// Generate feedback on uploaded evidence
  static String generateFeedback(PhotoAnalysisResult analysis, String taskTitle) {
    if (analysis.confidence > 0.7) {
      return '🎉 Great job on "${taskTitle}"! Your evidence looks solid. ${analysis.message}';
    } else if (analysis.confidence > 0.4) {
      return '📋 Evidence received for "${taskTitle}". ${analysis.message} The team leader will review it soon.';
    } else {
      return '⚠️ We received your submission for "${taskTitle}". Please ensure you\'ve included clear evidence of completion.';
    }
  }
  
  /// Check if evidence is sufficient based on keywords
  static bool isEvidenceSufficient(Map<String, dynamic> taskData, PhotoAnalysisResult analysis) {
    // Check if the task has multiple pieces of evidence
    final evidenceImages = List<String>.from(taskData['evidenceImages'] ?? []);
    final attachments = List<String>.from(taskData['attachments'] ?? []);
    
    if (evidenceImages.length >= 2 || attachments.isNotEmpty) {
      return true;
    }
    
    // Single image with high confidence is also fine
    if (evidenceImages.length == 1 && analysis.confidence > 0.6) {
      return true;
    }
    
    return false;
  }
}

/// ML Kit integration for advanced image recognition (optional)
/// Uncomment and configure if you have Google ML Kit setup
/*
import 'package:google_ml_kit/google_ml_kit.dart';

class MLKitPhotoAnalyzer {
  static Future<Map<String, dynamic>> analyzeWithMLKit(String imagePath) async {
    final inputImage = InputImage.fromFilePath(imagePath);
    final imageLabeler = GoogleMlKit.vision.imageLabeler();
    final List<ImageLabel> labels = await imageLabeler.processImage(inputImage);
    
    await imageLabeler.close();
    
    final detectedLabels = labels.map((label) => label.label.toLowerCase()).toList();
    final confidenceScores = labels.map((label) => label.confidence).toList();
    
    return {
      'labels': detectedLabels,
      'confidence': confidenceScores,
      'topLabel': detectedLabels.isNotEmpty ? detectedLabels.first : 'unknown',
    };
  }
}
*/