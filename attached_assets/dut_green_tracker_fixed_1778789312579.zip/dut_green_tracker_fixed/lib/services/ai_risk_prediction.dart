// lib/services/ai_risk_prediction.dart
// ignore_for_file: curly_braces_in_flow_control_structures, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class RiskPrediction {
  final double riskPercentage;
  final String riskLevel;
  final Color riskColor;
  final String suggestion;
  final int predictedDaysLate;
  
  RiskPrediction({
    required this.riskPercentage,
    required this.riskLevel,
    required this.riskColor,
    required this.suggestion,
    required this.predictedDaysLate,
  });
}

class AIRiskPrediction {
  
  /// Predict risk for a single task
  static Future<RiskPrediction> predictTaskRisk({
    required String taskId,
    required String title,
    required int progress,
    required DateTime deadline,
    required int difficultyLevel,
    required String assignedTo,
  }) async {
    final now = DateTime.now();
    final daysLeft = deadline.difference(now).inDays;
    
    // Calculate risk factors
    double riskScore = 0.0;
    
    // Factor 1: Days left vs progress
    if (daysLeft <= 0) {
      riskScore += 50; // Already overdue
    } else if (daysLeft <= 2) {
      riskScore += 40;
    } else if (daysLeft <= 5) {
      riskScore += 25;
    } else if (daysLeft <= 10) {
      riskScore += 10;
    }
    
    // Factor 2: Progress vs days left
    final expectedProgressPerDay = 100.0 / (daysLeft + 1).clamp(1, 30);
    final currentProgressRate = progress / (now.difference(deadline.subtract(Duration(days: daysLeft))).inDays + 1).clamp(1, 30);
    
    if (currentProgressRate < expectedProgressPerDay * 0.5) {
      riskScore += 30; // Far behind schedule
    } else if (currentProgressRate < expectedProgressPerDay) {
      riskScore += 15; // Slightly behind
    }
    
    // Factor 3: Difficulty level
    if (difficultyLevel >= 8) {
      riskScore += 20;
    } else if (difficultyLevel >= 6) {
      riskScore += 10;
    } else if (difficultyLevel >= 4) {
      riskScore += 5;
    }
    
    // Factor 4: User's past performance (if available)
    final userPerformance = await _getUserPerformance(assignedTo);
    if (userPerformance < 50) {
      riskScore += 15;
    } else if (userPerformance < 70) {
      riskScore += 5;
    }
    
    // Cap at 100
    riskScore = riskScore.clamp(0, 100);
    
    // Determine risk level
    String riskLevel;
    Color riskColor;
    String suggestion;
    int predictedDaysLate = 0;
    
    if (riskScore >= 70) {
      riskLevel = 'High Risk';
      riskColor = Colors.red;
      predictedDaysLate = (daysLeft <= 0 ? 3 : daysLeft + 2).clamp(1, 10);
      suggestion = '⚠️ This task is at high risk of being late. Consider reassigning or getting help from team members.';
    } else if (riskScore >= 40) {
      riskLevel = 'Medium Risk';
      riskColor = Colors.orange;
      predictedDaysLate = (daysLeft <= 0 ? 1 : (daysLeft / 2).ceil()).clamp(0, 5);
      suggestion = '📊 This task needs attention. Focus more time on it to stay on schedule.';
    } else if (riskScore >= 15) {
      riskLevel = 'Low Risk';
      riskColor = Colors.yellow.shade700;
      predictedDaysLate = 0;
      suggestion = '✅ On track, but keep monitoring progress.';
    } else {
      riskLevel = 'Very Low Risk';
      riskColor = Colors.green;
      predictedDaysLate = 0;
      suggestion = '🎯 Great progress! You are well on track to complete on time.';
    }
    
    // Special case: Already completed
    if (progress == 100) {
      riskLevel = 'Completed';
      riskColor = Colors.green;
      riskScore = 0;
      suggestion = '✅ Task completed successfully! Great job!';
      predictedDaysLate = 0;
    }
    
    // Special case: Overdue
    if (daysLeft < 0 && progress < 100) {
      riskLevel = 'Overdue';
      riskColor = Colors.red.shade900;
      riskScore = 95;
      suggestion = '⏰ This task is overdue! Please complete it immediately or request deadline extension.';
      predictedDaysLate = daysLeft.abs();
    }
    
    return RiskPrediction(
      riskPercentage: riskScore,
      riskLevel: riskLevel,
      riskColor: riskColor,
      suggestion: suggestion,
      predictedDaysLate: predictedDaysLate,
    );
  }
  
  /// Get user's historical performance
  static Future<double> _getUserPerformance(String userId) async {
    try {
      final tasksSnapshot = await FirebaseFirestore.instance
          .collection('tasks')
          .where('assignedTo', isEqualTo: userId)
          .where('completedAt', isNotEqualTo: null)
          .limit(10)
          .get();
      
      if (tasksSnapshot.docs.isEmpty) return 70.0; // Default for new users
      
      int onTimeCount = 0;
      for (var doc in tasksSnapshot.docs) {
        final data = doc.data();
        final deadline = (data['deadline'] as Timestamp?)?.toDate();
        final completedAt = (data['completedAt'] as Timestamp?)?.toDate();
        
        if (deadline != null && completedAt != null && completedAt.isBefore(deadline)) {
          onTimeCount++;
        }
      }
      
      return (onTimeCount / tasksSnapshot.docs.length) * 100;
    } catch (e) {
      print('Error getting user performance: $e');
      return 70.0;
    }
  }
  
  /// Get project-level risk summary
  static Future<Map<String, dynamic>> getProjectRiskSummary(String projectId) async {
    final tasksSnapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .where('projectId', isEqualTo: projectId)
        .get();
    
    if (tasksSnapshot.docs.isEmpty) {
      return {
        'totalTasks': 0,
        'highRiskTasks': 0,
        'mediumRiskTasks': 0,
        'lowRiskTasks': 0,
        'overdueTasks': 0,
        'completedTasks': 0,
        'overallRisk': 'No tasks',
        'overallRiskColor': Colors.grey,
      };
    }
    
    int highRisk = 0;
    int mediumRisk = 0;
    int lowRisk = 0;
    int overdue = 0;
    int completed = 0;
    
    for (var doc in tasksSnapshot.docs) {
      final data = doc.data();
      final progress = data['progress'] ?? 0;
      final deadline = (data['deadline'] as Timestamp?)?.toDate();
      final difficulty = data['difficultyLevel'] ?? 1;
      final assignedTo = data['assignedTo'] ?? '';
      
      if (progress == 100) {
        completed++;
        continue;
      }
      
      if (deadline != null && deadline.isBefore(DateTime.now())) {
        overdue++;
        continue;
      }
      
      // Calculate rough risk without full prediction
      final daysLeft = deadline != null ? deadline.difference(DateTime.now()).inDays : 14;
      int risk = 0;
      if (daysLeft <= 2) risk += 40;
      else if (daysLeft <= 5) risk += 20;
      
      if (difficulty >= 7) risk += 20;
      else if (difficulty >= 5) risk += 10;
      
      if (progress < 30 && daysLeft < 7) risk += 20;
      
      if (risk >= 60) highRisk++;
      else if (risk >= 30) mediumRisk++;
      else lowRisk++;
    }
    
    String overallRisk;
    Color overallRiskColor;
    int totalActive = highRisk + mediumRisk + lowRisk + overdue;
    
    if (overdue > 0 || highRisk > 2) {
      overallRisk = 'High Risk';
      overallRiskColor = Colors.red;
    } else if (highRisk > 0 || mediumRisk > 3) {
      overallRisk = 'Medium Risk';
      overallRiskColor = Colors.orange;
    } else if (totalActive > 0) {
      overallRisk = 'Low Risk';
      overallRiskColor = Colors.green;
    } else if (completed > 0 && totalActive == 0) {
      overallRisk = 'All Tasks Completed';
      overallRiskColor = Colors.green;
    } else {
      overallRisk = 'No Active Tasks';
      overallRiskColor = Colors.grey;
    }
    
    return {
      'totalTasks': tasksSnapshot.docs.length,
      'highRiskTasks': highRisk,
      'mediumRiskTasks': mediumRisk,
      'lowRiskTasks': lowRisk,
      'overdueTasks': overdue,
      'completedTasks': completed,
      'overallRisk': overallRisk,
      'overallRiskColor': overallRiskColor,
    };
  }
}