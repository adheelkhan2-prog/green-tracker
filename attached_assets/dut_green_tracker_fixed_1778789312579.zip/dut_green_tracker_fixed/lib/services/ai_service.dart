// ignore_for_file: unnecessary_brace_in_string_interps, prefer_const_declarations, avoid_print

import 'dart:convert';
import 'package:http/http.dart' as http;

class AIService {
  // Get your API key from: https://console.mistral.ai/
  // Sign up with Google/GitHub, verify phone, get free tier (1B tokens/month)
  static const String _apiKey = 'jDcSVuYkM2gAgQfXlT7LBlip16o50hjc';
  static const String _baseUrl = 'https://api.mistral.ai/v1/chat/completions';
  
  // Initialize and test connection
  static Future<bool> testConnection() async {
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'user', 'content': 'Say "AI is working"'}
          ],
          'max_tokens': 50,
        }),
      );
      
      if (response.statusCode == 200) {
        print('✅ Mistral AI Service is ready!');
        return true;
      } else {
        print('❌ Mistral AI test failed: ${response.statusCode}');
        print('Response: ${response.body}');
        return false;
      }
    } catch (e) {
      print('❌ Mistral AI connection error: $e');
      return false;
    }
  }
  
  static Future<Map<String, dynamic>> analyzeProject(Map<String, dynamic> projectData) async {
    final score = (projectData['sustainabilityScore'] ?? 0).toDouble();
    final title = projectData['title'] ?? 'This project';
    final env = (projectData['environment'] ?? 0).toDouble();
    final energy = (projectData['energy'] ?? 0).toDouble();
    final waste = (projectData['waste'] ?? 0).toDouble();
    final community = (projectData['community'] ?? 0).toDouble();
    final innovation = (projectData['innovation'] ?? 0).toDouble();
    final description = projectData['description'] ?? '';
    
    final prompt = '''
Analyze this sustainability project and provide a JSON response only (no markdown, no extra text):

Project Title: "$title"
Description: $description

Sustainability Metrics (0-100):
- Overall Score: $score/100
- Environment: $env/100
- Energy: $energy/100
- Waste: $waste/100
- Community: $community/100
- Innovation: $innovation/100

Respond with this exact JSON structure:
{
  "summary": "2-3 sentence executive summary of project sustainability performance",
  "strengths": ["strength 1", "strength 2", "strength 3"],
  "weaknesses": ["weakness 1", "weakness 2", "weakness 3"],
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"],
  "timeline": "estimated timeline for achieving goals"
}

Keep responses concise, actionable, and specific to the metrics provided.
''';
    
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'user', 'content': prompt}
          ],
          'temperature': 0.7,
          'response_format': {'type': 'json_object'},
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final content = data['choices'][0]['message']['content'];
        
        try {
          final result = jsonDecode(content);
          return {
            'summary': result['summary'] ?? 'Analysis completed successfully.',
            'strengths': List<String>.from(result['strengths'] ?? []),
            'weaknesses': List<String>.from(result['weaknesses'] ?? []),
            'recommendations': List<String>.from(result['recommendations'] ?? []),
            'timeline': result['timeline'] ?? 'Timeline not specified',
          };
        } catch (e) {
          print('JSON parse error: $e');
          return _getFallbackAnalysis(projectData);
        }
      } else {
        print('API error: ${response.statusCode}');
        return _getFallbackAnalysis(projectData);
      }
    } catch (e) {
      print('Network error: $e');
      return _getFallbackAnalysis(projectData);
    }
  }
  
  // NEW METHOD: Predict Impact
  static Future<Map<String, dynamic>> predictImpact(Map<String, dynamic> projectData) async {
    final score = (projectData['sustainabilityScore'] ?? 0).toDouble();
    final title = projectData['title'] ?? 'Project';
    final env = (projectData['environment'] ?? 0).toDouble();
    final energy = (projectData['energy'] ?? 0).toDouble();
    final waste = (projectData['waste'] ?? 0).toDouble();
    final community = (projectData['community'] ?? 0).toDouble();
    final innovation = (projectData['innovation'] ?? 0).toDouble();
    final description = projectData['description'] ?? '';
    
    final prompt = '''
Predict the sustainability impact for this project and provide a JSON response only:

Project Title: "$title"
Description: $description

Current Metrics:
- Sustainability Score: $score/100
- Environment: $env/100
- Energy Efficiency: $energy/100
- Waste Management: $waste/100
- Community Engagement: $community/100
- Innovation Level: $innovation/100

Respond with this exact JSON structure (use realistic numbers based on the metrics):
{
  "carbonReduction": integer (kg CO2 saved annually, range 500-5000),
  "wasteReduction": integer (percentage, range 10-80),
  "energySavings": integer (percentage, range 10-60),
  "waterConservation": integer (liters saved annually, range 5000-50000),
  "communityReach": integer (number of people impacted, range 50-1000),
  "roiTimeline": string (e.g., "6-9 months"),
  "impactScore": integer (0-100, calculated from metrics above),
  "successProbability": integer (0-100, based on metrics),
  "nextSteps": ["step 1", "step 2", "step 3"],
  "risks": ["risk 1", "risk 2", "risk 3"]
}
''';
    
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'user', 'content': prompt}
          ],
          'temperature': 0.7,
          'response_format': {'type': 'json_object'},
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final content = data['choices'][0]['message']['content'];
        
        try {
          final result = jsonDecode(content);
          return {
            'carbonReduction': result['carbonReduction'] ?? (score * 20).toInt(),
            'wasteReduction': result['wasteReduction'] ?? (score * 0.8).toInt(),
            'energySavings': result['energySavings'] ?? (score * 0.6).toInt(),
            'waterConservation': result['waterConservation'] ?? (score * 500).toInt(),
            'communityReach': result['communityReach'] ?? (score * 10).toInt(),
            'roiTimeline': result['roiTimeline'] ?? (score >= 70 ? '6-9 months' : '12-18 months'),
            'impactScore': result['impactScore'] ?? score.toInt(),
            'successProbability': result['successProbability'] ?? score.toInt(),
            'nextSteps': List<String>.from(result['nextSteps'] ?? [
              '📋 Complete baseline assessment',
              '📋 Develop detailed implementation plan',
              '📋 Engage key stakeholders',
            ]),
            'risks': List<String>.from(result['risks'] ?? [
              '⚠️ Resource constraints may affect timeline',
              '⚠️ Stakeholder engagement needs attention',
              '⚠️ Technical implementation challenges possible',
            ]),
          };
        } catch (e) {
          print('JSON parse error in predictImpact: $e');
          return _getFallbackImpact(projectData);
        }
      } else {
        print('API error in predictImpact: ${response.statusCode}');
        return _getFallbackImpact(projectData);
      }
    } catch (e) {
      print('Network error in predictImpact: $e');
      return _getFallbackImpact(projectData);
    }
  }
  
  static Future<String> compareProjects(List<Map<String, dynamic>> projects) async {
    final projectsText = projects.asMap().entries.map((entry) {
      final p = entry.value;
      final score = (p['sustainabilityScore'] ?? 0).toDouble();
      return 'Project ${entry.key + 1}: ${p['title']} - Score: ${score.toStringAsFixed(1)}/100, Environment: ${p['environment']}/100, Community: ${p['community']}/100, Progress: ${p['progress']}%';
    }).join('\n');
    
    final prompt = '''
Compare these sustainability projects and provide a detailed analysis:

$projectsText

Provide ranking from best to worst with reasoning for each. Include:
1. Overall ranking with scores
2. Key strengths of top performer
3. Specific recommendations for improvement
4. Estimated impact potential

Respond in markdown format with emojis for readability.
''';
    
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'user', 'content': prompt}
          ],
          'temperature': 0.7,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices'][0]['message']['content'];
      }
      return _getFallbackComparison(projects);
    } catch (e) {
      print('Comparison error: $e');
      return _getFallbackComparison(projects);
    }
  }
  
  static Future<List<String>> getSustainabilityTips(String category) async {
    final prompt = 'Give 5 specific sustainability tips for "$category" as a JSON array of strings. Example: ["tip 1", "tip 2", ...]';
    
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'user', 'content': prompt}
          ],
          'temperature': 0.8,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final content = data['choices'][0]['message']['content'];
        try {
          return List<String>.from(jsonDecode(content));
        } catch (e) {
          return _fallbackTips(category);
        }
      }
      return _fallbackTips(category);
    } catch (e) {
      return _fallbackTips(category);
    }
  }
  
  static Future<String> getPersonalizedFeedback(String userId) async {
    final prompt = '''
Generate personalized sustainability feedback for a student. 
Be encouraging and provide specific actionable suggestions.
3-4 sentences maximum.
''';
    
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'user', 'content': prompt}
          ],
          'temperature': 0.7,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices'][0]['message']['content'];
      }
      return 'Continue making progress on your sustainability journey! Every task completed makes a difference. 🌍';
    } catch (e) {
      return 'Keep up the great work! Focus on completing your assigned tasks and submitting evidence. 🌱';
    }
  }
  
  // ==================== NEW METHODS FOR CHATBOT ====================
  
  static Future<String> chatWithProjectAI({
    required String userMessage,
    required String projectContext,
    required String tasksContext,
    required String userRole,
    required String projectTitle,
  }) async {
    try {
      final systemPrompt = '''
You are a helpful AI assistant for a project management system called DUT GreenTrack.
The user is a $userRole.

Your capabilities:
- Answer questions about project progress, tasks, and deadlines
- Provide helpful advice and recommendations
- Explain sustainability metrics
- Motivate users to complete their tasks

Current context:
$projectContext
$tasksContext

Guidelines:
- Be friendly and encouraging
- Keep responses concise (2-3 sentences when possible)
- Use emojis occasionally for engagement
- If you don't know something, suggest checking with the project leader
- For deadlines, remind users to check their task list
''';

      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'system', 'content': systemPrompt},
            {'role': 'user', 'content': userMessage}
          ],
          'temperature': 0.7,
          'max_tokens': 500,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices'][0]['message']['content'];
      } else {
        print('Chat API error: ${response.statusCode}');
        return _getFallbackChatResponse(userMessage, userRole, projectTitle);
      }
      
    } catch (e) {
      print('Chat error: $e');
      return 'Sorry, I\'m having trouble connecting right now. Please try again in a moment.';
    }
  }
  
  // ==================== NEW METHOD FOR WEEKLY SUMMARY ====================
  
  static Future<String> generateWeeklySummary({
    required List<Map<String, dynamic>> projects,
    required List<Map<String, dynamic>> tasks,
    required List<Map<String, dynamic>> weeklyUpdates,
    required int totalUsers,
    required int completedTasks,
    required int pendingTasks,
    required int overdueTasks,
  }) async {
    // Prepare data for AI
    final projectsSummary = projects.map((p) {
      return '- ${p['title']}: ${p['progress']}% complete, Status: ${p['status']}, Score: ${p['sustainabilityScore']?.toStringAsFixed(1) ?? 0}/100';
    }).join('\n');
    
    final updatesSummary = weeklyUpdates.take(5).map((u) {
      return '- ${u['projectTitle']}: Week ${u['weekNumber']} - ${u['progressSummary']}';
    }).join('\n');
    
    final prompt = '''
You are an AI assistant for DUT GreenTrack, a project management system. Generate a weekly summary report for the admin.

**Data for this week:**
- Total Projects: ${projects.length}
- Total Users: $totalUsers
- Tasks Completed This Week: $completedTasks
- Tasks In Progress: $pendingTasks
- Overdue Tasks: $overdueTasks

**Projects Overview:**
$projectsSummary

**Recent Weekly Updates from Team Leaders:**
$updatesSummary

**Generate a comprehensive weekly report with:**
1. Executive Summary (2-3 sentences)
2. Key Achievements (3 bullet points)
3. Areas Needing Attention (2-3 bullet points)
4. Risk Alerts (if any overdue tasks > 3)
5. Recommendations for Next Week (3 bullet points)
6. Recognition (top performing project based on sustainability score)

Use emojis for visual appeal. Keep it professional but encouraging.
''';

    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'mistral-large-latest',
          'messages': [
            {'role': 'system', 'content': 'You are a helpful project management assistant.'},
            {'role': 'user', 'content': prompt}
          ],
          'temperature': 0.7,
          'max_tokens': 1000,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices'][0]['message']['content'];
      } else {
        print('Weekly summary API error: ${response.statusCode}');
        return _getFallbackWeeklySummary(projects, overdueTasks, weeklyUpdates);
      }
      
    } catch (e) {
      print('Weekly summary error: $e');
      return _getFallbackWeeklySummary(projects, overdueTasks, weeklyUpdates);
    }
  }
  
  // ==================== FALLBACK METHODS ====================
  
  static Map<String, dynamic> _getFallbackAnalysis(Map<String, dynamic> projectData) {
    final score = (projectData['sustainabilityScore'] ?? 0).toDouble();
    final title = projectData['title'] ?? 'Project';
    
    return {
      'summary': 'Project "$title" shows ${score >= 70 ? 'strong' : (score >= 40 ? 'moderate' : 'needs improvement in')} sustainability performance with a score of ${score.toStringAsFixed(1)}/100.',
      'strengths': [
        'Clear sustainability objectives established',
        'Active stakeholder engagement planned',
        'Measurable impact metrics defined',
      ],
      'weaknesses': [
        'Resource allocation needs optimization',
        'Timeline for key milestones requires adjustment',
        'Risk mitigation strategies need development',
      ],
      'recommendations': [
        'Implement weekly progress tracking system',
        'Schedule monthly stakeholder review meetings',
        'Develop comprehensive communication plan',
      ],
      'timeline': score >= 70 ? '3-4 months' : (score >= 40 ? '6-8 months' : '10-12 months'),
    };
  }
  
  static Map<String, dynamic> _getFallbackImpact(Map<String, dynamic> projectData) {
    final score = (projectData['sustainabilityScore'] ?? 0).toDouble();
    
    return {
      'carbonReduction': (score * 20).toInt(),
      'wasteReduction': (score * 0.8).toInt(),
      'energySavings': (score * 0.6).toInt(),
      'waterConservation': (score * 500).toInt(),
      'communityReach': (score * 10).toInt(),
      'roiTimeline': score >= 70 ? '6-9 months' : '12-18 months',
      'impactScore': score.toInt(),
      'successProbability': score.toInt(),
      'nextSteps': [
        '📋 Complete baseline assessment',
        '📋 Develop detailed implementation plan',
        '📋 Engage key stakeholders early',
      ],
      'risks': [
        '⚠️ Resource constraints may affect timeline',
        '⚠️ Stakeholder engagement needs attention',
        '⚠️ Technical implementation challenges possible',
      ],
    };
  }
  
  static String _getFallbackChatResponse(String message, String userRole, String projectTitle) {
    final lowerMsg = message.toLowerCase();
    
    if (lowerMsg.contains('task') || lowerMsg.contains('assigned')) {
      return '📋 You can view all your tasks in the "My Tasks" tab. Each task has a difficulty level and deadline. Don\'t forget to upload evidence when you complete a task!';
    }
    else if (lowerMsg.contains('deadline') || lowerMsg.contains('due')) {
      return '⏰ Check your task deadlines in the Calendar view. I recommend prioritizing tasks with the closest deadlines and highest difficulty levels.';
    }
    else if (lowerMsg.contains('progress')) {
      return '📊 Project progress is shown as a percentage. Complete your assigned tasks to increase the overall project progress. Each completed task contributes to the final goal!';
    }
    else if (lowerMsg.contains('sustainability') || lowerMsg.contains('green') || lowerMsg.contains('eco')) {
      return '🌱 Sustainability scores are calculated from 5 metrics: Environment, Energy, Waste, Community, and Innovation. Focus on improving lower scores first for the biggest impact!';
    }
    else if (lowerMsg.contains('advice') || lowerMsg.contains('tip') || lowerMsg.contains('recommend')) {
      return '💡 My advice: Break down large tasks into smaller steps, communicate regularly with your team, and update progress daily. Small consistent actions lead to great results!';
    }
    else if (lowerMsg.contains('hello') || lowerMsg.contains('hi')) {
      return '👋 Hello! I\'m your AI assistant for $projectTitle. How can I help you today?';
    }
    else {
      return 'I\'m here to help with your projects! You can ask me about:\n• Your assigned tasks\n• Upcoming deadlines\n• Project progress\n• Sustainability improvements\n• General advice\n\nWhat would you like to know?';
    }
  }
  
  static String _getFallbackComparison(List<Map<String, dynamic>> projects) {
    var result = '## 📊 Project Comparison Results\n\n';
    final sorted = List<Map<String, dynamic>>.from(projects);
    sorted.sort((a, b) => (b['sustainabilityScore'] ?? 0).compareTo(a['sustainabilityScore'] ?? 0));
    
    for (int i = 0; i < sorted.length; i++) {
      final p = sorted[i];
      final score = p['sustainabilityScore'] ?? 0;
      final emoji = score >= 70 ? '🏆' : (score >= 40 ? '📈' : '⚠️');
      result += '### ${i + 1}. $emoji ${p['title']}\n';
      result += '- **Score:** ${score.toStringAsFixed(1)}/100\n';
      result += '- **Progress:** ${p['progress']}%\n';
      result += '- **Key Metric:** Environment: ${p['environment']}/100\n\n';
    }
    
    result += '\n### 🎯 Recommendation\n';
    result += 'Project 1 shows the highest potential for sustainability impact. Focus resources there first.';
    
    return result;
  }
  
  static String _getFallbackWeeklySummary(List<Map<String, dynamic>> projects, int overdueTasks, List<Map<String, dynamic>> weeklyUpdates) {
    final topProject = projects.isNotEmpty 
        ? projects.reduce((a, b) => (a['sustainabilityScore'] ?? 0) > (b['sustainabilityScore'] ?? 0) ? a : b)
        : null;
    
    final atRiskProjects = projects.where((p) {
      final progress = p['progress'] ?? 0;
      final status = p['status']?.toString().toLowerCase() ?? '';
      return progress < 50 && status != 'completed';
    }).length;
    
    return '''
📊 **Weekly Executive Summary**

This week showed ${projects.length} active projects with ${weeklyUpdates.length} team updates submitted. Overall progress is ${atRiskProjects > 0 ? 'mixed' : 'positive'} with ${overdueTasks > 0 ? '$overdueTasks tasks overdue' : 'no overdue tasks'}.

---

🏆 **Key Achievements**
• ${weeklyUpdates.length} weekly updates submitted by team leaders
• ${projects.where((p) => (p['progress'] ?? 0) >= 75).length} projects above 75% completion
• Active engagement across all project teams

⚠️ **Areas Needing Attention**
• ${atRiskProjects} project(s) below 50% completion
• ${overdueTasks} overdue task(s) need immediate review
• Consider additional resources for delayed projects

🚨 **Risk Alerts**
${overdueTasks > 3 
    ? '⚠️ Multiple overdue tasks detected. Schedule review meetings with affected team leaders.'
    : '✅ No major risk alerts. All projects within acceptable parameters.'}

🎯 **Recommendations for Next Week**
• Review progress with team leaders of at-risk projects
• Recognize top performers in weekly meeting
• Schedule deadline extensions for overdue tasks where appropriate

🌟 **Recognition**
🏅 Top Performer: ${topProject != null ? topProject['title'] : 'N/A'} (Sustainability Score: ${topProject != null ? (topProject['sustainabilityScore'] ?? 0).toStringAsFixed(1) : 'N/A'}/100)

---
*This report was AI-generated based on project data and team updates.*
''';
  }
  
  static List<String> _fallbackTips(String category) {
    const tips = {
      'energy': ['💡 Use LED lighting', '🔌 Unplug idle devices', '☀️ Install solar panels', '⚡ Energy-efficient appliances', '🌡️ Optimize thermostat'],
      'waste': ['♻️ Implement recycling', '🗑️ Start composting', '📦 Reduce single-use plastics', '🔄 Donate old equipment', '📝 Go digital'],
      'water': ['💧 Low-flow fixtures', '🌧️ Rainwater collection', '🚰 Fix leaks', '🌱 Drought-resistant plants', '🧺 Full loads only'],
      'community': ['👥 Start a green club', '📢 Host events', '🤝 Partner with NGOs', '📚 Educational workshops', '🏆 Green competition'],
    };
    return tips[category] ?? tips['community']!;
  }
}