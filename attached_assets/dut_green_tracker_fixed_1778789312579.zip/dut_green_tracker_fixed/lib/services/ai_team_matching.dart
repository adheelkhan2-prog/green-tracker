// lib/services/ai_team_matching.dart
// ignore_for_file: prefer_is_empty

import 'package:cloud_firestore/cloud_firestore.dart';

class TeamMemberScore {
  final String userId;
  final String userName;
  final String userRole;
  final double score;
  final int completedTasks;
  final int currentTasks;
  final double avgPerformance;
  final List<String> strengths;
  final String recommendation;
  
  TeamMemberScore({
    required this.userId,
    required this.userName,
    required this.userRole,
    required this.score,
    required this.completedTasks,
    required this.currentTasks,
    required this.avgPerformance,
    required this.strengths,
    required this.recommendation,
  });
}

class TeamMatchResult {
  final List<TeamMemberScore> topMatches;
  final String summary;
  final String bestRecommendation;
  
  TeamMatchResult({
    required this.topMatches,
    required this.summary,
    required this.bestRecommendation,
  });
}

class SmartTeamMatching {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  /// Get all team members for a project with their scores
  Future<List<TeamMemberScore>> getTeamMemberScores({
    required String projectId,
    required String taskTitle,
    required String taskDescription,
    required int difficultyLevel,
  }) async {
    final scores = <TeamMemberScore>[];
    
    // Get project members
    final projectDoc = await _firestore.collection('projects').doc(projectId).get();
    final memberIds = List<String>.from(projectDoc.data()?['members'] ?? []);
    final leaderId = projectDoc.data()?['leaderId'];
    
    // Include leader if not already in members
    if (leaderId != null && !memberIds.contains(leaderId)) {
      memberIds.add(leaderId);
    }
    
    for (String userId in memberIds) {
      final score = await _calculateMemberScore(
        userId: userId,
        taskTitle: taskTitle,
        taskDescription: taskDescription,
        difficultyLevel: difficultyLevel,
      );
      scores.add(score);
    }
    
    // Sort by score descending
    scores.sort((a, b) => b.score.compareTo(a.score));
    
    return scores;
  }
  
  /// Calculate individual member score
  Future<TeamMemberScore> _calculateMemberScore({
    required String userId,
    required String taskTitle,
    required String taskDescription,
    required int difficultyLevel,
  }) async {
    // Get user data
    final userDoc = await _firestore.collection('users').doc(userId).get();
    final userName = userDoc.data()?['name'] ?? 'Unknown';
    final userRole = userDoc.data()?['role'] ?? 'member';
    
    // Get user's task history
    final tasksSnapshot = await _firestore
        .collection('tasks')
        .where('assignedTo', isEqualTo: userId)
        .get();
    
    int completedTasks = 0;
    int totalTasks = tasksSnapshot.docs.length;
    double totalPerformance = 0;
    List<String> strengths = [];
    Map<String, int> taskTypeCount = {};
    
    for (var doc in tasksSnapshot.docs) {
      final data = doc.data();
      final progress = data['progress'] ?? 0;
      final difficulty = data['difficultyLevel'] ?? 1;
      final deadline = (data['deadline'] as Timestamp?)?.toDate();
      final completedAt = (data['completedAt'] as Timestamp?)?.toDate();
      
      if (progress == 100) {
        completedTasks++;
        
        // Calculate performance based on deadline
        if (deadline != null && completedAt != null) {
          if (completedAt.isBefore(deadline)) {
            totalPerformance += 1.0; // Early/on time
          } else if (completedAt.isAfter(deadline)) {
            totalPerformance += 0.5; // Late but completed
          }
        } else {
          totalPerformance += 0.8;
        }
        
        // Track task types for strengths
        final title = data['title']?.toLowerCase() ?? '';
        if (title.contains('design') || title.contains('plan')) {
          taskTypeCount['design'] = (taskTypeCount['design'] ?? 0) + 1;
        }
        if (title.contains('report') || title.contains('document')) {
          taskTypeCount['documentation'] = (taskTypeCount['documentation'] ?? 0) + 1;
        }
        if (title.contains('install') || title.contains('setup')) {
          taskTypeCount['technical'] = (taskTypeCount['technical'] ?? 0) + 1;
        }
        if (title.contains('meeting') || title.contains('coordinate')) {
          taskTypeCount['coordination'] = (taskTypeCount['coordination'] ?? 0) + 1;
        }
        if (title.contains('research') || title.contains('analyze')) {
          taskTypeCount['analysis'] = (taskTypeCount['analysis'] ?? 0) + 1;
        }
      }
    }
    
    // Calculate average performance
    final avgPerformance = completedTasks > 0 
        ? (totalPerformance / completedTasks) * 100 
        : 50.0;
    
    // Get current active tasks
    final currentTasks = tasksSnapshot.docs.where((doc) {
      final progress = doc.data()['progress'] ?? 0;
      return progress > 0 && progress < 100;
    }).length;
    
    // Determine strengths
    if (taskTypeCount.isNotEmpty) {
      final sortedTypes = taskTypeCount.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      if (sortedTypes.isNotEmpty) {
        strengths.add(_getStrengthLabel(sortedTypes.first.key));
      }
    }
    if (avgPerformance > 80) {
      strengths.add('High performer');
    }
    if (completedTasks > 10) {
      strengths.add('Experienced');
    }
    if (strengths.isEmpty) {
      strengths.add('Reliable team member');
    }
    
    // Calculate match score for this specific task
    double matchScore = 0;
    
    // Factor 1: Past performance (30%)
    matchScore += (avgPerformance / 100) * 30;
    
    // Factor 2: Experience with similar tasks (25%)
    double experienceBonus = 0;
    final taskTitleLower = taskTitle.toLowerCase();
    final taskDescLower = taskDescription.toLowerCase();
    
    if (taskTitleLower.contains('design') && (taskTypeCount['design'] ?? 0) > 0) {
      experienceBonus = 25;
    } else if (taskTitleLower.contains('report') && (taskTypeCount['documentation'] ?? 0) > 0) {
      experienceBonus = 25;
    } else if (taskTitleLower.contains('install') && (taskTypeCount['technical'] ?? 0) > 0) {
      experienceBonus = 25;
    } else if (taskTitleLower.contains('meeting') && (taskTypeCount['coordination'] ?? 0) > 0) {
      experienceBonus = 25;
    } else if (completedTasks > 5) {
      experienceBonus = 15;
    } else {
      experienceBonus = 5;
    }
    matchScore += experienceBonus;
    
    // Factor 3: Current workload (20%)
    double workloadScore = 0;
    if (currentTasks == 0) {
      workloadScore = 20;
    } else if (currentTasks <= 2) {
      workloadScore = 15;
    } else if (currentTasks <= 4) {
      workloadScore = 10;
    } else if (currentTasks <= 6) {
      workloadScore = 5;
    } else {
      workloadScore = 0;
    }
    matchScore += workloadScore;
    
    // Factor 4: Difficulty level match (15%)
    double difficultyScore = 0;
    if (difficultyLevel <= 3) {
      difficultyScore = 15; // Easy task, anyone can do
    } else if (difficultyLevel <= 6) {
      difficultyScore = avgPerformance > 60 ? 15 : 10;
    } else {
      difficultyScore = avgPerformance > 70 ? 15 : 5;
    }
    matchScore += difficultyScore;
    
    // Factor 5: Task completion rate (10%)
    final completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
    matchScore += (completionRate / 100) * 10;
    
    // Cap at 100
    matchScore = matchScore.clamp(0, 100);
    
    // Generate recommendation
    String recommendation;
    if (matchScore >= 85) {
      recommendation = '🎯 Excellent match! This member has proven experience and is ready for this task.';
    } else if (matchScore >= 70) {
      recommendation = '👍 Good match. This member has relevant skills and available bandwidth.';
    } else if (matchScore >= 50) {
      recommendation = '📊 Decent match. Consider pairing with a more experienced member for guidance.';
    } else {
      recommendation = '⚠️ Low match. This member may struggle with this task. Consider training or reassignment.';
    }
    
    return TeamMemberScore(
      userId: userId,
      userName: userName,
      userRole: userRole,
      score: matchScore,
      completedTasks: completedTasks,
      currentTasks: currentTasks,
      avgPerformance: avgPerformance,
      strengths: strengths,
      recommendation: recommendation,
    );
  }
  
  /// Get AI-powered team matching recommendation
  Future<TeamMatchResult> getSmartTeamMatch({
    required String projectId,
    required String taskTitle,
    required String taskDescription,
    required int difficultyLevel,
  }) async {
    final scores = await getTeamMemberScores(
      projectId: projectId,
      taskTitle: taskTitle,
      taskDescription: taskDescription,
      difficultyLevel: difficultyLevel,
    );
    
    if (scores.isEmpty) {
      return TeamMatchResult(
        topMatches: [],
        summary: 'No team members available. Add members to the project first.',
        bestRecommendation: 'Please add team members before assigning tasks.',
      );
    }
    
    final topMatches = scores.take(3).toList();
    final bestMatch = topMatches.isNotEmpty ? topMatches.first : null;
    
    String summary;
    if (bestMatch != null && bestMatch.score >= 85) {
      summary = '🎯 Found an excellent match! ${bestMatch.userName} is highly recommended for this task with a ${bestMatch.score.toInt()}% match score.';
    } else if (bestMatch != null && bestMatch.score >= 70) {
      summary = '👍 ${bestMatch.userName} is a good match for this task (${bestMatch.score.toInt()}% match). They have relevant experience and available bandwidth.';
    } else if (bestMatch != null) {
      summary = '📊 ${bestMatch.userName} is the best available option (${bestMatch.score.toInt()}% match). Consider providing additional guidance or pairing with another member.';
    } else {
      summary = 'No team members available for this task.';
    }
    
    final bestRecommendation = bestMatch != null 
        ? 'Recommended: Assign this task to ${bestMatch.userName} (${bestMatch.score.toInt()}% match)\n\nReason: ${bestMatch.recommendation}'
        : 'No recommendation available.';
    
    return TeamMatchResult(
      topMatches: topMatches,
      summary: summary,
      bestRecommendation: bestRecommendation,
    );
  }
  
  /// Get workload summary for all team members
  Future<Map<String, dynamic>> getTeamWorkloadSummary(String projectId) async {
    final projectDoc = await _firestore.collection('projects').doc(projectId).get();
    final memberIds = List<String>.from(projectDoc.data()?['members'] ?? []);
    final leaderId = projectDoc.data()?['leaderId'];
    
    if (leaderId != null && !memberIds.contains(leaderId)) {
      memberIds.add(leaderId);
    }
    
    int totalMembers = memberIds.length;
    int overloadedMembers = 0;
    int underutilizedMembers = 0;
    List<Map<String, dynamic>> memberWorkloads = [];
    
    for (String userId in memberIds) {
      final userDoc = await _firestore.collection('users').doc(userId).get();
      final userName = userDoc.data()?['name'] ?? 'Unknown';
      
      final tasksSnapshot = await _firestore
          .collection('tasks')
          .where('assignedTo', isEqualTo: userId)
          .get();
      
      final activeTasks = tasksSnapshot.docs.where((doc) {
        final progress = doc.data()['progress'] ?? 0;
        return progress > 0 && progress < 100;
      }).length;
      
      final completedTasks = tasksSnapshot.docs.where((doc) {
        final progress = doc.data()['progress'] ?? 0;
        return progress == 100;
      }).length;
      
      memberWorkloads.add({
        'userId': userId,
        'name': userName,
        'activeTasks': activeTasks,
        'completedTasks': completedTasks,
        'totalTasks': tasksSnapshot.docs.length,
      });
      
      if (activeTasks >= 5) {
        overloadedMembers++;
      } else if (activeTasks == 0 && tasksSnapshot.docs.length > 0) {
        underutilizedMembers++;
      }
    }
    
    // Sort by active tasks (most overloaded first)
    memberWorkloads.sort((a, b) => b['activeTasks'].compareTo(a['activeTasks']));
    
    return {
      'totalMembers': totalMembers,
      'overloadedMembers': overloadedMembers,
      'underutilizedMembers': underutilizedMembers,
      'memberWorkloads': memberWorkloads,
      'recommendation': overloadedMembers > 0 
          ? '⚠️ $overloadedMembers team member(s) are overloaded. Consider redistributing tasks.'
          : '✅ Team workload is balanced. Good distribution of tasks.',
    };
  }
  
  String _getStrengthLabel(String type) {
    switch (type) {
      case 'design':
        return '🎨 Design & Planning';
      case 'documentation':
        return '📝 Documentation';
      case 'technical':
        return '🔧 Technical Skills';
      case 'coordination':
        return '🤝 Coordination';
      case 'analysis':
        return '📊 Analysis';
      default:
        return '💪 Reliable';
    }
  }
}

// Singleton instance
final smartTeamMatching = SmartTeamMatching();