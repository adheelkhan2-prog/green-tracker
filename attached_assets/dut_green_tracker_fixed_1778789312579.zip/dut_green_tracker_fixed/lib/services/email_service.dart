// lib/services/email_service.dart
// ignore_for_file: prefer_const_constructors, avoid_print, prefer_final_fields

import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';

class EmailService {
  // Email configuration - Replace with your actual email
  static const String _smtpUsername = 'your_email@gmail.com';
  static const String _smtpPassword = 'your_app_password';
  
  static bool _emailEnabled = true; // Set to true when configured
  
  static Future<void> _sendEmail({
    required String toEmail,
    required String toName,
    required String subject,
    required String htmlContent,
  }) async {
    if (!_emailEnabled || toEmail.isEmpty) {
      print('📧 Email skipped (not configured or no email)');
      return;
    }
    
    try {
      final smtpServer = gmail(_smtpUsername, _smtpPassword);
      
      final message = Message()
        ..from = Address(_smtpUsername, 'DUT GreenTrack')
        ..recipients.add(Address(toEmail, toName))
        ..subject = subject
        ..html = htmlContent;
      
      await send(message, smtpServer);
      print('✅ Email sent to $toEmail');
    } catch (e) {
      print('❌ Email failed (non-fatal): $e');
    }
  }

  static Future<void> sendTaskAssignmentEmail({
    required String toEmail,
    required String toName,
    required String taskTitle,
    required String projectTitle,
    required String deadline,
    required int difficulty,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #4CAF50; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .task-details { background: #f5f5f5; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .badge { display: inline-block; padding: 3px 8px; border-radius: 12px; font-size: 12px; }
        .badge-easy { background: #4CAF50; color: white; }
        .badge-moderate { background: #FF9800; color: white; }
        .badge-hard { background: #f44336; color: white; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
        .button { display: inline-block; padding: 10px 20px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>New Task Assignment</p>
      </div>
      <div class="content">
        <h3>Hello $toName,</h3>
        <p>You have been assigned a new task in <strong>$projectTitle</strong>.</p>
        
        <div class="task-details">
          <h3>📋 Task: $taskTitle</h3>
          <p><strong>Difficulty:</strong> <span class="badge ${_getDifficultyClass(difficulty)}">${_getDifficultyLabel(difficulty)}</span> (Level $difficulty/10)</p>
          <p><strong>Deadline:</strong> 📅 $deadline</p>
        </div>
        
        <p>Please log in to the app to view and complete this task.</p>
        <p>Don't forget to upload evidence when you complete the task!</p>
        
        <p style="margin-top: 20px;">
          <a href="#" class="button">Open App</a>
        </p>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '📋 New Task Assigned: $taskTitle',
      htmlContent: htmlContent,
    );
  }
  
  static Future<void> sendTaskCompletedEmail({
    required String toEmail,
    required String toName,
    required String taskTitle,
    required String projectTitle,
    required String completedByName,
    required int evidenceCount,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #4CAF50; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .completion-box { background: #e8f5e9; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #4CAF50; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>Task Completed! 🎉</p>
      </div>
      <div class="content">
        <h3>Hello $toName,</h3>
        <div class="completion-box">
          <p><strong>$completedByName</strong> has completed:</p>
          <h3>✅ $taskTitle</h3>
          <p><strong>Project:</strong> $projectTitle</p>
          <p><strong>Evidence uploaded:</strong> $evidenceCount file(s)</p>
        </div>
        <p>Log in to the app to review the evidence and provide feedback.</p>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '✅ Task Completed: $taskTitle',
      htmlContent: htmlContent,
    );
  }
  
  static Future<void> sendProjectAssignmentEmail({
    required String toEmail,
    required String toName,
    required String projectTitle,
    required String description,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #2196F3; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .project-box { background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #2196F3; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>Project Assigned to You</p>
      </div>
      <div class="content">
        <h3>Hello $toName,</h3>
        <p>You have been assigned as <strong>Team Leader</strong> for:</p>
        
        <div class="project-box">
          <h3>📁 $projectTitle</h3>
          <p>$description</p>
        </div>
        
        <p>As Team Leader, you can:</p>
        <ul>
          <li>Manage your team members</li>
          <li>Assign tasks to team members</li>
          <li>Submit weekly updates</li>
          <li>Track project progress</li>
        </ul>
        
        <p>Log in to the app to start managing this project.</p>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '📁 Project Assigned: $projectTitle',
      htmlContent: htmlContent,
    );
  }
  
  static Future<void> sendMemberAddedEmail({
    required String toEmail,
    required String toName,
    required String teamName,
    required String projectTitle,
    required String addedByName,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #9C27B0; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .info-box { background: #f3e5f5; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #9C27B0; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>You've Been Added to a Team! 🎉</p>
      </div>
      <div class="content">
        <h3>Hello $toName,</h3>
        <div class="info-box">
          <p><strong>$addedByName</strong> has added you to:</p>
          <h3>👥 Team: $teamName</h3>
          <p><strong>Project:</strong> $projectTitle</p>
        </div>
        <p>Log in to the app to see your assigned tasks and collaborate with your team.</p>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '👥 Added to Team: $teamName',
      htmlContent: htmlContent,
    );
  }

  // Add this method to EmailService class in email_service.dart

static Future<void> sendRawEmail({
  required String toEmail,
  required String toName,
  required String subject,
  required String htmlContent,
}) async {
  if (!_emailEnabled || toEmail.isEmpty) {
    print('📧 Email skipped (not configured or no email)');
    return;
  }
  
  try {
    final smtpServer = gmail(_smtpUsername, _smtpPassword);
    
    final message = Message()
      ..from = Address(_smtpUsername, 'DUT GreenTrack')
      ..recipients.add(Address(toEmail, toName))
      ..subject = subject
      ..html = htmlContent;
    
    await send(message, smtpServer);
    print('✅ Email sent to $toEmail');
  } catch (e) {
    print('❌ Email failed (non-fatal): $e');
  }
}
  
  static Future<void> sendWeeklyUpdateReminderEmail({
    required String toEmail,
    required String toName,
    required String projectTitle,
    required int weekNumber,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #FF9800; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .reminder-box { background: #fff3e0; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #FF9800; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>Weekly Update Reminder</p>
      </div>
      <div class="content">
        <h3>Hello $toName,</h3>
        <div class="reminder-box">
          <p>This is a reminder to submit your weekly update for:</p>
          <h3>📊 $projectTitle</h3>
          <p><strong>Week $weekNumber</strong></p>
        </div>
        <p>Please log in to the app and submit your weekly update including:</p>
        <ul>
          <li>Progress summary</li>
          <li>Key achievements</li>
          <li>Challenges faced</li>
          <li>Next week's plan</li>
        </ul>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '📊 Weekly Update Reminder: $projectTitle',
      htmlContent: htmlContent,
    );
  }
  
  static Future<void> sendDeadlineReminderEmail({
    required String toEmail,
    required String toName,
    required String taskTitle,
    required String projectTitle,
    required int daysLeft,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #f44336; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .deadline-box { background: #ffebee; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #f44336; }
        .urgent { color: #f44336; font-weight: bold; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>Deadline Reminder ⏰</p>
      </div>
      <div class="content">
        <h3>Hello $toName,</h3>
        <div class="deadline-box">
          <p>This is a reminder that your task is due soon:</p>
          <h3>📋 $taskTitle</h3>
          <p><strong>Project:</strong> $projectTitle</p>
          <p><strong class="urgent">⚠️ Due in $daysLeft day${daysLeft > 1 ? 's' : ''}</strong></p>
        </div>
        <p>Please log in to update your progress or submit evidence.</p>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '⏰ Deadline Reminder: $taskTitle',
      htmlContent: htmlContent,
    );
  }
  
  static Future<void> sendWelcomeEmail({
    required String toEmail,
    required String toName,
    required String role,
  }) async {
    final htmlContent = '''
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #4CAF50; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .welcome-box { background: #e8f5e9; padding: 15px; border-radius: 8px; margin: 15px 0; text-align: center; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🌱 DUT GreenTrack</h2>
        <p>Welcome to the Platform!</p>
      </div>
      <div class="content">
        <div class="welcome-box">
          <h3>Welcome $toName! 🎉</h3>
          <p>You have been registered as a <strong>$role</strong> on DUT GreenTrack.</p>
        </div>
        <p>Here's what you can do:</p>
        <ul>
          ${role == 'student' ? '<li>View and complete assigned tasks</li><li>Upload evidence for task completion</li><li>Track your project progress</li>' : ''}
          ${role == 'lecturer' ? '<li>Oversee projects as team leader</li><li>Assign tasks to team members</li><li>Submit weekly updates</li>' : ''}
          ${role == 'admin' ? '<li>Manage users and projects</li><li>View analytics dashboard</li><li>Oversee all platform activities</li>' : ''}
        </ul>
        <p>Log in to the app to get started!</p>
      </div>
      <div class="footer">
        <p>DUT GreenTrack - Tracking sustainability one task at a time</p>
      </div>
    </body>
    </html>
    ''';
    
    await _sendEmail(
      toEmail: toEmail,
      toName: toName,
      subject: '🎉 Welcome to DUT GreenTrack!',
      htmlContent: htmlContent,
    );
  }
  
  static String _getDifficultyLabel(int difficulty) {
    if (difficulty <= 3) return 'Easy';
    if (difficulty <= 6) return 'Moderate';
    if (difficulty <= 8) return 'Challenging';
    return 'Difficult';
  }
  
  static String _getDifficultyClass(int difficulty) {
    if (difficulty <= 3) return 'badge-easy';
    if (difficulty <= 6) return 'badge-moderate';
    return 'badge-hard';
  }
}
