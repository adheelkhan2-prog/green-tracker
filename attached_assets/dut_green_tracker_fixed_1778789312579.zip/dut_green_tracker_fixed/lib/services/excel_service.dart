import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ExcelService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<List<Map<String, dynamic>>> pickAndParseExcel() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'xls'],
    );

    if (result != null) {
      final bytes = result.files.first.bytes;
      var excel = Excel.decodeBytes(bytes!);
      
      List<Map<String, dynamic>> projects = [];
      var sheet = excel.tables[excel.tables.keys.first];
      
      for (var row in sheet!.rows.skip(1)) { // Skip header
        if (row[0] != null && row[0]!.value.toString().isNotEmpty) {
          projects.add({
            'title': row[0]?.value.toString() ?? '',
            'description': row[1]?.value.toString() ?? '',
            'projectTypeId': row[2]?.value.toString() ?? '',
            'status': 'pending',
            'progress': 0,
            'createdAt': DateTime.now(),
          });
        }
      }
      
      return projects;
    }
    return [];
  }

  Future<void> uploadMultipleProjects(List<Map<String, dynamic>> projects) async {
    final batch = _db.batch();
    for (var project in projects) {
      final docRef = _db.collection('projects').doc();
      batch.set(docRef, project);
    }
    await batch.commit();
  }
}