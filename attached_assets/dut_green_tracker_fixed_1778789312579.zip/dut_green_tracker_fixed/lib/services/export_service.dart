import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:excel/excel.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ExportService {
  
  // Export project report as PDF
  static Future<void> exportProjectToPDF(Map<String, dynamic> project, List<Map<String, dynamic>> tasks) async {
    final pdf = pw.Document();
    
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return [
            pw.Header(
              level: 0,
              child: pw.Text(
                'Project Report: ${project['title']}',
                style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold),
              ),
            ),
            pw.SizedBox(height: 20),
            
            // Project Details
            pw.Container(
              padding: const pw.EdgeInsets.all(10),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(),
                borderRadius: pw.BorderRadius.circular(5),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Project Details', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16)),
                  pw.SizedBox(height: 10),
                  _buildInfoRow('Project ID:', project['id']),
                  _buildInfoRow('Status:', project['status']),
                  _buildInfoRow('Progress:', '${project['progress']}%'),
                  _buildInfoRow('Created:', (project['createdAt'] as Timestamp?)?.toDate().toString() ?? 'N/A'),
                  pw.SizedBox(height: 5),
                  pw.Text('Description:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.Text(project['description'] ?? 'No description'),
                ],
              ),
            ),
            
            pw.SizedBox(height: 20),
            
            // Sustainability Metrics
            pw.Container(
              padding: const pw.EdgeInsets.all(10),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(),
                borderRadius: pw.BorderRadius.circular(5),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Sustainability Metrics', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16)),
                  pw.SizedBox(height: 10),
                  _buildInfoRow('Environmental Impact:', '${project['scores']?['environment'] ?? 0}%'),
                  _buildInfoRow('Energy Efficiency:', '${project['scores']?['energy'] ?? 0}%'),
                  _buildInfoRow('Waste Management:', '${project['scores']?['waste'] ?? 0}%'),
                  _buildInfoRow('Community Engagement:', '${project['scores']?['community'] ?? 0}%'),
                  _buildInfoRow('Innovation Level:', '${project['scores']?['innovation'] ?? 0}%'),
                  _buildInfoRow('Overall Score:', '${project['sustainabilityScore'] ?? 0}/100'),
                ],
              ),
            ),
            
            pw.SizedBox(height: 20),
            
            // Tasks
            pw.Text('Tasks (${tasks.length})', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16)),
            pw.SizedBox(height: 10),
            pw.Table(
              border: pw.TableBorder.all(),
              children: [
                pw.TableRow(
                  children: [
                    _buildHeaderCell('Task'),
                    _buildHeaderCell('Difficulty'),
                    _buildHeaderCell('Progress'),
                    _buildHeaderCell('Status'),
                    _buildHeaderCell('Deadline'),
                  ],
                ),
                ...tasks.map((task) => pw.TableRow(
                  children: [
                    _buildCell(task['title']),
                    _buildCell('${task['difficulty']}/10'),
                    _buildCell('${task['progress']}%'),
                    _buildCell(task['status']),
                    _buildCell(task['deadline']?.toString().substring(0, 10) ?? 'N/A'),
                  ],
                )),
              ],
            ),
            
            pw.SizedBox(height: 20),
            
            // Summary
            pw.Container(
              padding: const pw.EdgeInsets.all(10),
              color: PdfColors.grey200,
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Summary', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 5),
                  pw.Text('Total Tasks: ${tasks.length}'),
                  pw.Text('Completed Tasks: ${tasks.where((t) => t['progress'] == 100).length}'),
                  pw.Text('Completion Rate: ${tasks.isEmpty ? 0 : (tasks.where((t) => t['progress'] == 100).length / tasks.length * 100).toStringAsFixed(1)}%'),
                ],
              ),
            ),
          ];
        },
      ),
    );
    
    // Save and share
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final fileName = 'project_report_${project['id']}_$timestamp.pdf';
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/$fileName');
    await file.writeAsBytes(await pdf.save());
    
    await Share.shareXFiles(
      [XFile(file.path)],
      text: 'Project Report: ${project['title']}',
    );
  }
  
  // Export project report as Excel
  static Future<void> exportProjectToExcel(Map<String, dynamic> project, List<Map<String, dynamic>> tasks) async {
    var excel = Excel.createExcel();
    
    // Project Info Sheet
    final projectSheet = excel['Project Info'];
    projectSheet.appendRow([TextCellValue('Project Report')]);
    projectSheet.appendRow([]);
    projectSheet.appendRow([TextCellValue('Project Title'), TextCellValue(project['title'])]);
    projectSheet.appendRow([TextCellValue('Status'), TextCellValue(project['status'])]);
    projectSheet.appendRow([TextCellValue('Progress'), TextCellValue('${project['progress']}%')]);
    projectSheet.appendRow([TextCellValue('Created'), TextCellValue((project['createdAt'] as Timestamp?)?.toDate().toString() ?? 'N/A')]);
    projectSheet.appendRow([TextCellValue('Description'), TextCellValue(project['description'] ?? 'No description')]);
    projectSheet.appendRow([]);
    projectSheet.appendRow([TextCellValue('Sustainability Metrics')]);
    projectSheet.appendRow([TextCellValue('Environmental Impact'), TextCellValue('${project['scores']?['environment'] ?? 0}%')]);
    projectSheet.appendRow([TextCellValue('Energy Efficiency'), TextCellValue('${project['scores']?['energy'] ?? 0}%')]);
    projectSheet.appendRow([TextCellValue('Waste Management'), TextCellValue('${project['scores']?['waste'] ?? 0}%')]);
    projectSheet.appendRow([TextCellValue('Community Engagement'), TextCellValue('${project['scores']?['community'] ?? 0}%')]);
    projectSheet.appendRow([TextCellValue('Innovation Level'), TextCellValue('${project['scores']?['innovation'] ?? 0}%')]);
    projectSheet.appendRow([TextCellValue('Overall Score'), TextCellValue('${project['sustainabilityScore'] ?? 0}/100')]);
    
    // Tasks Sheet
    final tasksSheet = excel['Tasks'];
    tasksSheet.appendRow([TextCellValue('Task Title'), TextCellValue('Difficulty'), TextCellValue('Progress'), TextCellValue('Status'), TextCellValue('Deadline'), TextCellValue('Assigned To')]);
    
    for (var task in tasks) {
      tasksSheet.appendRow([
        TextCellValue(task['title']),
        TextCellValue('${task['difficulty']}/10'),
        TextCellValue('${task['progress']}%'),
        TextCellValue(task['status']),
        TextCellValue(task['deadline']?.toString().substring(0, 10) ?? 'N/A'),
        TextCellValue(task['assignedToName'] ?? 'Unassigned'),
      ]);
    }
    
    // Summary Sheet
    final summarySheet = excel['Summary'];
    summarySheet.appendRow([TextCellValue('Summary Statistics')]);
    summarySheet.appendRow([]);
    summarySheet.appendRow([TextCellValue('Total Tasks'), IntCellValue(tasks.length)]);
    summarySheet.appendRow([TextCellValue('Completed Tasks'), IntCellValue(tasks.where((t) => t['progress'] == 100).length)]);
    summarySheet.appendRow([TextCellValue('In Progress'), IntCellValue(tasks.where((t) => t['progress'] > 0 && t['progress'] < 100).length)]);
    summarySheet.appendRow([TextCellValue('Not Started'), IntCellValue(tasks.where((t) => t['progress'] == 0).length)]);
    summarySheet.appendRow([TextCellValue('Completion Rate'), TextCellValue('${tasks.isEmpty ? 0 : (tasks.where((t) => t['progress'] == 100).length / tasks.length * 100).toStringAsFixed(1)}%')]);
    
    // Save and share
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final fileName = 'project_report_${project['id']}_$timestamp.xlsx';
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/$fileName');
    await file.writeAsBytes(excel.encode()!);
    
    await Share.shareXFiles(
      [XFile(file.path)],
      text: 'Project Report: ${project['title']}',
    );
  }
  
  static pw.Widget _buildInfoRow(String label, String value) {
    return pw.Row(
      children: [
        pw.Text(label, style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(width: 10),
        pw.Text(value),
      ],
    );
  }
  
  static pw.Widget _buildHeaderCell(String text) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      color: PdfColors.grey300,
      child: pw.Text(text, style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
    );
  }
  
  static pw.Widget _buildCell(String text) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(text),
    );
  }
}