// ignore_for_file: unused_import, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dut_green_tracker_fixed/models/notification.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/project.dart';
import '../models/task.dart';
import '../models/team.dart';
import '../models/user.dart';
import '../models/notifications.dart';



class FirebaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // ============ AUTHENTICATION ============
  Future<User?> signIn(String email, String password) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return credential.user;
    } catch (e) {
      print('Login error: $e');
      return null;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ============ USER MANAGEMENT ============
  Future<void> addUser(AppUser user) async {
    await _db.collection('users').doc(user.id).set(user.toMap());
  }

  Stream<List<AppUser>> getUsers() {
    return _db.collection('users').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return AppUser.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Stream<AppUser?> getUser(String userId) {
    return _db.collection('users').doc(userId).snapshots().map((doc) {
      if (doc.exists) {
        return AppUser.fromMap(doc.data()!, doc.id);
      }
      return null;
    });
  }

  // ============ PROJECTS (Enhanced) ============
  Stream<List<Project>> getProjects() {
    return _db.collection('projects').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return Project.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Future<void> addProject(Project project) async {
    await _db.collection('projects').add(project.toMap());
  }

  Future<void> updateProject(Project project) async {
    await _db.collection('projects').doc(project.id).update(project.toMap());
  }

  Future<void> deleteProject(String id) async {
    await _db.collection('projects').doc(id).delete();
  }

  // ============ TEAM MANAGEMENT ============
  Future<void> createTeam(Team team) async {
    await _db.collection('teams').add(team.toMap());
  }

  Stream<List<Team>> getTeamsForProject(String projectId) {
    return _db
        .collection('teams')
        .where('projectId', isEqualTo: projectId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return Team.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Stream<List<Team>> getAvailableTeams() {
    return _db
        .collection('teams')
        .where('isAvailable', isEqualTo: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return Team.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Future<void> assignTeamToProject(String projectId, String teamId) async {
    await _db.collection('projects').doc(projectId).update({
      'assignedTeamId': teamId,
      'status': 'in_progress',
    });
  }

  // ============ TASK MANAGEMENT ============
  Future<void> createTask(Task task) async {
    await _db.collection('tasks').add(task.toMap());
    await _createNotification(
      userId: task.assignedTo,
      title: 'New Task Assigned',
      message: 'You have been assigned: ${task.title}',
      type: 'info',
      relatedId: task.id,
    );
  }

  Stream<List<Task>> getTasksForUser(String userId) {
    return _db
        .collection('tasks')
        .where('assignedTo', isEqualTo: userId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return Task.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Stream<List<Task>> getTasksForProject(String projectId) {
    return _db
        .collection('tasks')
        .where('projectId', isEqualTo: projectId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return Task.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Future<void> updateTaskStatus(String taskId, String status, int progress) async {
    await _db.collection('tasks').doc(taskId).update({
      'status': status,
      'progress': progress,
      if (progress == 100) 'completedAt': DateTime.now(),
    });
  }

  // ============ AI SUGGESTIONS ============
  Future<Map<String, dynamic>> getAISuggestions(String projectId) async {
    final project = await _db.collection('projects').doc(projectId).get();
    final tasks = await _db
        .collection('tasks')
        .where('projectId', isEqualTo: projectId)
        .get();
    
    // Calculate metrics
    int totalTasks = tasks.docs.length;
    int completedTasks = tasks.docs.where((t) => t['progress'] == 100).length;
    double completionRate = totalTasks > 0 ? completedTasks / totalTasks : 0;
    
    // Check for delays
    bool hasDelayedTasks = tasks.docs.any((task) {
      DateTime deadline = (task['deadline'] as Timestamp).toDate();
      return deadline.isBefore(DateTime.now()) && task['progress'] < 100;
    });
    
    // Suggest best team
    final availableTeams = await _db
        .collection('teams')
        .where('isAvailable', isEqualTo: true)
        .get();
    
    String? suggestedTeam;
    if (availableTeams.docs.isNotEmpty) {
      suggestedTeam = availableTeams.docs.first['name'];
    }
    
    return {
      'completionRate': completionRate,
      'hasDelayedTasks': hasDelayedTasks,
      'suggestedTeam': suggestedTeam,
      'totalTasks': totalTasks,
      'completedTasks': completedTasks,
      'recommendation': _generateRecommendation(completionRate, hasDelayedTasks),
    };
  }

  String _generateRecommendation(double completionRate, bool hasDelays) {
    if (hasDelays) {
      return '⚠️ Project has delayed tasks. Consider reallocating resources.';
    } else if (completionRate < 0.3) {
      return '📈 Project just started. Focus on completing initial tasks.';
    } else if (completionRate > 0.8) {
      return '🎉 Project near completion! Prepare for final review.';
    }
    return '✅ Project on track. Keep up the good work!';
  }

  // ============ NOTIFICATIONS ============
  Future<void> _createNotification({
    required String userId,
    required String title,
    required String message,
    required String type,
    String? relatedId,
  }) async {
  // ✅ Correct - using constructor
final notification = AppNotification(
  id: '',  // Empty ID, Firestore will generate one
  userId: userId,
  title: title,
  message: message,
  type: type,
  createdAt: DateTime.now(),
  relatedId: relatedId,
);
    await _db.collection('notifications').add(notification.toMap());
  }

  Stream<List<AppNotification>> getNotificationsForUser(String userId) {
    return _db
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return AppNotification.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }

  Future<void> markNotificationAsRead(String notificationId) async {
    await _db.collection('notifications').doc(notificationId).update({
      'isRead': true,
    });
  }

  // ============ ANALYTICS ============
  Future<Map<String, dynamic>> getAnalytics() async {
    final projects = await _db.collection('projects').get();
    final users = await _db.collection('users').get();
    final tasks = await _db.collection('tasks').get();
    
    int totalProjects = projects.docs.length;
    int completedProjects = projects.docs.where((p) => p['progress'] == 100).length;
    int totalUsers = users.docs.length;
    int totalTasks = tasks.docs.length;
    int completedTasks = tasks.docs.where((t) => t['progress'] == 100).length;
    
    return {
      'totalProjects': totalProjects,
      'completedProjects': completedProjects,
      'totalUsers': totalUsers,
      'totalTasks': totalTasks,
      'completedTasks': completedTasks,
      'averageProgress': totalProjects > 0 
          ? projects.docs.map((p) => p['progress'] as int).reduce((a, b) => a + b) / totalProjects
          : 0,
    };
  }
}