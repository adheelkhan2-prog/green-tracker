import 'package:cloud_firestore/cloud_firestore.dart';


class NotificationService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Send notification for project creation
  static Future<void> notifyProjectCreated(String projectId, String projectTitle, String adminId) async {
    await _firestore.collection('notifications').add({
      'userId': adminId,
      'title': 'Project Created',
      'message': 'Project "$projectTitle" has been created successfully.',
      'type': 'success',
      'notificationType': 'project_created',
      'isRead': false,
      'relatedId': projectId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
  
  // Send notification for project assignment to team
  static Future<void> notifyProjectAssigned(String teamId, String projectId, String projectTitle) async {
    // Get team members
    final teamDoc = await _firestore.collection('teams').doc(teamId).get();
    final memberIds = List<String>.from(teamDoc.data()?['memberIds'] ?? []);
    final leaderId = teamDoc.data()?['leaderId'];
    
    final allUserIds = [...memberIds];
    if (leaderId != null && !allUserIds.contains(leaderId)) {
      allUserIds.add(leaderId);
    }
    
    for (String userId in allUserIds) {
      await _firestore.collection('notifications').add({
        'userId': userId,
        'title': 'Project Assigned',
        'message': 'Project "$projectTitle" has been assigned to your team.',
        'type': 'info',
        'notificationType': 'project_assigned',
        'isRead': false,
        'relatedId': projectId,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }
  
  // Send notification for team creation
  static Future<void> notifyTeamCreated(String teamId, String teamName, List<String> memberIds) async {
    for (String userId in memberIds) {
      await _firestore.collection('notifications').add({
        'userId': userId,
        'title': 'Added to Team',
        'message': 'You have been added to team "$teamName".',
        'type': 'success',
        'notificationType': 'member_added',
        'isRead': false,
        'relatedId': teamId,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }
  
  // Send notification for task assignment
  static Future<void> notifyTaskAssigned(String taskId, String taskTitle, String assignedToId, String assignedByName) async {
    await _firestore.collection('notifications').add({
      'userId': assignedToId,
      'title': 'New Task Assigned',
      'message': '$assignedByName assigned you: "$taskTitle"',
      'type': 'info',
      'notificationType': 'task_assigned',
      'isRead': false,
      'relatedId': taskId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
  
  // Send notification for task completion
  static Future<void> notifyTaskCompleted(String taskId, String taskTitle, String completedById, String completedByName, String teamLeaderId) async {
    await _firestore.collection('notifications').add({
      'userId': teamLeaderId,
      'title': 'Task Completed',
      'message': '$completedByName completed task: "$taskTitle"',
      'type': 'success',
      'notificationType': 'task_completed',
      'isRead': false,
      'relatedId': taskId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
  
  // Send notification for project acceptance/rejection
  static Future<void> notifyProjectResponse(String projectId, String projectTitle, String teamLeaderName, bool accepted, String adminId) async {
    await _firestore.collection('notifications').add({
      'userId': adminId,
      'title': accepted ? 'Project Accepted' : 'Project Rejected',
      'message': '$teamLeaderName has ${accepted ? "accepted" : "rejected"} project "$projectTitle"',
      'type': accepted ? 'success' : 'warning',
      'notificationType': accepted ? 'project_accepted' : 'project_rejected',
      'isRead': false,
      'relatedId': projectId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
  
  // Send notification for join request
  static Future<void> notifyJoinRequest(String projectId, String projectTitle, String requesterId, String requesterName, String leaderId) async {
    await _firestore.collection('notifications').add({
      'userId': leaderId,
      'title': 'Join Request',
      'message': '$requesterName wants to join project "$projectTitle"',
      'type': 'warning',
      'notificationType': 'join_request',
      'isRead': false,
      'relatedId': projectId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
  
  // Send deadline reminder
  static Future<void> sendDeadlineReminder(String taskId, String taskTitle, String assignedToId, DateTime deadline) async {
    final daysLeft = deadline.difference(DateTime.now()).inDays;
    if (daysLeft <= 3 && daysLeft > 0) {
      await _firestore.collection('notifications').add({
        'userId': assignedToId,
        'title': 'Deadline Reminder',
        'message': 'Task "$taskTitle" is due in $daysLeft day${daysLeft > 1 ? 's' : ''}',
        'type': 'deadline',
        'notificationType': 'deadline_reminder',
        'isRead': false,
        'relatedId': taskId,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }
  
  // Send evidence submitted notification
  static Future<void> notifyEvidenceSubmitted(String taskId, String taskTitle, String submittedByName, String teamLeaderId) async {
    await _firestore.collection('notifications').add({
      'userId': teamLeaderId,
      'title': 'Evidence Submitted',
      'message': '$submittedByName has submitted evidence for task "$taskTitle"',
      'type': 'info',
      'notificationType': 'evidence_submitted',
      'isRead': false,
      'relatedId': taskId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}