class RoleGuard {
  static bool isAdmin(String role) => role == "admin";

  static bool isLecturer(String role) => role == "lecturer";

  static bool canManageProjects(String role) =>
      role == "admin" || role == "lecturer";

  static bool canViewAll(String role) =>
      role == "admin" || role == "lecturer";

  static bool isReadOnly(String role) => role == "external";
}