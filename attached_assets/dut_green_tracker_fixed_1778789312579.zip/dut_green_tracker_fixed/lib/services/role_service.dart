import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/role.dart';

class RoleService {
  final _db = FirebaseFirestore.instance;

  Future<Role> getRole(String roleName) async {
    final doc = await _db.collection('roles').doc(roleName).get();
    return Role.fromMap(doc.data()!);
  }
}