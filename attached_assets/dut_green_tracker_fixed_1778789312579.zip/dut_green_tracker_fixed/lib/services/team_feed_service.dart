// lib/services/team_feed_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TeamFeedItem {
  final String id;
  final String projectId;
  final String userId;
  final String userName;
  final String userPhotoUrl;
  final String type; // 'update', 'task_completed', 'photo_upload', 'comment', 'member_joined'
  final String title;
  final String content;
  final List<String> images;
  final List<String> attachments;
  final DateTime createdAt;
  final List<String> readBy;
  final int commentCount;
  final bool isPinned;
  
  TeamFeedItem({
    required this.id,
    required this.projectId,
    required this.userId,
    required this.userName,
    required this.userPhotoUrl,
    required this.type,
    required this.title,
    required this.content,
    required this.images,
    required this.attachments,
    required this.createdAt,
    required this.readBy,
    required this.commentCount,
    required this.isPinned,
  });
  
  factory TeamFeedItem.fromMap(Map<String, dynamic> map, String id) {
    return TeamFeedItem(
      id: id,
      projectId: map['projectId'] ?? '',
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? 'Unknown',
      userPhotoUrl: map['userPhotoUrl'] ?? '',
      type: map['type'] ?? 'update',
      title: map['title'] ?? '',
      content: map['content'] ?? '',
      images: List<String>.from(map['images'] ?? []),
      attachments: List<String>.from(map['attachments'] ?? []),
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      readBy: List<String>.from(map['readBy'] ?? []),
      commentCount: map['commentCount'] ?? 0,
      isPinned: map['isPinned'] ?? false,
    );
  }
}

class TeamFeedComment {
  final String id;
  final String feedId;
  final String userId;
  final String userName;
  final String userPhotoUrl;
  final String content;
  final DateTime createdAt;
  
  TeamFeedComment({
    required this.id,
    required this.feedId,
    required this.userId,
    required this.userName,
    required this.userPhotoUrl,
    required this.content,
    required this.createdAt,
  });
  
  factory TeamFeedComment.fromMap(Map<String, dynamic> map, String id) {
    return TeamFeedComment(
      id: id,
      feedId: map['feedId'] ?? '',
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? 'Unknown',
      userPhotoUrl: map['userPhotoUrl'] ?? '',
      content: map['content'] ?? '',
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}

class TeamFeedService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Create a feed post
  Future<void> createFeedPost({
    required String projectId,
    required String type,
    required String title,
    required String content,
    List<String> images = const [],
    List<String> attachments = const [],
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    
    final userDoc = await _firestore.collection('users').doc(user.uid).get();
    final userName = userDoc.data()?['name'] ?? 'Team Member';
    final userPhotoUrl = userDoc.data()?['photoUrl'] ?? '';
    
    await _firestore.collection('team_feeds').add({
      'projectId': projectId,
      'userId': user.uid,
      'userName': userName,
      'userPhotoUrl': userPhotoUrl,
      'type': type,
      'title': title,
      'content': content,
      'images': images,
      'attachments': attachments,
      'createdAt': FieldValue.serverTimestamp(),
      'readBy': [user.uid],
      'commentCount': 0,
      'isPinned': false,
    });
  }
  
  // Get feeds for a project
  Stream<List<TeamFeedItem>> getProjectFeeds(String projectId) {
    return _firestore
        .collection('team_feeds')
        .where('projectId', isEqualTo: projectId)
        .orderBy('isPinned', descending: true)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return TeamFeedItem.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }
  
  // Mark feed as read
  Future<void> markAsRead(String feedId) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    
    final feedRef = _firestore.collection('team_feeds').doc(feedId);
    final feedDoc = await feedRef.get();
    
    if (feedDoc.exists) {
      final readBy = List<String>.from(feedDoc.data()?['readBy'] ?? []);
      if (!readBy.contains(user.uid)) {
        await feedRef.update({
          'readBy': FieldValue.arrayUnion([user.uid]),
        });
      }
    }
  }
  
  // Add comment to feed
  Future<void> addComment(String feedId, String content) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || content.isEmpty) return;
    
    final userDoc = await _firestore.collection('users').doc(user.uid).get();
    final userName = userDoc.data()?['name'] ?? 'Team Member';
    final userPhotoUrl = userDoc.data()?['photoUrl'] ?? '';
    
    await _firestore.collection('team_feed_comments').add({
      'feedId': feedId,
      'userId': user.uid,
      'userName': userName,
      'userPhotoUrl': userPhotoUrl,
      'content': content,
      'createdAt': FieldValue.serverTimestamp(),
    });
    
    // Increment comment count
    await _firestore.collection('team_feeds').doc(feedId).update({
      'commentCount': FieldValue.increment(1),
    });
  }
  
  // Get comments for a feed
  Stream<List<TeamFeedComment>> getFeedComments(String feedId) {
    return _firestore
        .collection('team_feed_comments')
        .where('feedId', isEqualTo: feedId)
        .orderBy('createdAt', descending: false)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return TeamFeedComment.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }
  
  // Pin/unpin a feed post
  Future<void> togglePin(String feedId, bool isPinned) async {
    await _firestore.collection('team_feeds').doc(feedId).update({
      'isPinned': isPinned,
    });
  }
  
  // Delete feed post
  Future<void> deleteFeed(String feedId) async {
    // Delete all comments first
    final comments = await _firestore
        .collection('team_feed_comments')
        .where('feedId', isEqualTo: feedId)
        .get();
    
    final batch = _firestore.batch();
    for (var doc in comments.docs) {
      batch.delete(doc.reference);
    }
    batch.delete(_firestore.collection('team_feeds').doc(feedId));
    await batch.commit();
  }
  
  // Auto-create feed post when task is completed
  Future<void> createTaskCompletedFeed({
    required String projectId,
    required String taskTitle,
    required List<String> evidenceImages,
  }) async {
    await createFeedPost(
      projectId: projectId,
      type: 'task_completed',
      title: 'Task Completed! 🎉',
      content: 'Task "$taskTitle" has been completed with evidence.',
      images: evidenceImages,
    );
  }
  
  // Auto-create feed post when member joins
  Future<void> createMemberJoinedFeed({
    required String projectId,
    required String memberName,
  }) async {
    await createFeedPost(
      projectId: projectId,
      type: 'member_joined',
      title: 'New Team Member 👋',
      content: '$memberName has joined the team!',
    );
  }
}