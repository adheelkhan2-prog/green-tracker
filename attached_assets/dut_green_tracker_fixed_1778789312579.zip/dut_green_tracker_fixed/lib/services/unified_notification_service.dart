// lib/services/unified_notification_service.dart
// ignore_for_file: avoid_print, unused_import

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'email_service.dart';

class UnifiedNotificationService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  static Future<void> sendNotification({
    required String userId,
    required String title,
    required String message,
    required String type,
    required String notificationType,
    String? relatedId,
    bool sendEmail = true,
    Map<String, String>? emailData,
  }) async {
    // 1. Send in-app notification
    await _firestore.collection('notifications').add({
      'userId': userId,
      'title': title,
      'message': message,
      'type': type,
      'notificationType': notificationType,
      'isRead': false,
      'createdAt': FieldValue.serverTimestamp(),
      'relatedId': relatedId,
    });
    
    // 2. Send email if requested and user email is available
    if (sendEmail) {
      try {
        final userDoc = await _firestore.collection('users').doc(userId).get();
        final userEmail = userDoc.data()?['email'];
        final userName = userDoc.data()?['name'] ?? 'User';
        
        if (userEmail != null && userEmail.isNotEmpty) {
          await _sendEmailForNotification(
            email: userEmail,
            name: userName,
            title: title,
            message: message,
            notificationType: notificationType,
            emailData: emailData,
          );
        }
      } catch (e) {
        print('Email sending failed for $userId: $e');
      }
    }
  }
  
  static Future<void> sendBulkNotification({
    required List<String> userIds,
    required String title,
    required String message,
    required String type,
    required String notificationType,
    String? relatedId,
    bool sendEmail = true,
  }) async {
    final batch = _firestore.batch();
    
    for (String userId in userIds) {
      final notificationRef = _firestore.collection('notifications').doc();
      batch.set(notificationRef, {
        'userId': userId,
        'title': title,
        'message': message,
        'type': type,
        'notificationType': notificationType,
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'relatedId': relatedId,
      });
    }
    
    await batch.commit();
    
    // Send emails in parallel (don't wait, fire and forget)
    if (sendEmail) {
      for (String userId in userIds) {
        _sendEmailToUser(userId, title, message, notificationType);
      }
    }
  }
  
  static Future<void> _sendEmailToUser(String userId, String title, String message, String notificationType) async {
    try {
      final userDoc = await _firestore.collection('users').doc(userId).get();
      final userEmail = userDoc.data()?['email'];
      final userName = userDoc.data()?['name'] ?? 'User';
      
      if (userEmail != null && userEmail.isNotEmpty) {
        await _sendEmailForNotification(
          email: userEmail,
          name: userName,
          title: title,
          message: message,
          notificationType: notificationType,
        );
      }
    } catch (e) {
      print('Bulk email failed for $userId: $e');
    }
  }
  
  static Future<void> _sendEmailForNotification({
    required String email,
    required String name,
    required String title,
    required String message,
    required String notificationType,
    Map<String, String>? emailData,
  }) async {
    switch (notificationType) {
      case 'task_assigned':
        await EmailService.sendTaskAssignmentEmail(
          toEmail: email,
          toName: name,
          taskTitle: emailData?['taskTitle'] ?? title,
          projectTitle: emailData?['projectTitle'] ?? 'Project',
          deadline: emailData?['deadline'] ?? 'Not specified',
          difficulty: int.tryParse(emailData?['difficulty'] ?? '1') ?? 1,
        );
        break;
        
      case 'task_completed':
        await EmailService.sendTaskCompletedEmail(
          toEmail: email,
          toName: name,
          taskTitle: emailData?['taskTitle'] ?? title,
          projectTitle: emailData?['projectTitle'] ?? 'Project',
          completedByName: emailData?['completedByName'] ?? 'Team Member',
          evidenceCount: int.tryParse(emailData?['evidenceCount'] ?? '0') ?? 0,
        );
        break;
        
      case 'project_assigned':
        await EmailService.sendProjectAssignmentEmail(
          toEmail: email,
          toName: name,
          projectTitle: emailData?['projectTitle'] ?? title,
          description: emailData?['description'] ?? message,
        );
        break;
        
      case 'member_added':
        await EmailService.sendMemberAddedEmail(
          toEmail: email,
          toName: name,
          teamName: emailData?['teamName'] ?? 'Team',
          projectTitle: emailData?['projectTitle'] ?? 'Project',
          addedByName: emailData?['addedByName'] ?? 'Admin',
        );
        break;
        
      case 'weekly_reminder':
        await EmailService.sendWeeklyUpdateReminderEmail(
          toEmail: email,
          toName: name,
          projectTitle: emailData?['projectTitle'] ?? 'Project',
          weekNumber: int.tryParse(emailData?['weekNumber'] ?? '1') ?? 1,
        );
        break;
        
      case 'deadline_reminder':
        await EmailService.sendDeadlineReminderEmail(
          toEmail: email,
          toName: name,
          taskTitle: emailData?['taskTitle'] ?? title,
          projectTitle: emailData?['projectTitle'] ?? 'Project',
          daysLeft: int.tryParse(emailData?['daysLeft'] ?? '3') ?? 3,
        );
        break;
        
      case 'welcome':
        await EmailService.sendWelcomeEmail(
          toEmail: email,
          toName: name,
          role: emailData?['role'] ?? 'student',
        );
        break;
        
      default:
        // Generic email
        final htmlContent = '''
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .header { background: #4CAF50; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #777; border-top: 1px solid #eee; }
          </style>
        </head>
        <body>
          <div class="header"><h2>🌱 DUT GreenTrack</h2></div>
          <div class="content">
            <h3>Hello $name,</h3>
            <p><strong>$title</strong></p>
            <p>$message</p>
            <p>Log in to the app for more details.</p>
          </div>
          <div class="footer"><p>DUT GreenTrack - Tracking sustainability one task at a time</p></div>
        </body>
        </html>
        ''';
        
        await EmailService.sendRawEmail(
          toEmail: email,
          toName: name,
          subject: title,
          htmlContent: htmlContent,
        );
    }
  }
}