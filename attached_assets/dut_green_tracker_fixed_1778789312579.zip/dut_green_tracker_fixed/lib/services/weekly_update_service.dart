// lib/services/weekly_update_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class WeeklyUpdate {
  final String id;
  final String projectId;
  final String projectTitle;
  final String leaderId;
  final String leaderName;
  final int weekNumber;
  final int year;
  final DateTime startDate;
  final DateTime endDate;
  final String progressSummary;
  final String achievements;
  final String challenges;
  final String nextWeekPlan;
  final int tasksCompleted;
  final int tasksInProgress;
  final int tasksBlocked;
  final double currentProgress;
  final List<String> attachments;
  final DateTime submittedAt;
  final String status; // pending, reviewed, flagged
  final String? adminFeedback;
  final DateTime? reviewedAt;
  
  WeeklyUpdate({
    required this.id,
    required this.projectId,
    required this.projectTitle,
    required this.leaderId,
    required this.leaderName,
    required this.weekNumber,
    required this.year,
    required this.startDate,
    required this.endDate,
    required this.progressSummary,
    required this.achievements,
    required this.challenges,
    required this.nextWeekPlan,
    required this.tasksCompleted,
    required this.tasksInProgress,
    required this.tasksBlocked,
    required this.currentProgress,
    required this.attachments,
    required this.submittedAt,
    required this.status,
    this.adminFeedback,
    this.reviewedAt,
  });
  
  factory WeeklyUpdate.fromMap(Map<String, dynamic> map, String id) {
    return WeeklyUpdate(
      id: id,
      projectId: map['projectId'] ?? '',
      projectTitle: map['projectTitle'] ?? '',
      leaderId: map['leaderId'] ?? '',
      leaderName: map['leaderName'] ?? '',
      weekNumber: map['weekNumber'] ?? 1,
      year: map['year'] ?? DateTime.now().year,
      startDate: (map['startDate'] as Timestamp?)?.toDate() ?? DateTime.now(),
      endDate: (map['endDate'] as Timestamp?)?.toDate() ?? DateTime.now(),
      progressSummary: map['progressSummary'] ?? '',
      achievements: map['achievements'] ?? '',
      challenges: map['challenges'] ?? '',
      nextWeekPlan: map['nextWeekPlan'] ?? '',
      tasksCompleted: map['tasksCompleted'] ?? 0,
      tasksInProgress: map['tasksInProgress'] ?? 0,
      tasksBlocked: map['tasksBlocked'] ?? 0,
      currentProgress: map['currentProgress'] ?? 0.0,
      attachments: List<String>.from(map['attachments'] ?? []),
      submittedAt: (map['submittedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      status: map['status'] ?? 'pending',
      adminFeedback: map['adminFeedback'],
      reviewedAt: (map['reviewedAt'] as Timestamp?)?.toDate(),
    );
  }
  
  Map<String, dynamic> toMap() {
    return {
      'projectId': projectId,
      'projectTitle': projectTitle,
      'leaderId': leaderId,
      'leaderName': leaderName,
      'weekNumber': weekNumber,
      'year': year,
      'startDate': Timestamp.fromDate(startDate),
      'endDate': Timestamp.fromDate(endDate),
      'progressSummary': progressSummary,
      'achievements': achievements,
      'challenges': challenges,
      'nextWeekPlan': nextWeekPlan,
      'tasksCompleted': tasksCompleted,
      'tasksInProgress': tasksInProgress,
      'tasksBlocked': tasksBlocked,
      'currentProgress': currentProgress,
      'attachments': attachments,
      'submittedAt': Timestamp.fromDate(submittedAt),
      'status': status,
      'adminFeedback': adminFeedback,
      'reviewedAt': reviewedAt != null ? Timestamp.fromDate(reviewedAt!) : null,
    };
  }
}

class WeeklyUpdateService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Get current week number
  static Map<String, int> getCurrentWeek() {
    final now = DateTime.now();
    final startOfYear = DateTime(now.year, 1, 1);
    final weekNumber = ((now.difference(startOfYear).inDays / 7).ceil());
    return {'week': weekNumber, 'year': now.year};
  }
  
  // Get week start and end dates
  static Map<String, DateTime> getWeekDateRange(int weekNumber, int year) {
    final startOfYear = DateTime(year, 1, 1);
    final startDate = startOfYear.add(Duration(days: (weekNumber - 1) * 7));
    final endDate = startDate.add(const Duration(days: 6));
    return {'start': startDate, 'end': endDate};
  }
  
  // Check if weekly update already submitted for this week
  Future<bool> hasSubmittedThisWeek(String projectId) async {
    final currentWeek = getCurrentWeek();
    final snapshot = await _firestore
        .collection('weekly_updates')
        .where('projectId', isEqualTo: projectId)
        .where('year', isEqualTo: currentWeek['year'])
        .where('weekNumber', isEqualTo: currentWeek['week'])
        .get();
    
    return snapshot.docs.isNotEmpty;
  }
  
  // Submit weekly update
  Future<void> submitWeeklyUpdate({
    required String projectId,
    required String projectTitle,
    required String progressSummary,
    required String achievements,
    required String challenges,
    required String nextWeekPlan,
    required int tasksCompleted,
    required int tasksInProgress,
    required int tasksBlocked,
    required double currentProgress,
    List<String> attachments = const [],
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Not logged in');
    
    final userDoc = await _firestore.collection('users').doc(user.uid).get();
    final leaderName = userDoc.data()?['name'] ?? 'Team Leader';
    
    final currentWeek = getCurrentWeek();
    final weekRange = getWeekDateRange(currentWeek['week']!, currentWeek['year']!);
    
    final update = WeeklyUpdate(
      id: '',
      projectId: projectId,
      projectTitle: projectTitle,
      leaderId: user.uid,
      leaderName: leaderName,
      weekNumber: currentWeek['week']!,
      year: currentWeek['year']!,
      startDate: weekRange['start']!,
      endDate: weekRange['end']!,
      progressSummary: progressSummary,
      achievements: achievements,
      challenges: challenges,
      nextWeekPlan: nextWeekPlan,
      tasksCompleted: tasksCompleted,
      tasksInProgress: tasksInProgress,
      tasksBlocked: tasksBlocked,
      currentProgress: currentProgress,
      attachments: attachments,
      submittedAt: DateTime.now(),
      status: 'pending',
      adminFeedback: null,
      reviewedAt: null,
    );
    
    await _firestore.collection('weekly_updates').add(update.toMap());
    
    // Notify admins
    await _notifyAdmins(projectTitle, leaderName);
  }
  
  // Notify all admins
  Future<void> _notifyAdmins(String projectTitle, String leaderName) async {
    final admins = await _firestore
        .collection('users')
        .where('role', isEqualTo: 'admin')
        .get();
    
    final batch = _firestore.batch();
    for (var admin in admins.docs) {
      final notificationRef = _firestore.collection('notifications').doc();
      batch.set(notificationRef, {
        'userId': admin.id,
        'title': '📋 Weekly Update Submitted',
        'message': '$leaderName submitted weekly update for "$projectTitle"',
        'type': 'info',
        'notificationType': 'weekly_update',
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'relatedId': projectTitle,
      });
    }
    await batch.commit();
  }
  
  // Get weekly updates for a project (for Project Leader)
  Stream<List<WeeklyUpdate>> getProjectWeeklyUpdates(String projectId) {
    return _firestore
        .collection('weekly_updates')
        .where('projectId', isEqualTo: projectId)
        .orderBy('year', descending: true)
        .orderBy('weekNumber', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return WeeklyUpdate.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }
  
  // Get all pending weekly updates (for Admin)
  Stream<List<WeeklyUpdate>> getPendingWeeklyUpdates() {
    return _firestore
        .collection('weekly_updates')
        .where('status', isEqualTo: 'pending')
        .orderBy('submittedAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return WeeklyUpdate.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }
  
  // Get all weekly updates (for Admin)
  Stream<List<WeeklyUpdate>> getAllWeeklyUpdates() {
    return _firestore
        .collection('weekly_updates')
        .orderBy('submittedAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return WeeklyUpdate.fromMap(doc.data(), doc.id);
      }).toList();
    });
  }
  
  // Review weekly update (Admin)
  Future<void> reviewWeeklyUpdate(String updateId, String feedback, String status) async {
    await _firestore.collection('weekly_updates').doc(updateId).update({
      'adminFeedback': feedback,
      'status': status,
      'reviewedAt': FieldValue.serverTimestamp(),
    });
  }
  
  // Generate AI summary for admin (to be used in admin dashboard)
  static String generateAISummary(List<WeeklyUpdate> updates) {
    if (updates.isEmpty) {
      return 'No weekly updates submitted yet this week.';
    }
    
    String summary = '';
    int totalTasksCompleted = 0;
    int totalTasksInProgress = 0;
    int totalTasksBlocked = 0;
    int atRiskProjects = 0;
    List<String> topAchievements = [];
    List<String> commonChallenges = [];
    
    for (var update in updates) {
      totalTasksCompleted += update.tasksCompleted;
      totalTasksInProgress += update.tasksInProgress;
      totalTasksBlocked += update.tasksBlocked;
      
      if (update.currentProgress < 50 && update.weekNumber > 2) {
        atRiskProjects++;
      }
      
      if (update.achievements.isNotEmpty) {
        topAchievements.add('• ${update.projectTitle}: ${update.achievements}');
      }
      
      if (update.challenges.isNotEmpty) {
        commonChallenges.add('• ${update.projectTitle}: ${update.challenges}');
      }
    }
    
    summary = '''
📊 **Weekly Summary Report**

**Overall Stats:**
• ${updates.length} projects reported this week
• $totalTasksCompleted tasks completed
• $totalTasksInProgress tasks in progress  
• $totalTasksBlocked tasks blocked

**Risk Alert:**
• $atRiskProjects project(s) are behind schedule

**🎉 Top Achievements:**
${topAchievements.take(3).join('\n')}

**⚠️ Common Challenges:**
${commonChallenges.take(3).join('\n')}

**Recommendation:**
• Schedule review meetings for at-risk projects
• Address blocked tasks with resource allocation
• Recognize top performing teams
''';
    
    return summary;
  }
}