import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static final lightTheme = ThemeData(
    useMaterial3: true,
    primaryColor: const Color(0xFF00A86B),
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF00A86B),
    ),
    textTheme: GoogleFonts.poppinsTextTheme(),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF00A86B),
      foregroundColor: Colors.white,
      centerTitle: true,
    ),
  );
}