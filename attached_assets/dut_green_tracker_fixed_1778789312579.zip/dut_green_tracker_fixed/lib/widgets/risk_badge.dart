// lib/widgets/risk_badge.dart
// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../services/ai_risk_prediction.dart';

class RiskBadge extends StatelessWidget {
  final RiskPrediction risk;
  final bool showTooltip;
  final double size;

  const RiskBadge({
    super.key,
    required this.risk,
    this.showTooltip = true,
    this.size = 40,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: showTooltip 
          ? '${risk.riskLevel} - ${risk.suggestion}'
          : '${risk.riskLevel} risk',
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: risk.riskColor.withOpacity(0.1),
          shape: BoxShape.circle,
          border: Border.all(color: risk.riskColor, width: 2),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                _getRiskIcon(risk.riskLevel),
                color: risk.riskColor,
                size: size * 0.35,
              ),
              if (risk.riskPercentage > 0)
                Text(
                  '${risk.riskPercentage.toInt()}%',
                  style: TextStyle(
                    fontSize: size * 0.25,
                    fontWeight: FontWeight.bold,
                    color: risk.riskColor,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getRiskIcon(String riskLevel) {
    switch (riskLevel) {
      case 'High Risk':
        return Icons.warning_amber;
      case 'Medium Risk':
        return Icons.priority_high;
      case 'Low Risk':
        return Icons.trending_up;
      case 'Overdue':
        return Icons.timer_off;
      case 'Completed':
        return Icons.check_circle;
      default:
        return Icons.assessment;
    }
  }
}